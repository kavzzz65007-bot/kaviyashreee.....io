import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

// base './' makes the built site work from ANY address, including a GitHub
// Pages project URL such as https://<user>.github.io/<repo>/ .
export default defineConfig({
  base: './',
  plugins: [react(), tailwindcss()],
  build: {
    // pdf.js ships modern syntax; every current browser supports it.
    target: 'esnext',
    // three.js is big on purpose (it is loaded lazily, only for the 3D scenes).
    chunkSizeWarningLimit: 2000,
  },
  optimizeDeps: {
    esbuildOptions: { target: 'esnext' },
  },
});
