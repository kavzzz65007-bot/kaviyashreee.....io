import test from 'node:test';
import assert from 'node:assert/strict';

import {
  arcPoint,
  buildArcTube,
  drawCountForProgress,
  easeOutCubic,
  layoutBars,
  makeParticles,
  ringColor,
} from '../src/three/math.js';

test('particles are deterministic, finite and the requested size', () => {
  const a = makeParticles(500, 7);
  const b = makeParticles(500, 7);
  assert.equal(a.length, 1500);
  assert.deepEqual([...a], [...b]);
  assert.notDeepEqual([...a], [...makeParticles(500, 8)]);
  assert.ok([...a].every(Number.isFinite));
  assert.equal(makeParticles(0).length, 0);
  assert.equal(makeParticles(-5).length, 0);
});

test('arc tube: sizes, index bounds and unit normals', () => {
  const d = buildArcTube({ segments: 64, radialSegments: 10 });
  assert.equal(d.vertexCount, 65 * 10);
  assert.equal(d.positions.length, d.vertexCount * 3);
  assert.equal(d.indices.length, 64 * 10 * 6);
  assert.ok(d.indices.every((i) => i >= 0 && i < d.vertexCount));
  for (let v = 0; v < d.vertexCount; v += 1) {
    const len = Math.hypot(d.normals[v * 3], d.normals[v * 3 + 1], d.normals[v * 3 + 2]);
    assert.ok(Math.abs(len - 1) < 1e-5);
  }
  assert.ok([...d.positions].every(Number.isFinite));
});

test('arc tube: triangles are ordered ALONG the path (so setDrawRange reveals the arc progressively)', () => {
  const d = buildArcTube({ segments: 40, radialSegments: 8 });
  for (let s = 0; s < d.segments; s += 1) {
    const from = s * d.indicesPerSegment;
    for (let i = from; i < from + d.indicesPerSegment; i += 1) {
      const vertexSegment = Math.floor(d.indices[i] / d.radialSegments);
      assert.ok(vertexSegment === s || vertexSegment === s + 1, `index ${i} belongs to segment ${vertexSegment}, expected ${s}`);
    }
  }
});

test('arc tube: triangle winding faces outward (matches vertex normals)', () => {
  const d = buildArcTube({ segments: 32, radialSegments: 12 });
  const P = (i) => [d.positions[i * 3], d.positions[i * 3 + 1], d.positions[i * 3 + 2]];
  const N = (i) => [d.normals[i * 3], d.normals[i * 3 + 1], d.normals[i * 3 + 2]];
  let bad = 0;
  for (let t = 0; t < d.indices.length; t += 3) {
    const [a, b, c] = [d.indices[t], d.indices[t + 1], d.indices[t + 2]];
    const pa = P(a);
    const e1 = P(b).map((v, k) => v - pa[k]);
    const e2 = P(c).map((v, k) => v - pa[k]);
    const cross = [e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]];
    const n = N(a);
    if (cross[0] * n[0] + cross[1] * n[1] + cross[2] * n[2] <= 0) bad += 1;
  }
  assert.equal(bad, 0, `${bad} inward-facing triangles`);
});

test('draw range follows progress and is clamped', () => {
  const d = buildArcTube({ segments: 100, radialSegments: 14 });
  assert.equal(drawCountForProgress(0, d), 0);
  assert.equal(drawCountForProgress(1, d), d.indices.length);
  assert.equal(drawCountForProgress(0.5, d), 50 * d.indicesPerSegment);
  assert.equal(drawCountForProgress(-3, d), 0);
  assert.equal(drawCountForProgress(7, d), d.indices.length);
  assert.equal(drawCountForProgress(0.5, d) % 3, 0, 'must be a whole number of triangles');
});

test('arc point: starts at the top and runs clockwise', () => {
  const top = arcPoint(0, 2);
  assert.ok(Math.abs(top.x) < 1e-9 && Math.abs(top.y - 2) < 1e-9);
  const right = arcPoint(0.25, 2);
  assert.ok(Math.abs(right.x - 2) < 1e-9 && Math.abs(right.y) < 1e-9);
  const bottom = arcPoint(0.5, 2);
  assert.ok(Math.abs(bottom.y + 2) < 1e-9);
});

test('ringColor: red -> amber -> green and always a valid hex colour', () => {
  assert.equal(ringColor(0), '#f87171');
  assert.equal(ringColor(50), '#fbbf24');
  assert.equal(ringColor(75), '#34d399');
  assert.equal(ringColor(100), '#2dd4bf');
  for (const s of [-10, 0, 12.5, 49.9, 63, 99, 250, NaN, undefined]) assert.match(ringColor(s), /^#[0-9a-f]{6}$/);
});

test('easeOutCubic is 0 -> 1, monotonic and clamped', () => {
  assert.equal(easeOutCubic(0), 0);
  assert.equal(easeOutCubic(1), 1);
  assert.equal(easeOutCubic(2), 1);
  assert.equal(easeOutCubic(-1), 0);
  let prev = -1;
  for (let t = 0; t <= 1; t += 0.05) {
    const v = easeOutCubic(t);
    assert.ok(v >= prev);
    prev = v;
  }
});

test('bar layout: green up, red down, scaled to the biggest bar, centred', () => {
  const items = [
    { id: 'a', tag: 'Metric', deltaTenths: 60, kind: 'chunk' },
    { id: 'b', tag: 'Removed', deltaTenths: -30, kind: 'chunk' },
    { id: 'c', tag: 'Move', deltaTenths: 0, kind: 'chunk' },
    { id: 'i', tag: 'Interaction', deltaTenths: -10, kind: 'interaction' },
  ];
  const { bars, hidden, maxHeight } = layoutBars(items);
  assert.equal(hidden, 0);
  assert.deepEqual(bars.map((b) => b.tone), ['up', 'down', 'flat', 'neutral']);
  assert.ok(bars[0].height > 0 && bars[1].height < 0 && bars[2].height === 0);
  assert.equal(bars[0].height, maxHeight);
  assert.ok(Math.abs(bars[1].height) < bars[0].height);
  assert.ok(Math.abs(bars.reduce((s, b) => s + b.x, 0)) < 1e-9, 'centred around 0');
});

test('bar layout: keeps the biggest movers and the interaction bar when there are too many', () => {
  const items = Array.from({ length: 20 }, (_, i) => ({ id: `c${i}`, tag: `t${i}`, deltaTenths: i - 10, kind: 'chunk' }));
  items.push({ id: 'i', tag: 'Interaction', deltaTenths: 1, kind: 'interaction' });
  const { bars, hidden } = layoutBars(items, { maxBars: 8 });
  assert.equal(bars.length, 8);
  assert.equal(hidden, 13);
  assert.ok(bars.some((b) => b.kind === 'interaction'));
  const kept = bars.filter((b) => b.kind === 'chunk').map((b) => Math.abs(b.deltaTenths));
  assert.ok(Math.min(...kept) >= 5, 'the smallest movers were dropped');
});

test('bar layout: empty / all-zero input does not break', () => {
  assert.deepEqual(layoutBars([]).bars, []);
  assert.deepEqual(layoutBars(undefined).bars, []);
  const z = layoutBars([{ id: 'a', tag: 'x', deltaTenths: 0, kind: 'chunk' }]);
  assert.equal(z.bars[0].height, 0);
  assert.ok(Number.isFinite(z.width));
});
