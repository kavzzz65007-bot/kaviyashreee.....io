// Shared helpers for the test files (not a test itself).
import { mulberry32 } from '../src/three/math.js';

export { mulberry32 };

const POOL = [
  'Led a team of 5 engineers to ship the billing platform 2 weeks early',
  'Responsible for maintaining internal tools',
  'Built REST APIs in Python and Node.js serving 2M requests per day',
  'Worked on various bugs and other stuff',
  'Reduced page load time by 40% with caching and code splitting',
  'Mentored three junior developers and ran weekly code reviews',
  'Helped with deployments and testing of releases',
  'Automated CI/CD pipelines on AWS with Docker and Kubernetes',
  'Designed a PostgreSQL schema that cut report time from 30s to 4s',
  'Participated in daily standups and sprint planning',
  'Launched an open-source CLI tool that reached 400+ GitHub stars',
  'Wrote unit tests for backend services using pytest',
  'Managed a $1.2M cloud budget and cut spend by 18%',
  'Assisted with data entry tasks',
  'Implemented monitoring dashboards that detected incidents 3x faster',
  'Improved onboarding flow conversion from 12% to 19%',
  'Collaborated with design to deliver accessible React components',
  'Tasked with migrating legacy services',
];

const HEADINGS = ['SUMMARY', 'EXPERIENCE', 'EDUCATION', 'SKILLS', 'PROJECTS'];

/** Random but reproducible resume text built from a pool of lines. */
export function randomResume(seed) {
  const rand = mulberry32(seed);
  const pick = () => POOL[Math.floor(rand() * POOL.length)];
  const lines = ['JAMIE DOE', 'jamie.doe@example.com | +1 555 010 7788'];
  for (const h of HEADINGS) {
    if (rand() < 0.2) continue; // sometimes miss a section
    lines.push(h);
    if (h === 'SKILLS') {
      lines.push(['Python', 'SQL', 'Docker', 'AWS', 'Git', 'React', 'Redis'].filter(() => rand() < 0.6).join(', ') || 'Python');
    } else if (h === 'EDUCATION') {
      lines.push('B.S. in Computer Science | State University | 2019');
    } else if (h === 'SUMMARY') {
      lines.push('Software engineer with experience in backend systems and cloud platforms.');
    } else {
      const n = 1 + Math.floor(rand() * 5);
      for (let i = 0; i < n; i += 1) lines.push(`- ${pick()}`);
    }
  }
  return lines.join('\n');
}

/** Randomly edit a resume: delete / insert / replace / swap / duplicate lines. */
export function mutateResume(text, seed) {
  const rand = mulberry32(seed);
  const lines = text.split('\n');
  const edits = 1 + Math.floor(rand() * 6);
  for (let e = 0; e < edits; e += 1) {
    const i = Math.floor(rand() * lines.length);
    const kind = Math.floor(rand() * 5);
    const pick = POOL[Math.floor(rand() * POOL.length)];
    if (kind === 0 && lines.length > 3) lines.splice(i, 1);
    else if (kind === 1) lines.splice(i, 0, `- ${pick}`);
    else if (kind === 2) lines[i] = `- ${pick}`;
    else if (kind === 3 && i + 1 < lines.length) [lines[i], lines[i + 1]] = [lines[i + 1], lines[i]];
    else lines.splice(i, 0, lines[i]);
  }
  return lines.join('\n');
}

export const JD_SAMPLE = `Backend Engineer
We need a backend engineer with Python, Node.js, PostgreSQL, Redis, Docker, Kubernetes and AWS experience.
You will build REST APIs and CI/CD pipelines, improve performance and mentor engineers.`;
