import test, { beforeEach } from 'node:test';
import assert from 'node:assert/strict';

import {
  addVersion,
  draftKey,
  emptyVersions,
  hashText,
  loadDraft,
  loadVersions,
  removeVersion,
  resetStorageForTests,
  saveDraft,
  saveVersions,
  storage,
  versionsKey,
} from '../src/lib/storage.js';
import {
  deleteLocalAccount,
  getSession,
  hashPassword,
  loginGuest,
  loginUser,
  logout,
  registerUser,
  validateCredentials,
} from '../src/lib/auth.js';
import { MAX_VERSIONS } from '../src/engine/constants.js';

beforeEach(() => resetStorageForTests());

/* ------------------------------ storage ------------------------------ */

test('storage falls back to memory when localStorage is unavailable (never throws)', () => {
  assert.equal(storage.get('nope'), null);
  assert.equal(storage.set('k', 'v'), false, 'reports that it was not persisted');
  assert.equal(storage.get('k'), 'v');
  storage.remove('k');
  assert.equal(storage.get('k'), null);
});

test('storage survives a localStorage that throws on every call', () => {
  globalThis.window = {
    get localStorage() {
      throw new Error('SecurityError: blocked');
    },
  };
  try {
    resetStorageForTests();
    assert.doesNotThrow(() => storage.set('a', '1'));
    assert.equal(storage.get('a'), '1');
  } finally {
    delete globalThis.window;
    resetStorageForTests();
  }
});

test('storage uses localStorage when it works, and falls back when it is full', () => {
  const store = new Map();
  let full = false;
  globalThis.window = {
    localStorage: {
      getItem: (k) => (store.has(k) ? store.get(k) : null),
      setItem: (k, v) => {
        if (full && k !== '__resumelens_probe__') throw new Error('QuotaExceededError');
        store.set(k, v);
      },
      removeItem: (k) => store.delete(k),
    },
  };
  try {
    resetStorageForTests();
    assert.equal(storage.set('x', '1'), true);
    assert.equal(store.get('x'), '1');
    full = true;
    assert.equal(storage.set('x', '2'), false);
    assert.equal(storage.get('x'), '2', 'the in-memory copy wins while storage is full');
  } finally {
    delete globalThis.window;
    resetStorageForTests();
  }
});

test('hashText is deterministic and sensitive', () => {
  assert.equal(hashText('abc'), hashText('abc'));
  assert.notEqual(hashText('abc'), hashText('abd'));
  assert.match(hashText('abc'), /^[0-9a-f]+$/);
});

test('versions: v1, v2, v3 labels, duplicates are not re-saved', () => {
  let data = emptyVersions();
  let r = addVersion(data, 'Resume one text', 1);
  assert.equal(r.added.label, 'v1');
  data = r.data;
  r = addVersion(data, 'Resume two text', 2);
  assert.equal(r.added.label, 'v2');
  data = r.data;
  r = addVersion(data, '  Resume   one text  '.replace(/ {2,}/g, ' '), 3); // same text, different spacing
  assert.equal(r.added, null);
  assert.equal(r.existing.label, 'v1');
  assert.equal(r.data.items.length, 2);
  r = addVersion(data, '   ', 4);
  assert.equal(r.added, null);
  r = addVersion(data, 'Resume three text', 5);
  assert.equal(r.added.label, 'v3');
});

test('versions: capped at MAX_VERSIONS, oldest dropped, labels keep counting', () => {
  let data = emptyVersions();
  for (let i = 1; i <= MAX_VERSIONS + 5; i += 1) data = addVersion(data, `Resume number ${i}`, i).data;
  assert.equal(data.items.length, MAX_VERSIONS);
  assert.equal(data.items[0].label, 'v6');
  assert.equal(data.items.at(-1).label, `v${MAX_VERSIONS + 5}`);
  assert.equal(data.counter, MAX_VERSIONS + 5);
});

test('versions: save / load round trip, removal and corrupted data', () => {
  let data = addVersion(emptyVersions(), 'Resume A text', 1).data;
  data = addVersion(data, 'Resume B text', 2).data;
  assert.equal(saveVersions('guest', data), false); // memory fallback in Node
  assert.deepEqual(loadVersions('guest').items.map((v) => v.label), ['v1', 'v2']);
  data = removeVersion(data, data.items[0].id);
  assert.equal(data.items.length, 1);

  storage.set(versionsKey('guest'), '{not json');
  assert.deepEqual(loadVersions('guest'), emptyVersions());
  storage.set(versionsKey('guest'), JSON.stringify({ items: [{ id: 5 }, null, { id: 'x', label: 'v1', text: '', savedAt: 1 }], counter: 'x' }));
  assert.deepEqual(loadVersions('guest'), emptyVersions());
  storage.set(versionsKey('guest'), 'null');
  assert.deepEqual(loadVersions('guest'), emptyVersions());
});

test('draft: round trip and corrupted data fall back to empty strings', () => {
  assert.deepEqual(loadDraft('guest'), { v1: '', v2: '', jd: '' });
  saveDraft('guest', { v1: 'a', v2: 'b', jd: 'c' });
  assert.deepEqual(loadDraft('guest'), { v1: 'a', v2: 'b', jd: 'c' });
  storage.set(draftKey('guest'), '[1,2,3');
  assert.deepEqual(loadDraft('guest'), { v1: '', v2: '', jd: '' });
  storage.set(draftKey('guest'), JSON.stringify({ v1: 5, v2: null, jd: 'ok' }));
  assert.deepEqual(loadDraft('guest'), { v1: '', v2: '', jd: 'ok' });
});

test('profiles do not see each other\'s data', () => {
  saveDraft('u:alice', { v1: 'alice', v2: '', jd: '' });
  assert.equal(loadDraft('u:bob').v1, '');
  assert.equal(loadDraft('u:alice').v1, 'alice');
});

/* -------------------------------- auth ------------------------------- */

test('credential validation messages', () => {
  assert.match(validateCredentials('', 'secret1'), /Enter a username/);
  assert.match(validateCredentials('ab', 'secret1'), /Username must be/);
  assert.match(validateCredentials('bad name!', 'secret1'), /Username must be/);
  assert.match(validateCredentials('alice', ''), /Enter a password/);
  assert.match(validateCredentials('alice', '123'), /at least 6/);
  assert.equal(validateCredentials('alice_01', 'secret1'), null);
  assert.equal(validateCredentials('alice', '', { checkPassword: false }), null);
});

test('register -> logout -> login works, with a salted PBKDF2 hash (never plain text)', async () => {
  const reg = await registerUser('Alice', 'correct horse');
  assert.equal(reg.ok, true);
  assert.equal(reg.session.profile, 'u:alice');
  assert.equal(getSession().username, 'Alice');

  const stored = storage.get('resumelens:users');
  assert.ok(!stored.includes('correct horse'), 'password must not be stored in clear');
  const user = JSON.parse(stored).alice;
  assert.equal(user.algo, 'pbkdf2');
  assert.equal(user.salt.length, 32);
  assert.equal(user.hash.length, 64);

  logout();
  assert.equal(getSession(), null);

  const ok = await loginUser('alice', 'correct horse'); // case-insensitive username
  assert.equal(ok.ok, true);
  assert.equal(getSession().username, 'Alice');
});

test('wrong password, unknown user and duplicate registration give clear errors', async () => {
  await registerUser('bob', 'password1');
  logout();
  const wrong = await loginUser('bob', 'password2');
  const unknown = await loginUser('nobody', 'password1');
  assert.equal(wrong.ok, false);
  assert.equal(wrong.error, unknown.error, 'same message so usernames cannot be probed');
  assert.equal(getSession(), null);
  const dup = await registerUser('BOB', 'password3');
  assert.equal(dup.ok, false);
  assert.match(dup.error, /already taken/);
  const bad = await registerUser('x', 'y');
  assert.equal(bad.ok, false);
});

test('guest session and deleting a local account', async () => {
  const g = loginGuest();
  assert.equal(g.session.guest, true);
  assert.equal(g.session.profile, 'guest');
  assert.equal(getSession().guest, true);
  await registerUser('carol', 'password1');
  deleteLocalAccount('Carol');
  logout();
  assert.equal((await loginUser('carol', 'password1')).ok, false);
});

test('corrupted session / user data never crashes', async () => {
  storage.set('resumelens:session', '{oops');
  assert.equal(getSession(), null);
  storage.set('resumelens:session', JSON.stringify({ username: 5 }));
  assert.equal(getSession(), null);
  storage.set('resumelens:users', '[]');
  assert.equal((await loginUser('dave', 'password1')).ok, false);
  storage.set('resumelens:users', JSON.stringify({ dave: { username: 'dave' } }));
  assert.equal((await loginUser('dave', 'password1')).ok, false);
  assert.equal((await registerUser('eve', 'password1')).ok, true);
});

test('hashPassword is salted and deterministic; fallback hash path works without SubtleCrypto', async () => {
  const a = await hashPassword('secret', 'salt1');
  const b = await hashPassword('secret', 'salt1');
  const c = await hashPassword('secret', 'salt2');
  assert.equal(a.hash, b.hash);
  assert.notEqual(a.hash, c.hash);
  const weak = await hashPassword('secret', 'salt1', { forceWeak: true });
  assert.equal(weak.algo, 'weak');
  assert.notEqual(weak.hash, a.hash);

  // No SubtleCrypto (plain http page): registering falls back to the weak hash and login still works.
  const original = Object.getOwnPropertyDescriptor(globalThis, 'crypto');
  Object.defineProperty(globalThis, 'crypto', { value: { getRandomValues: original.value?.getRandomValues?.bind(original.value) || globalThis.crypto.getRandomValues.bind(globalThis.crypto) }, configurable: true });
  try {
    const reg = await registerUser('frank', 'password1');
    assert.equal(reg.ok, true);
    assert.equal(JSON.parse(storage.get('resumelens:users')).frank.algo, 'weak');
    logout();
    assert.equal((await loginUser('frank', 'password1')).ok, true);
    assert.equal((await loginUser('frank', 'password2')).ok, false);
  } finally {
    Object.defineProperty(globalThis, 'crypto', original);
  }

  // A PBKDF2 account cannot be opened without SubtleCrypto: friendly message, no crash.
  await registerUser('gina', 'password1');
  logout();
  Object.defineProperty(globalThis, 'crypto', { value: {}, configurable: true });
  try {
    const r = await loginUser('gina', 'password1');
    assert.equal(r.ok, false);
    assert.match(r.error, /https/);
  } finally {
    Object.defineProperty(globalThis, 'crypto', original);
  }
});
