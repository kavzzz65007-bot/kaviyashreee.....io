import test from 'node:test';
import assert from 'node:assert/strict';

import {
  buildJdModel,
  formatDeltaTenths,
  hasMetric,
  findWeakPhrases,
  lengthRatio,
  scoreResume,
  startsWithActionVerb,
} from '../src/engine/scoring.js';
import { parseResume, parseUnits, stem } from '../src/engine/text.js';
import { WEIGHTS_NO_JD, WEIGHTS_WITH_JD } from '../src/engine/constants.js';
import { DEMO_JD, DEMO_V1, DEMO_V2 } from '../src/engine/demoData.js';
import { JD_SAMPLE, randomResume } from './helpers.js';

const sum = (o) => Object.values(o).reduce((a, b) => a + b, 0);

test('weights add up to exactly 100 with and without a job description', () => {
  assert.equal(sum(WEIGHTS_WITH_JD), 100);
  assert.equal(sum(WEIGHTS_NO_JD), 100);
  assert.equal(WEIGHTS_NO_JD.keywords, 0);
});

test('scoring is deterministic: same input -> identical result', () => {
  const a = scoreResume(DEMO_V2, DEMO_JD);
  const b = scoreResume(DEMO_V2, DEMO_JD);
  assert.deepEqual(a, b);
  // JD text vs prebuilt model give the same answer
  const c = scoreResume(DEMO_V2, buildJdModel(DEMO_JD));
  assert.deepEqual(a, c);
  for (let seed = 1; seed <= 25; seed += 1) {
    const text = randomResume(seed);
    assert.deepEqual(scoreResume(text, JD_SAMPLE), scoreResume(text, JD_SAMPLE));
  }
});

test('category scores add up to the total (breakdown is consistent) and stay within 0..max', () => {
  for (const jd of [DEMO_JD, null, '']) {
    for (const text of [DEMO_V1, DEMO_V2, randomResume(3), randomResume(9)]) {
      const r = scoreResume(text, jd);
      const tenths = r.breakdown.reduce((s, c) => s + c.tenths, 0);
      assert.equal(tenths, r.totalTenths);
      assert.equal(r.total, r.totalTenths / 10);
      assert.ok(r.total >= 0 && r.total <= 100);
      for (const c of r.breakdown) {
        assert.ok(c.score >= 0 && c.score <= c.max, `${c.key} ${c.score}/${c.max}`);
      }
      const maxSum = r.breakdown.reduce((s, c) => s + c.max, 0);
      assert.equal(maxSum, 100);
      assert.equal(r.hasJD, Boolean(jd));
    }
  }
});

test('without a JD the keyword category is skipped and its weight redistributed', () => {
  const r = scoreResume(DEMO_V2, '');
  assert.equal(r.hasJD, false);
  assert.equal(r.categories.keywords.max, 0);
  assert.equal(r.categories.keywords.skipped, true);
  assert.equal(r.categories.metrics.max, 31);
  assert.equal(r.categories.verbs.max, 23);
  assert.equal(r.categories.sections.max, 23);
  assert.equal(r.categories.readability.max, 23);
  assert.deepEqual(r.missingKeywords, []);
});

test('empty, whitespace-only and gibberish input never throws and scores 0', () => {
  for (const text of ['', '   ', '\n\n\n', '!!!???', '🙂🙂🙂', undefined, null]) {
    const r = scoreResume(text, DEMO_JD);
    assert.equal(typeof r.total, 'number');
    assert.ok(Number.isFinite(r.total));
    assert.ok(r.total >= 0 && r.total <= 100);
  }
  assert.equal(scoreResume('', null).total, 0);
});

test('a good resume scores clearly higher than a weak one', () => {
  const weak = scoreResume(DEMO_V1, DEMO_JD).total;
  const strong = scoreResume(DEMO_V2, DEMO_JD).total;
  assert.ok(strong > weak + 20, `${weak} -> ${strong}`);
});

test('metric detection', () => {
  const yes = [
    'Cut costs by 18%',
    'Managed a $1.2M budget',
    'Served 1,200 customers',
    'Shipped releases 3x faster',
    'Reduced latency from 800ms to 250ms',
    'Saved the team 5 hours every week',
    'Grew revenue 40%',
    'Reached 400+ stars',
    'Handled 2M requests per day',
    'Led a 5-person team',
  ];
  const no = [
    'Built APIs in 2023',
    'Wrote Java 8 services',
    'Migrated to Python 3 and S3',
    'Used HTML5 and CSS3',
    'Built 3D visualisations',
    'Finished 1st in the class',
    'Improved onboarding',
  ];
  for (const t of yes) assert.equal(hasMetric(t), true, t);
  for (const t of no) assert.equal(hasMetric(t), false, t);
});

test('action verb detection (any inflection, weak openers rejected)', () => {
  for (const t of ['Led a team', 'Developed an API', 'Developing an API', 'Manages 5 engineers', 'Built a tool', 'Reduced cost', 'Wrote tests']) {
    assert.equal(startsWithActionVerb(t), true, t);
  }
  for (const t of ['Responsible for the API', 'Helped with releases', 'Worked on bugs', 'The API was rebuilt', '', '123']) {
    assert.equal(startsWithActionVerb(t), false, t);
  }
});

test('weak phrase detection picks the longest phrase and finds clichés', () => {
  const w = findWeakPhrases('Helped with various deployment tasks');
  const names = w.map((x) => x.phrase);
  assert.ok(names.includes('helped with'));
  assert.ok(!names.includes('helped'), 'shorter contained phrase should be dropped');
  assert.ok(names.includes('various'));
  assert.ok(findWeakPhrases('Hard worker and team player').length === 2);
  assert.equal(findWeakPhrases('Led a migration that cut costs by 20%').length, 0);
});

test('standard sections: each missing section costs points', () => {
  const full = scoreResume(DEMO_V2, null).categories.sections;
  assert.equal(full.score, full.max);
  const noSkills = DEMO_V2.replace(/SKILLS\n[^\n]*\n/, '');
  const r = scoreResume(noSkills, null).categories.sections;
  assert.ok(r.score < full.score);
  const noContact = DEMO_V2.replace(/alex\.morgan@example\.com \| \+1 415 555 0198 \|/, '');
  assert.ok(scoreResume(noContact, null).categories.sections.score < full.score);
});

test('JD keywords: stop words/filler dropped, case preserved, weights capped, matching uses stems', () => {
  const model = buildJdModel('We need Python and python experience. Strong Python skills. Managing Kubernetes clusters. The team will work with AWS.');
  const names = model.keywords.map((k) => k.display.toLowerCase());
  assert.ok(names.includes('python'));
  assert.ok(names.includes('kubernetes'));
  assert.ok(names.includes('aws'));
  assert.ok(!names.includes('the'));
  assert.ok(!names.includes('experience'));
  assert.ok(!names.includes('strong'));
  const python = model.keywords.find((k) => k.stem === 'python');
  assert.equal(python.count, 3);
  assert.equal(python.weight, 3);
  assert.equal(model.keywords.find((k) => k.stem === 'aws').display, 'AWS');

  // "managing" in the JD is matched by "managed" in the resume
  assert.equal(stem('managing'), stem('managed'));
  const r = scoreResume('JAMIE\njamie@example.com\nEXPERIENCE\n- Managed Kubernetes clusters on AWS using Python', 'Managing Kubernetes clusters with Python on AWS');
  assert.equal(r.missingKeywords.length, 0);
  assert.ok(r.categories.keywords.score === r.categories.keywords.max);
});

test('missing keywords are listed from the JD, highest weight first', () => {
  const r = scoreResume('JAMIE\njamie@example.com\nSKILLS\nPython', 'Python Docker Docker Docker Terraform Terraform GraphQL');
  assert.deepEqual(r.missingKeywords.map((k) => k.display), ['Docker', 'Terraform', 'GraphQL']);
  assert.deepEqual(r.matchedKeywords.map((k) => k.display), ['Python']);
});

test('keyword stuffing cannot beat the cap: presence counts once', () => {
  const base = scoreResume('JAMIE\njamie@example.com\nSKILLS\nPython', 'Python Docker').categories.keywords.score;
  const stuffed = scoreResume('JAMIE\njamie@example.com\nSKILLS\nPython Python Python Python Python', 'Python Docker').categories.keywords.score;
  assert.equal(base, stuffed);
});

test('parsing: wrapped bullets are joined, lone glyph lines attach to the next line', () => {
  const units = parseUnits('EXPERIENCE\n- Built a very long running service that\nhandled many requests\n•\nShipped the new billing flow\n- Led migration to AWS');
  assert.equal(units.length, 4);
  assert.equal(units[1].text, 'Built a very long running service that handled many requests');
  assert.equal(units[2].marker.trim(), '•');
  assert.equal(units[2].text, 'Shipped the new billing flow');
});

test('parsing: bullets are found with markers, without markers and with no headings at all', () => {
  const marked = parseResume('EXPERIENCE\n- Built APIs for the platform team\n- Led the migration to the cloud');
  assert.equal(marked.bullets.length, 2);
  const prose = parseResume('EXPERIENCE\nSoftware Engineer | Acme | 2020 - 2023\nBuilt internal APIs that served many different teams at once\nLed the migration of the monolith to services across three regions');
  assert.equal(prose.bullets.length, 2, 'meta line must not count as a bullet');
  const noHeadings = parseResume('Built internal APIs that served many different teams at once\nLed the migration of the monolith to services across three regions');
  assert.equal(noHeadings.bullets.length, 2);
});

test('length curve is piece-wise linear and peaks between 350 and 800 words', () => {
  assert.equal(lengthRatio(0), 0);
  assert.equal(lengthRatio(350), 1);
  assert.equal(lengthRatio(600), 1);
  assert.equal(lengthRatio(800), 1);
  assert.ok(lengthRatio(1000) < 1 && lengthRatio(1000) > lengthRatio(1500));
  assert.ok(lengthRatio(100) < lengthRatio(250));
  assert.ok(lengthRatio(99999) > 0);
});

test('weak bullet detection returns one short suggestion per bullet', () => {
  const r = scoreResume(DEMO_V1, DEMO_JD);
  assert.ok(r.weakBullets.length >= 4);
  for (const b of r.weakBullets) {
    assert.equal(typeof b.suggestion, 'string');
    assert.ok(b.suggestion.length > 10 && b.suggestion.length < 160, b.suggestion);
  }
  const resp = r.weakBullets.find((b) => /Responsible for/.test(b.text));
  assert.ok(resp.issues.includes('weak-phrase'));
});

test('formatDeltaTenths formats signed values', () => {
  assert.equal(formatDeltaTenths(0), '±0');
  assert.equal(formatDeltaTenths(60), '+6');
  assert.equal(formatDeltaTenths(65), '+6.5');
  assert.equal(formatDeltaTenths(-32), '−3.2');
  assert.equal(formatDeltaTenths(NaN), '±0');
});

test('a very large resume is scored quickly', () => {
  const big = Array.from({ length: 1200 }, (_, i) => `- Built service number ${i} that served ${i + 2} users`).join('\n');
  const t0 = performance.now();
  const r = scoreResume(`EXPERIENCE\n${big}`, DEMO_JD);
  assert.ok(performance.now() - t0 < 1500);
  assert.ok(Number.isFinite(r.total));
});
