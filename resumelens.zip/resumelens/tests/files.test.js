import test from 'node:test';
import assert from 'node:assert/strict';

import {
  FileError,
  extractPdfText,
  htmlToText,
  itemsToLines,
  readResumeFile,
  validateFile,
} from '../src/lib/fileParsing.js';
import { MAX_CHARS, MAX_FILE_BYTES } from '../src/engine/constants.js';
import { DEMO_V2 } from '../src/engine/demoData.js';
import { parseResume } from '../src/engine/text.js';

const file = (parts, name, type = '') => new File(parts, name, { type });

/** Build a tiny valid one-page text PDF (ASCII only) so the real pdf.js can read it. */
function makePdf(lines) {
  const esc = (s) => s.replace(/([()\\])/g, '\\$1');
  const stream = lines.length
    ? `BT /F1 12 Tf 72 720 Td ${lines.map((l, i) => `${i ? '0 -16 Td ' : ''}(${esc(l)}) Tj`).join(' ')} ET`
    : '';
  const objs = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>',
    `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`,
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
  ];
  let pdf = '%PDF-1.4\n';
  const offsets = [];
  objs.forEach((o, i) => {
    offsets.push(pdf.length);
    pdf += `${i + 1} 0 obj\n${o}\nendobj\n`;
  });
  const xref = pdf.length;
  pdf += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n${offsets.map((o) => `${String(o).padStart(10, '0')} 00000 n \n`).join('')}`;
  pdf += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return new TextEncoder().encode(pdf);
}

/** The real pdf.js (Node build) - skipped when it is not installed. */
async function loadRealPdfjs() {
  try {
    return await import('pdfjs-dist/legacy/build/pdf.mjs');
  } catch {
    return null;
  }
}

/* ----------------------------- validateFile ---------------------------- */

test('validateFile: wrong type, old .doc, empty and oversize files are rejected with clear messages', () => {
  assert.match(validateFile(null), /No file/);
  assert.match(validateFile(file(['x'], 'photo.png', 'image/png')), /not a supported file type/);
  assert.match(validateFile(file(['x'], 'resume.exe')), /not a supported file type/);
  assert.match(validateFile(file(['x'], 'resume')), /not a supported file type/);
  assert.match(validateFile(file(['x'], 'old.doc')), /old \.doc/);
  assert.match(validateFile(file([], 'empty.pdf')), /empty/);
  const big = { name: 'big.pdf', size: MAX_FILE_BYTES + 1 };
  assert.match(validateFile(big), /5\.0 MB/);
  assert.equal(validateFile({ name: 'ok.pdf', size: MAX_FILE_BYTES }), null);
  assert.equal(validateFile(file(['hello'], 'CV.DOCX')), null);
  assert.equal(validateFile(file(['hello'], 'cv.txt')), null);
});

test('readResumeFile rejects bad files with FileError before reading them', async () => {
  await assert.rejects(readResumeFile(file(['x'], 'a.png')), FileError);
  await assert.rejects(readResumeFile(undefined), /No file/);
});

/* ------------------------------- TXT ---------------------------------- */

test('TXT files are read and normalised', async () => {
  const { text } = await readResumeFile(file(['Alex Morgan\r\nalex@example.com\r\n\r\n- Built APIs'], 'cv.txt', 'text/plain'));
  assert.equal(text, 'Alex Morgan\nalex@example.com\n\n- Built APIs');
});

test('binary junk renamed to .txt, empty text and huge text are rejected nicely', async () => {
  const junk = new Uint8Array(2000).map((_, i) => (i * 37) % 256);
  await assert.rejects(readResumeFile(file([junk], 'junk.txt')), /does not look like plain text/);
  await assert.rejects(readResumeFile(file(['   \n  '], 'blank.txt')), /No readable text/);
  await assert.rejects(readResumeFile(file(['a '.repeat(MAX_CHARS)], 'huge.txt')), /too long/);
});

/* ------------------------------- DOCX --------------------------------- */

test('DOCX: mammoth HTML becomes lines with bullets (regex fallback path, no DOM in Node)', async () => {
  const html = '<h1>Alex Morgan</h1><p>alex@example.com</p><h2>Experience</h2><ul><li>Built &amp; shipped APIs</li><li>Led a team</li></ul><table><tr><td>Python</td><td>SQL</td></tr></table>';
  const text = htmlToText(html);
  assert.match(text, /Alex Morgan/);
  assert.match(text, /• Built & shipped APIs/);
  assert.match(text, /• Led a team/);
  const parsed = parseResume(text);
  assert.equal(parsed.bullets.length, 2);

  const mammoth = { convertToHtml: async () => ({ value: html }) };
  const r = await readResumeFile(file(['PK'], 'cv.docx'), { loadMammoth: async () => mammoth });
  assert.match(r.text, /Led a team/);
});

test('DOCX: unreadable, empty and library-failure cases are friendly FileErrors', async () => {
  const broken = { convertToHtml: async () => { throw new Error('zip error'); } };
  await assert.rejects(readResumeFile(file(['PK'], 'cv.docx'), { loadMammoth: async () => broken }), /could not be read/);
  const empty = { convertToHtml: async () => ({ value: '<p> </p>' }) };
  await assert.rejects(readResumeFile(file(['PK'], 'cv.docx'), { loadMammoth: async () => empty }), /No readable text/);
  await assert.rejects(readResumeFile(file(['PK'], 'cv.docx'), { loadMammoth: async () => { throw new Error('offline'); } }), /could not be loaded/);
});

/* -------------------------------- PDF --------------------------------- */

test('itemsToLines groups by baseline, orders left-to-right and spaces by gap', () => {
  const item = (str, x, y, width) => ({ str, transform: [12, 0, 0, 12, x, y], width, height: 12 });
  const lines = itemsToLines([
    item('World', 100, 700, 30),
    item('Hello', 50, 700, 30),
    item('Second line', 50, 680, 60),
    item('•', 40, 660, 5),
    item('Built things', 55, 660, 60),
    item('', 0, 0, 0),
  ]);
  assert.deepEqual(lines, ['Hello World', 'Second line', '• Built things']);
});

test('PDF: a text-based PDF is read with the real pdf.js', async (t) => {
  const lib = await loadRealPdfjs();
  if (!lib) return t.skip('pdfjs-dist is not installed');
  const wanted = ['ALEX MORGAN', 'alex.morgan@example.com | +1 415 555 0198', 'EXPERIENCE', '- Built dashboards for 1,200 customers cutting tickets by 35%', '- Led CI/CD migration to AWS', 'SKILLS', 'Python, SQL, Docker (AWS) and Git'];
  const { text } = await extractPdfText(lib, makePdf(wanted).buffer);
  assert.deepEqual(text.split('\n'), wanted);

  const r = await readResumeFile(file([makePdf(wanted)], 'cv.pdf', 'application/pdf'), { loadPdfjs: async () => lib });
  assert.match(r.text, /Built dashboards/);
  assert.equal(r.note, null);
  assert.equal(parseResume(r.text).bullets.length, 2);
});

test('PDF: a scanned / image-only PDF gets the "looks scanned" message', async (t) => {
  const lib = await loadRealPdfjs();
  if (!lib) return t.skip('pdfjs-dist is not installed');
  await assert.rejects(
    readResumeFile(file([makePdf([])], 'scan.pdf', 'application/pdf'), { loadPdfjs: async () => lib }),
    (err) => err instanceof FileError && /looks scanned/.test(err.message),
  );
});

test('PDF: a fake .pdf is reported as not a valid PDF, and a missing reader as offline', async (t) => {
  const lib = await loadRealPdfjs();
  if (lib) {
    await assert.rejects(
      readResumeFile(file(['this is not a pdf at all'], 'fake.pdf', 'application/pdf'), { loadPdfjs: async () => lib }),
      (err) => err instanceof FileError && /valid PDF|could not be read/.test(err.message),
    );
  } else t.diagnostic('pdfjs-dist missing: skipped fake-pdf check');
  await assert.rejects(
    readResumeFile(file(['%PDF-1.4'], 'cv.pdf'), { loadPdfjs: async () => { throw new Error('network'); } }),
    /could not be loaded/,
  );
});

test('demo resume text survives a TXT upload unchanged', async () => {
  const { text } = await readResumeFile(file([DEMO_V2], 'v2.txt'));
  assert.equal(text, DEMO_V2.trim());
});
