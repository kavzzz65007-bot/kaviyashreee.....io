import test from 'node:test';
import assert from 'node:assert/strict';

import { allChunksUnits, attributeChanges, revertChunkText } from '../src/engine/attribution.js';
import { analyzeEditImpact, validateInputs } from '../src/engine/analysis.js';
import { computeNextBestEdits } from '../src/engine/nextBest.js';
import { buildJdModel, scoreResume } from '../src/engine/scoring.js';
import { parseUnits, unitsToText } from '../src/engine/text.js';
import { DEMO_JD, DEMO_V1, DEMO_V2 } from '../src/engine/demoData.js';
import { JD_SAMPLE, mutateResume, randomResume } from './helpers.js';

const noYield = async () => {};

/* ---------------------- the headline guarantee ---------------------- */

test('attributed deltas + interaction effect = total change (demo data, with JD)', () => {
  const r = attributeChanges(parseUnits(DEMO_V1), parseUnits(DEMO_V2), DEMO_JD);
  const total = r.after.totalTenths - r.before.totalTenths;
  const sum = r.chunks.reduce((s, c) => s + c.deltaTenths, 0);
  assert.equal(r.totalTenths, total);
  assert.equal(r.sumTenths, sum);
  assert.equal(sum + r.interactionTenths, total, 'sum of edits + interaction must equal the total change');
  assert.ok(r.chunks.length >= 8);
});

test('attributed deltas + interaction = total change (no JD)', () => {
  const r = attributeChanges(parseUnits(DEMO_V1), parseUnits(DEMO_V2), null);
  const sum = r.chunks.reduce((s, c) => s + c.deltaTenths, 0);
  assert.equal(sum + r.interactionTenths, r.after.totalTenths - r.before.totalTenths);
});

test('fuzz: the sum rule holds for 300 random pairs, with and without a JD', () => {
  const jd = buildJdModel(JD_SAMPLE);
  for (let seed = 1; seed <= 300; seed += 1) {
    const a = randomResume(seed);
    const b = seed % 9 === 0 ? randomResume(seed + 500) : mutateResume(a, seed * 17);
    for (const jdArg of [jd, null]) {
      const r = attributeChanges(parseUnits(a), parseUnits(b), jdArg);
      const sum = r.chunks.reduce((s, c) => s + c.deltaTenths, 0);
      assert.equal(sum + r.interactionTenths, r.after.totalTenths - r.before.totalTenths, `seed ${seed}`);
      assert.ok(Number.isInteger(r.interactionTenths));
      // the v2 score used here is exactly what the stand-alone scorer reports
      assert.equal(r.after.total, scoreResume(b, jdArg).total, `v2 consistency seed ${seed}`);
      assert.equal(r.before.total, scoreResume(a, jdArg).total, `v1 consistency seed ${seed}`);
    }
  }
});

test('single-edit change: the interaction effect is exactly zero', () => {
  const v1 = 'JAMIE DOE\njamie@example.com\nEXPERIENCE\n- Responsible for the billing API\n- Led a team of 5 engineers to ship the platform';
  const v2 = 'JAMIE DOE\njamie@example.com\nEXPERIENCE\n- Built the billing API serving 2M requests per day\n- Led a team of 5 engineers to ship the platform';
  const r = attributeChanges(parseUnits(v1), parseUnits(v2), null);
  assert.equal(r.chunks.length, 1);
  assert.equal(r.interactionTenths, 0);
  assert.equal(r.chunks[0].deltaTenths, r.totalTenths);
  assert.ok(r.chunks[0].delta > 0);
});

/* --------------------------- identical input -------------------------- */

test('identical v1 and v2: no chunks, zero change, zero interaction', () => {
  const r = attributeChanges(parseUnits(DEMO_V2), parseUnits(DEMO_V2), DEMO_JD);
  assert.equal(r.identical, true);
  assert.equal(r.chunks.length, 0);
  assert.equal(r.totalTenths, 0);
  assert.equal(r.interactionTenths, 0);
});

/* --------------------------- labels + regressions ----------------------- */

test('chunks are labelled in plain language and regressions are flagged', () => {
  const r = attributeChanges(parseUnits(DEMO_V1), parseUnits(DEMO_V2), DEMO_JD);
  const labels = r.chunks.map((c) => c.label);
  assert.ok(labels.some((l) => /^Added metric to bullet \d/.test(l)), labels.join(' | '));
  assert.ok(labels.some((l) => /^Moved section: SKILLS/.test(l)));
  assert.ok(labels.some((l) => /^Added section: PROJECTS/.test(l)));
  assert.ok(labels.some((l) => /^Skills updated: \+TypeScript/.test(l)));
  const regressions = r.chunks.filter((c) => c.regression);
  assert.ok(regressions.length >= 2, 'demo should contain regressions');
  for (const c of r.chunks) assert.equal(c.regression, c.deltaTenths < 0);
  const move = r.chunks.find((c) => c.kind === 'moved');
  assert.equal(move.deltaTenths, 0);
  assert.match(move.note, /not scored/);
});

test('Undo reverts ONLY the chosen chunk', () => {
  const unitsA = parseUnits(DEMO_V1);
  const unitsB = parseUnits(DEMO_V2);
  const r = attributeChanges(unitsA, unitsB, DEMO_JD);
  const removedMentor = r.chunks.find((c) => c.kind === 'removed' && /Mentored/.test(c.oldText));
  const addedVague = r.chunks.find((c) => c.kind === 'added' && /various tasks/.test(c.newText));
  assert.ok(removedMentor && addedVague);
  assert.ok(removedMentor.regression && addedVague.regression);

  // Undo the removal: the bullet comes back, everything else stays as in v2.
  const t1 = revertChunkText(r, removedMentor.id);
  assert.match(t1, /Mentored three junior developers/);
  assert.match(t1, /Reduced API response time/); // other v2 edits intact
  assert.match(t1, /Assisted with various tasks/); // the other regression is untouched
  assert.equal(t1.split('\n').length, unitsB.length + 1);

  // Undo the added vague bullet: it disappears, nothing else changes.
  const t2 = revertChunkText(r, addedVague.id);
  assert.doesNotMatch(t2, /Assisted with various tasks/);
  assert.equal(t2.split('\n').length, unitsB.length - 1);

  // Re-analysing after the undo: that chunk is gone and the score does not go down.
  const after = attributeChanges(unitsA, parseUnits(t2), DEMO_JD);
  assert.ok(!after.chunks.some((c) => /various tasks/.test(c.newText)));
  assert.ok(after.after.totalTenths >= r.after.totalTenths);
});

test('applying every chunk reproduces v2 exactly', () => {
  const r = attributeChanges(parseUnits(DEMO_V1), parseUnits(DEMO_V2), DEMO_JD);
  assert.equal(unitsToText(allChunksUnits(r)), unitsToText(parseUnits(DEMO_V2)));
});

/* ------------------------------ full analysis ------------------------- */

test('analyzeEditImpact returns everything the UI needs for the demo data', async () => {
  const r = await analyzeEditImpact({ v1Text: DEMO_V1, v2Text: DEMO_V2, jdText: DEMO_JD }, { yieldFn: noYield });
  assert.equal(r.ok, true);
  assert.equal(r.hasJD, true);
  assert.equal(r.identical, false);
  assert.ok(r.after.total > r.before.total);
  assert.equal(r.sumTenths + r.interactionTenths, r.totalTenths);
  assert.ok(r.wordLines.length > 10);
  assert.ok(r.after.missingKeywords.length > 0);
  assert.ok(r.after.weakBullets.length > 0);

  const impacts = r.wordLines.flatMap((l) => l.segments).filter((s) => s.impact !== null);
  assert.ok(impacts.some((s) => s.impact > 0), 'some words raised the score');
  assert.ok(impacts.some((s) => s.impact < 0), 'some words lowered the score');
});

test('word highlight: "800ms" raises the score, a vague phrase lowers it', async () => {
  const r = await analyzeEditImpact({ v1Text: DEMO_V1, v2Text: DEMO_V2, jdText: DEMO_JD }, { yieldFn: noYield });
  const segs = r.wordLines.flatMap((l) => l.segments);
  const metricWord = segs.find((s) => s.text === '800ms');
  assert.ok(metricWord && metricWord.impact > 0, JSON.stringify(metricWord));
  const vague = segs.find((s) => s.text === 'various' && s.status === 'added');
  assert.ok(vague && vague.impact < 0, JSON.stringify(vague));
});

test('analyzeEditImpact: identical versions give an analysis with no chunks', async () => {
  const r = await analyzeEditImpact({ v1Text: DEMO_V2, v2Text: DEMO_V2, jdText: DEMO_JD }, { yieldFn: noYield });
  assert.equal(r.ok, true);
  assert.equal(r.identical, true);
  assert.equal(r.chunks.length, 0);
  assert.equal(r.totalTenths, 0);
  assert.deepEqual(r.wordLines, []);
  assert.ok(r.after.breakdown.length === 5);
});

test('analyzeEditImpact works without a job description', async () => {
  const r = await analyzeEditImpact({ v1Text: DEMO_V1, v2Text: DEMO_V2, jdText: '' }, { yieldFn: noYield });
  assert.equal(r.ok, true);
  assert.equal(r.hasJD, false);
  assert.equal(r.after.categories.keywords.max, 0);
  assert.equal(r.sumTenths + r.interactionTenths, r.totalTenths);
  assert.ok(r.validation.notes.length === 1);
});

test('word-level evaluation is capped for huge rewrites', async () => {
  const big = (tag) => `EXPERIENCE\n${Array.from({ length: 60 }, (_, i) => `- Built ${tag} module ${i} with many different words inside it today`).join('\n')}`;
  const r = await analyzeEditImpact({ v1Text: big('alpha'), v2Text: big('beta'), jdText: '' }, { yieldFn: noYield, maxWordEvals: 50 });
  assert.equal(r.ok, true);
  assert.equal(r.wordTruncated, true);
  assert.equal(r.sumTenths + r.interactionTenths, r.totalTenths);
});

/* ------------------------------ validation ---------------------------- */

test('validateInputs: empty, huge, junk and short inputs get friendly messages', () => {
  let v = validateInputs({ v1Text: '', v2Text: '   ', jdText: '' });
  assert.equal(v.ok, false);
  assert.match(v.errors.v1, /Resume v1/);
  assert.match(v.errors.v2, /Resume v2/);

  v = validateInputs({ v1Text: 'x '.repeat(30000), v2Text: DEMO_V2, jdText: '' });
  assert.equal(v.ok, false);
  assert.match(v.errors.v1, /too long/);

  v = validateInputs({ v1Text: '12345 67890', v2Text: DEMO_V2, jdText: '' });
  assert.equal(v.ok, false);
  assert.match(v.errors.v1, /readable text/);

  v = validateInputs({ v1Text: 'Alex Morgan\nSoftware engineer', v2Text: DEMO_V2, jdText: DEMO_JD });
  assert.equal(v.ok, true);
  assert.ok(v.warnings.some((w) => /very short/.test(w)));

  v = validateInputs({ v1Text: DEMO_V1, v2Text: DEMO_V2, jdText: 'the and of to a' });
  assert.equal(v.ok, true);
  assert.ok(v.warnings.some((w) => /No usable keywords/.test(w)));

  v = validateInputs({ v1Text: DEMO_V1, v2Text: DEMO_V2, jdText: 'y'.repeat(25000) });
  assert.equal(v.ok, false);
  assert.match(v.errors.jd, /too long/);

  v = validateInputs({});
  assert.equal(v.ok, false);
});

test('analyzeEditImpact never throws on bad input - it reports it', async () => {
  const r = await analyzeEditImpact({ v1Text: '', v2Text: DEMO_V2 }, { yieldFn: noYield });
  assert.equal(r.ok, false);
  assert.ok(r.validation.errors.v1);
  const r2 = await analyzeEditImpact(undefined, { yieldFn: noYield });
  assert.equal(r2.ok, false);
});

/* ------------------------------- next best ---------------------------- */

test('Next Best Edit: top 3, sorted by gain, all positive, none already applied', () => {
  const units = parseUnits(DEMO_V2);
  const best = computeNextBestEdits(units, DEMO_JD, { limit: 3 });
  assert.equal(best.length, 3);
  for (let i = 1; i < best.length; i += 1) assert.ok(best[i - 1].gainTenths >= best[i].gainTenths);
  for (const b of best) {
    assert.ok(b.gainTenths > 0);
    assert.equal(b.gain, b.gainTenths / 10);
    assert.ok(b.title.length > 5 && b.detail.length > 5);
  }
  assert.equal(new Set(best.map((b) => b.id)).size, 3);

  // A keyword that is already in the resume is never suggested.
  const suggested = best.filter((b) => b.type === 'keyword').map((b) => b.title);
  for (const t of suggested) assert.doesNotMatch(t, /"(Python|Docker|AWS|Kubernetes)"/);
});

test('Next Best Edit: suggestions disappear once they are applied (weak phrase fixed)', () => {
  const before = computeNextBestEdits(parseUnits(DEMO_V2), DEMO_JD, { limit: 20 });
  assert.ok(before.some((b) => b.type === 'weak'));
  const fixed = DEMO_V2.replaceAll('Assisted with', 'Supported');
  const after = computeNextBestEdits(parseUnits(fixed), DEMO_JD, { limit: 20 });
  assert.ok(!after.some((b) => b.type === 'weak'));
});

test('Next Best Edit: weak v1 suggests concrete fixes, tiny input does not crash', () => {
  const weak = computeNextBestEdits(parseUnits(DEMO_V1), DEMO_JD, { limit: 3 });
  assert.ok(weak.length === 3 && weak[0].gain >= weak[2].gain);
  assert.deepEqual(computeNextBestEdits(parseUnits(''), null), computeNextBestEdits([], null));
  const tiny = computeNextBestEdits(parseUnits('Hello world'), null);
  assert.ok(Array.isArray(tiny));
});

test('Next Best Edit works without a JD (no keyword suggestions)', () => {
  const best = computeNextBestEdits(parseUnits(DEMO_V1), null, { limit: 10 });
  assert.ok(best.length > 0);
  assert.ok(!best.some((b) => b.type === 'keyword'));
});
