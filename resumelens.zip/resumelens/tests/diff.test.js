import test from 'node:test';
import assert from 'node:assert/strict';

import {
  applyAll,
  applyAllExcept,
  applyChunks,
  applyNone,
  applyOnly,
  computeEditScript,
  diffWords,
  lcsOps,
} from '../src/engine/diff.js';
import { parseUnits, unitsToText } from '../src/engine/text.js';
import { DEMO_V1, DEMO_V2 } from '../src/engine/demoData.js';
import { mulberry32, mutateResume, randomResume } from './helpers.js';

const raws = (units) => units.map((u) => u.raw);

/** Brute-force LCS length for cross-checking lcsOps. */
function lcsLength(a, b) {
  const dp = Array.from({ length: a.length + 1 }, () => new Array(b.length + 1).fill(0));
  for (let i = 1; i <= a.length; i += 1) {
    for (let j = 1; j <= b.length; j += 1) {
      dp[i][j] = a[i - 1] === b[j - 1] ? dp[i - 1][j - 1] + 1 : Math.max(dp[i - 1][j], dp[i][j - 1]);
    }
  }
  return dp[a.length][b.length];
}

test('lcsOps: valid edit script and optimal length on random arrays', () => {
  const rand = mulberry32(42);
  for (let n = 0; n < 200; n += 1) {
    const mk = () => Array.from({ length: Math.floor(rand() * 9) }, () => String(Math.floor(rand() * 4)));
    const a = mk();
    const b = mk();
    const ops = lcsOps(a, b);
    const eq = ops.filter((o) => o.op === 'eq');
    assert.equal(eq.length, lcsLength(a, b));
    // replaying the ops rebuilds both sides
    assert.deepEqual(ops.filter((o) => o.op !== 'ins').map((o) => a[o.a]), a);
    assert.deepEqual(ops.filter((o) => o.op !== 'del').map((o) => b[o.b]), b);
  }
});

test('identical resumes: no chunks at all', () => {
  const u = parseUnits(DEMO_V1);
  const { script, chunks } = computeEditScript(u, parseUnits(DEMO_V1));
  assert.equal(chunks.length, 0);
  assert.equal(script.every((s) => s.type === 'eq'), true);
});

test('added / removed / changed bullets become separate chunks', () => {
  const a = parseUnits('EXPERIENCE\n- Built the billing API for the platform team\n- Fixed many bugs in the checkout flow\n- Ran the weekly release for the team');
  const b = parseUnits('EXPERIENCE\n- Built the billing API for the platform team and cut errors by 30%\n- Ran the weekly release for the team\n- Launched a new onboarding flow for new users');
  const { script, chunks } = computeEditScript(a, b);
  const kinds = chunks.map((c) => c.kind).sort();
  assert.ok(chunks.length >= 2);
  assert.ok(kinds.includes('changed'));
  assert.deepEqual(raws(applyNone(script)), raws(a));
  assert.deepEqual(raws(applyAll(script, chunks)), raws(b));
});

test('rewritten bullets in the same place are paired as "changed", not removed + added', () => {
  const a = parseUnits('EXPERIENCE\n- Responsible for building web application features\n- Worked on the API');
  const b = parseUnits('EXPERIENCE\n- Built dashboards used by 1,200 customers\n- Reduced API latency from 800ms to 250ms');
  const { chunks } = computeEditScript(a, b);
  assert.equal(chunks.length, 2);
  assert.ok(chunks.every((c) => c.kind === 'changed'));
});

test('a moved section is ONE "moved" chunk with scope "section"', () => {
  const a = parseUnits('SUMMARY\nEngineer.\nEXPERIENCE\n- Built APIs for the billing team\nEDUCATION\nB.S. Computer Science\nSKILLS\nPython, SQL, Git');
  const b = parseUnits('SUMMARY\nEngineer.\nSKILLS\nPython, SQL, Git\nEXPERIENCE\n- Built APIs for the billing team\nEDUCATION\nB.S. Computer Science');
  const { script, chunks } = computeEditScript(a, b);
  assert.equal(chunks.length, 1);
  assert.equal(chunks[0].kind, 'moved');
  assert.equal(chunks[0].scope, 'section');
  assert.deepEqual(raws(applyNone(script)), raws(a));
  assert.deepEqual(raws(applyAll(script, chunks)), raws(b));
});

test('a new section (heading + lines) is ONE added chunk; lone bullets stay separate', () => {
  const a = parseUnits('EXPERIENCE\n- Built APIs for the billing team');
  const b = parseUnits('EXPERIENCE\n- Built APIs for the billing team\n- Led a team of five engineers\n- Cut costs by 20% in one year\nPROJECTS\n- Launched a CLI tool\n- Built a Node.js service');
  const { chunks } = computeEditScript(a, b);
  const added = chunks.filter((c) => c.kind === 'added');
  assert.equal(added.length, 3);
  const section = added.find((c) => c.scope === 'section');
  assert.equal(section.newUnits.length, 3);
});

test('demo data: none -> v1, all -> v2, and every chunk can be applied or reverted alone', () => {
  const a = parseUnits(DEMO_V1);
  const b = parseUnits(DEMO_V2);
  const { script, chunks } = computeEditScript(a, b);
  assert.ok(chunks.length >= 8);
  assert.equal(unitsToText(applyNone(script)), unitsToText(a));
  assert.equal(unitsToText(applyAll(script, chunks)), unitsToText(b));
  for (const c of chunks) {
    const only = applyOnly(script, c.id);
    const except = applyAllExcept(script, chunks, c.id);
    // applying one chunk never loses or duplicates unrelated lines
    assert.equal(only.length, a.length - c.oldUnits.length + c.newUnits.length);
    assert.equal(except.length, b.length - c.newUnits.length + c.oldUnits.length);
  }
});

test('fuzz: invariants hold for 400 random v1/v2 pairs (and any chunk subset)', () => {
  const rand = mulberry32(7);
  for (let seed = 1; seed <= 400; seed += 1) {
    const textA = randomResume(seed);
    const textB = seed % 7 === 0 ? randomResume(seed + 1000) : mutateResume(textA, seed * 31);
    const a = parseUnits(textA);
    const b = parseUnits(textB);
    const { script, chunks } = computeEditScript(a, b);

    assert.deepEqual(raws(applyNone(script)), raws(a), `none seed ${seed}`);
    assert.deepEqual(raws(applyAll(script, chunks)), raws(b), `all seed ${seed}`);
    for (const it of script) if (it.type !== 'eq') assert.ok(it.chunk, `unassigned item seed ${seed}`);
    assert.equal(new Set(chunks.map((c) => c.id)).size, chunks.length);
    // the whole-document safety net must never be needed for ordinary input
    assert.ok(!chunks.some((c) => c.scope === 'document'), `fallback used seed ${seed}`);

    // any random subset yields only lines that exist in v1 or v2
    const universe = new Set([...raws(a), ...raws(b)]);
    const subset = new Set(chunks.filter(() => rand() < 0.5).map((c) => c.id));
    const mixed = applyChunks(script, subset);
    for (const u of mixed) assert.ok(universe.has(u.raw), `foreign line seed ${seed}`);
  }
});

test('large documents diff quickly (1,200 lines each, shifted)', () => {
  const lines = Array.from({ length: 1200 }, (_, i) => `- Delivered feature ${i} for team ${i % 17}`);
  const a = parseUnits(`EXPERIENCE\n${lines.join('\n')}`);
  const shifted = [...lines.slice(5), ...lines.slice(0, 5)].map((l, i) => (i % 97 === 0 ? `${l} (edited)` : l));
  const b = parseUnits(`EXPERIENCE\n${shifted.join('\n')}`);
  const t0 = performance.now();
  const { script, chunks } = computeEditScript(a, b);
  assert.ok(performance.now() - t0 < 4000, 'diff took too long');
  assert.deepEqual(raws(applyNone(script)), raws(a));
  assert.deepEqual(raws(applyAll(script, chunks)), raws(b));
});

test('diffWords marks inserted and deleted words', () => {
  const ops = diffWords('Worked on the API', 'Built the API fast');
  assert.deepEqual(ops.filter((o) => o.op === 'ins').map((o) => o.word), ['Built', 'fast']);
  assert.deepEqual(ops.filter((o) => o.op === 'del').map((o) => o.word), ['Worked', 'on']);
  assert.deepEqual(diffWords('', 'a b').map((o) => o.op), ['ins', 'ins']);
  assert.deepEqual(diffWords('a b', '').map((o) => o.op), ['del', 'del']);
});
