/**
 * lazy.js - the 3D scenes are loaded on demand (code splitting), so the first
 * paint of the site never waits for three.js. Always render these inside
 * <SafeScene> (which provides Suspense + the error fallback).
 */
import { lazy } from 'react';

export const BackdropScene = lazy(() => import('./BackdropScene.jsx'));
export const HeroRingScene = lazy(() => import('./HeroRingScene.jsx'));
export const ImpactBarsScene = lazy(() => import('./ImpactBarsScene.jsx'));
export const LoginOrbScene = lazy(() => import('./LoginOrbScene.jsx'));
