/**
 * SceneCanvas.jsx - the one place a react-three-fiber <Canvas> is created.
 *
 *  - transparent background so the page's dark theme shows through
 *  - capped pixel ratio (max 1.75) to keep 60fps on laptops and phones
 *  - "prefers-reduced-motion": frameloop="demand" -> it only draws when
 *    something changes, so the scene is a still picture
 *  - if the GPU context is lost it throws, and SafeScene's ErrorBoundary swaps
 *    in the 2D fallback
 */

import { useState } from 'react';
import { Canvas } from '@react-three/fiber';

export default function SceneCanvas({ children, camera, reduced = false, dpr = [1, 1.75], className, style, ...rest }) {
  const [lost, setLost] = useState(false);
  if (lost) throw new Error('The 3D view lost its graphics context.');

  return (
    <Canvas
      className={className}
      style={style}
      camera={camera}
      dpr={dpr}
      frameloop={reduced ? 'demand' : 'always'}
      gl={{ antialias: true, alpha: true, powerPreference: 'default' }}
      onCreated={({ gl }) => {
        gl.setClearColor(0x000000, 0);
        gl.domElement.addEventListener(
          'webglcontextlost',
          (event) => {
            event.preventDefault();
            setLost(true);
          },
          { once: true },
        );
      }}
      {...rest}
    >
      {children}
    </Canvas>
  );
}
