/**
 * BackdropScene.jsx - floating background particles (two soft clouds).
 * Lightweight: one draw call per cloud, no lights, no textures.
 */

import { useEffect, useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { BufferAttribute, BufferGeometry } from 'three';
import SceneCanvas from './SceneCanvas.jsx';
import { makeParticles } from './math.js';
import { usePointer } from './usePointer.js';

function Cloud({ count, seed, color, size, speed, reduced }) {
  const group = useRef(null);
  const pointer = usePointer();

  const geometry = useMemo(() => {
    const g = new BufferGeometry();
    g.setAttribute('position', new BufferAttribute(makeParticles(count, seed, { x: 18, y: 11, z: 9 }), 3));
    return g;
  }, [count, seed]);

  // Free GPU memory when the cloud goes away.
  useEffect(() => () => geometry.dispose(), [geometry]);

  useFrame((state, delta) => {
    const g = group.current;
    if (!g || reduced) return;
    const ease = Math.min(1, delta * 1.5);
    g.rotation.y += delta * speed;
    g.rotation.x += (pointer.current.y * 0.12 - g.rotation.x) * ease;
    g.position.x += (pointer.current.x * 0.45 - g.position.x) * ease;
    g.position.y = Math.sin(state.clock.elapsedTime * 0.25 + seed) * 0.15;
  });

  return (
    <group ref={group}>
      <points geometry={geometry}>
        <pointsMaterial size={size} color={color} transparent opacity={0.8} sizeAttenuation depthWrite={false} />
      </points>
    </group>
  );
}

export default function BackdropScene({ count = 140, reduced = false }) {
  return (
    <SceneCanvas camera={{ position: [0, 0, 7], fov: 55 }} reduced={reduced} dpr={[1, 1.5]} aria-hidden="true">
      <Cloud count={count} seed={7} color="#7dd3fc" size={0.055} speed={0.025} reduced={reduced} />
      <Cloud count={Math.round(count * 0.4)} seed={21} color="#34d399" size={0.07} speed={-0.018} reduced={reduced} />
    </SceneCanvas>
  );
}
