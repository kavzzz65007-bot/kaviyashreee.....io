/**
 * usePointer.js - the mouse position over the whole window as a ref.
 * ref.current = { x, y } with both in -1..1 (x: left->right, y: bottom->top).
 * Scenes read it every frame for parallax; nothing re-renders when it changes.
 */
import { useEffect, useRef } from 'react';

export function usePointer() {
  const pointer = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const onMove = (e) => {
      const w = window.innerWidth || 1;
      const h = window.innerHeight || 1;
      pointer.current.x = (e.clientX / w) * 2 - 1;
      pointer.current.y = -((e.clientY / h) * 2 - 1);
    };
    window.addEventListener('pointermove', onMove, { passive: true });
    return () => window.removeEventListener('pointermove', onMove);
  }, []);

  return pointer;
}
