/**
 * math.js  (3D helpers - PURE functions, no three.js import)
 * ---------------------------------------------------------------------------
 * All the numeric work behind the 3D scenes lives here, away from React and
 * WebGL, so it can be unit-tested in plain Node:
 *
 *   - seeded particle positions          (makeParticles)
 *   - the gauge arc as a tube mesh       (buildArcTube + drawCountForProgress)
 *   - score colour + easing              (ringColor, easeOutCubic)
 *   - 3D bar chart layout                (layoutBars)
 *
 * The React components in this folder only wrap these results in meshes.
 */

export const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

/** Small deterministic PRNG (same seed -> same sequence). */
export function mulberry32(seed) {
  let a = seed >>> 0;
  return function next() {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Random-looking but reproducible particle cloud: Float32Array [x,y,z, x,y,z ...]. */
export function makeParticles(count, seed = 1, spread = { x: 14, y: 8, z: 8 }) {
  const n = Math.max(0, Math.floor(count));
  const rand = mulberry32(seed);
  const out = new Float32Array(n * 3);
  for (let i = 0; i < n; i += 1) {
    out[i * 3] = (rand() - 0.5) * spread.x;
    out[i * 3 + 1] = (rand() - 0.5) * spread.y;
    out[i * 3 + 2] = (rand() - 0.5) * spread.z - 1;
  }
  return out;
}

export const easeOutCubic = (t) => 1 - (1 - clamp(t, 0, 1)) ** 3;

/** Score -> colour (red below 50, amber below 70, green from 70, blended between stops). */
export function ringColor(score) {
  const s = clamp(Number.isFinite(score) ? score : 0, 0, 100);
  const stops = [
    [0, [248, 113, 113]], // red-400
    [50, [251, 191, 36]], // amber-400
    [75, [52, 211, 153]], // emerald-400
    [100, [45, 212, 191]], // teal-400
  ];
  let lo = stops[0];
  let hi = stops[stops.length - 1];
  for (let i = 1; i < stops.length; i += 1) {
    if (s <= stops[i][0]) {
      lo = stops[i - 1];
      hi = stops[i];
      break;
    }
  }
  const t = hi[0] === lo[0] ? 0 : (s - lo[0]) / (hi[0] - lo[0]);
  const c = lo[1].map((v, i) => Math.round(v + (hi[1][i] - v) * t));
  return `#${c.map((v) => v.toString(16).padStart(2, '0')).join('')}`;
}

/**
 * Build the gauge arc as an indexed tube: a circle of radius `radius` swept
 * clockwise from `startAngle` (top of the circle by default).
 *
 * Triangles are ordered ALONG the path (segment by segment), so revealing the
 * first N indices reveals the first N/segments of the arc. That lets the gauge
 * "fill" by simply calling geometry.setDrawRange(0, count) every frame -
 * no geometry is rebuilt while animating.
 */
export function buildArcTube({
  radius = 1.6,
  tube = 0.14,
  segments = 160,
  radialSegments = 14,
  startAngle = Math.PI / 2,
} = {}) {
  const vertexCount = (segments + 1) * radialSegments;
  const positions = new Float32Array(vertexCount * 3);
  const normals = new Float32Array(vertexCount * 3);

  for (let s = 0; s <= segments; s += 1) {
    const a = startAngle - (s / segments) * Math.PI * 2;
    const cx = Math.cos(a);
    const cy = Math.sin(a);
    for (let k = 0; k < radialSegments; k += 1) {
      const phi = (k / radialSegments) * Math.PI * 2;
      const nx = Math.cos(phi) * cx;
      const ny = Math.cos(phi) * cy;
      const nz = Math.sin(phi);
      const i = (s * radialSegments + k) * 3;
      positions[i] = radius * cx + tube * nx;
      positions[i + 1] = radius * cy + tube * ny;
      positions[i + 2] = tube * nz;
      normals[i] = nx;
      normals[i + 1] = ny;
      normals[i + 2] = nz;
    }
  }

  const indicesPerSegment = radialSegments * 6;
  const IndexArray = vertexCount < 65536 ? Uint16Array : Uint32Array;
  const indices = new IndexArray(segments * indicesPerSegment);
  let w = 0;
  for (let s = 0; s < segments; s += 1) {
    for (let k = 0; k < radialSegments; k += 1) {
      const a = s * radialSegments + k;
      const b = s * radialSegments + ((k + 1) % radialSegments);
      const c = (s + 1) * radialSegments + k;
      const d = (s + 1) * radialSegments + ((k + 1) % radialSegments);
      // Counter-clockwise when seen from outside the tube (verified in tests).
      indices[w] = a;
      indices[w + 1] = b;
      indices[w + 2] = c;
      indices[w + 3] = b;
      indices[w + 4] = d;
      indices[w + 5] = c;
      w += 6;
    }
  }

  return { positions, normals, indices, segments, radialSegments, indicesPerSegment, vertexCount, radius, startAngle };
}

/** How many indices to draw so that `progress` (0..1) of the arc is visible. */
export function drawCountForProgress(progress, data) {
  const whole = Math.floor(clamp(progress, 0, 1) * data.segments);
  return whole * data.indicesPerSegment;
}

/** Centre-line point of the arc at `progress` (0..1) - used to place the glowing end cap. */
export function arcPoint(progress, radius, startAngle = Math.PI / 2) {
  const a = startAngle - clamp(progress, 0, 1) * Math.PI * 2;
  return { x: radius * Math.cos(a), y: radius * Math.sin(a) };
}

/**
 * Lay out the 3D impact bars.
 * items: [{ id, tag, deltaTenths, kind: 'chunk' | 'interaction' }]
 * When there are more items than `maxBars`, the biggest movers (by |delta|)
 * are kept - the interaction bar is always kept - and `hidden` says how many
 * were left out. The full list is always shown in the table next to the chart.
 */
export function layoutBars(items, { maxBars = 12, spacing = 1.05, maxHeight = 2.4, minHeight = 0.1 } = {}) {
  const list = Array.isArray(items) ? items : [];
  let kept = list.map((it, index) => ({ ...it, index }));
  if (kept.length > maxBars) {
    const must = kept.filter((it) => it.kind === 'interaction');
    const rest = kept
      .filter((it) => it.kind !== 'interaction')
      .sort((a, b) => Math.abs(b.deltaTenths) - Math.abs(a.deltaTenths) || a.index - b.index)
      .slice(0, Math.max(0, maxBars - must.length));
    kept = [...rest, ...must].sort((a, b) => a.index - b.index);
  }
  const hidden = list.length - kept.length;
  const maxAbs = kept.reduce((m, it) => Math.max(m, Math.abs(it.deltaTenths)), 0);
  const scale = maxAbs > 0 ? maxHeight / maxAbs : 0;
  const n = kept.length;

  const bars = kept.map((it, i) => {
    const d = it.deltaTenths;
    let height = 0;
    if (d !== 0) height = Math.sign(d) * Math.max(minHeight, Math.abs(d) * scale);
    let tone = 'flat';
    if (it.kind === 'interaction') tone = 'neutral';
    else if (d > 0) tone = 'up';
    else if (d < 0) tone = 'down';
    return {
      id: it.id,
      tag: it.tag,
      deltaTenths: d,
      kind: it.kind,
      tone,
      height,
      x: (i - (n - 1) / 2) * spacing,
    };
  });

  return { bars, hidden, width: Math.max(1, n) * spacing, maxHeight };
}
