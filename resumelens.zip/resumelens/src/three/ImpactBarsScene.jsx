/**
 * ImpactBarsScene.jsx - 3D bar columns: one per edit, green up / red down,
 * each labelled with its edit. The grey-violet bar is the interaction effect.
 *
 * Layout maths (heights, x positions, which bars to keep) is in math.js
 * layoutBars(); this file only turns that layout into meshes.
 * Labels use drei <Html>, so they are real DOM text (crisp, selectable).
 */

import { useEffect, useMemo, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import SceneCanvas from './SceneCanvas.jsx';
import { easeOutCubic, layoutBars } from './math.js';
import { usePointer } from './usePointer.js';
import { formatDeltaTenths } from '../engine/scoring.js';

const FILL = { up: '#34d399', down: '#f87171', neutral: '#a78bfa', flat: '#94a3b8' };
const TEXT = { up: '#6ee7b7', down: '#fca5a5', neutral: '#c4b5fd', flat: '#cbd5e1' };
const GROW_SECONDS = 0.9;

/** Keeps the whole chart in view whatever the canvas size and number of bars. */
function FitCamera({ width, maxHeight }) {
  const camera = useThree((s) => s.camera);
  const size = useThree((s) => s.size);
  const invalidate = useThree((s) => s.invalidate);

  useEffect(() => {
    const aspect = size.width / Math.max(1, size.height);
    const k = 2 * Math.tan(((camera.fov || 40) * Math.PI) / 360);
    const needH = maxHeight * 2 + 2.6;
    const needW = width + 1.6;
    const distance = Math.max(needH / k, needW / (k * aspect)) + 0.8;
    camera.position.set(0, 0.5, distance);
    camera.lookAt(0, 0, 0);
    camera.updateProjectionMatrix();
    invalidate();
  }, [camera, size.width, size.height, width, maxHeight, invalidate]);

  return null;
}

function Bar({ bar, index, reduced }) {
  const mesh = useRef(null);
  const startAt = useRef(null);

  const full = Math.abs(bar.height) || 0.04; // zero-change bars are drawn as a thin slab
  const dir = bar.height < 0 ? -1 : 1;

  const grow = (p) => {
    const m = mesh.current;
    if (!m) return;
    const h = Math.max(0.0001, full * p);
    m.scale.y = h;
    m.position.y = (dir * h) / 2;
  };

  useFrame((state) => {
    if (reduced) return;
    if (startAt.current === null) startAt.current = state.clock.elapsedTime + index * 0.07;
    grow(easeOutCubic((state.clock.elapsedTime - startAt.current) / GROW_SECONDS));
  });

  useEffect(() => {
    if (reduced) grow(1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reduced, full, dir]);

  const color = FILL[bar.tone] || FILL.flat;
  const labelY = bar.height < 0 ? bar.height - 0.62 : (bar.height || 0.04) + 0.62;

  return (
    <group position={[bar.x, 0, 0]}>
      <mesh ref={mesh} scale={[1, reduced ? full : 0.0001, 1]} position={[0, reduced ? (dir * full) / 2 : 0, 0]}>
        <boxGeometry args={[0.62, 1, 0.62]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.25} roughness={0.35} metalness={0.15} />
      </mesh>
      <Html position={[0, labelY, 0]} center zIndexRange={[10, 0]} style={{ pointerEvents: 'none' }}>
        <div className="bar-label fade-in">
          <strong style={{ color: TEXT[bar.tone] || TEXT.flat }}>{formatDeltaTenths(bar.deltaTenths)}</strong>
          <span title={bar.tag}>{bar.tag}</span>
        </div>
      </Html>
    </group>
  );
}

function Chart({ layout, reduced }) {
  const group = useRef(null);
  const pointer = usePointer();

  useFrame((state, delta) => {
    const g = group.current;
    if (!g || reduced) return;
    const turn = pointer.current.x * 0.35 + Math.sin(state.clock.elapsedTime * 0.5) * 0.12;
    g.rotation.y += (turn - g.rotation.y) * Math.min(1, delta * 2.5);
  });

  return (
    <group ref={group} rotation={[0.16, -0.2, 0]}>
      <mesh position={[0, -0.01, 0]}>
        <boxGeometry args={[layout.width + 0.4, 0.02, 0.9]} />
        <meshStandardMaterial color="#475569" roughness={0.8} />
      </mesh>
      {layout.bars.map((bar, i) => (
        <Bar key={bar.id} bar={bar} index={i} reduced={reduced} />
      ))}
    </group>
  );
}

/**
 * @param {{ items: Array<{id:string, tag:string, deltaTenths:number, kind:'chunk'|'interaction'}>, reduced?: boolean }} props
 * `items` must be memoised by the caller.
 */
export default function ImpactBarsScene({ items, reduced = false }) {
  const layout = useMemo(() => layoutBars(items), [items]);
  return (
    <SceneCanvas camera={{ position: [0, 0.5, 10], fov: 38 }} reduced={reduced}>
      <ambientLight intensity={0.9} />
      <directionalLight position={[4, 6, 6]} intensity={2.4} />
      <FitCamera width={layout.width} maxHeight={layout.maxHeight} />
      <Chart layout={layout} reduced={reduced} />
    </SceneCanvas>
  );
}
