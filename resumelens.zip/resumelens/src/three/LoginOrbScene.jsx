/**
 * LoginOrbScene.jsx - the 3D login centrepiece: a glowing core inside a
 * wireframe shell with three orbiting rings. It follows the mouse, spins up
 * while signing in, shakes on an error and swells on success.
 */

import { useEffect, useMemo, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { Color } from 'three';
import SceneCanvas from './SceneCanvas.jsx';
import { usePointer } from './usePointer.js';

const STATUS_COLOR = { idle: '#38bdf8', busy: '#a78bfa', error: '#f87171', success: '#34d399' };
const RINGS = [
  { radius: 1.75, tilt: [1.2, 0.2, 0], speed: 0.5 },
  { radius: 2.05, tilt: [0.3, 1.1, 0.4], speed: -0.38 },
  { radius: 2.35, tilt: [-0.7, 0.4, 1.0], speed: 0.27 },
];

function Orb({ status, reduced }) {
  const invalidate = useThree((s) => s.invalidate);
  const pointer = usePointer();

  const group = useRef(null);
  const spin = useRef(null);
  const core = useRef(null);
  const coreMat = useRef(null);
  const shellMat = useRef(null);
  const ringMats = useRef([]);
  const ringGroups = useRef([]);
  const shake = useRef(0);
  const swell = useRef(1);

  const target = useMemo(() => new Color(STATUS_COLOR[status] || STATUS_COLOR.idle), [status]);
  const current = useMemo(() => new Color(STATUS_COLOR.idle), []);

  const paint = () => {
    if (coreMat.current) {
      coreMat.current.color.copy(current);
      coreMat.current.emissive.copy(current);
    }
    if (shellMat.current) shellMat.current.color.copy(current);
    ringMats.current.forEach((m) => m && m.color.copy(current));
  };

  useEffect(() => {
    if (status === 'error') shake.current = 1;
    if (reduced) {
      current.copy(target);
      paint();
      invalidate();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, reduced, target]);

  useFrame((state, delta) => {
    if (reduced) return;
    const t = state.clock.elapsedTime;
    current.lerp(target, Math.min(1, delta * 4));
    paint();

    const g = group.current;
    if (g) {
      const ease = Math.min(1, delta * 3);
      g.rotation.y += (pointer.current.x * 0.5 - g.rotation.y) * ease;
      g.rotation.x += (-pointer.current.y * 0.35 - g.rotation.x) * ease;
      shake.current = Math.max(0, shake.current - delta * 1.8);
      g.position.x = Math.sin(t * 50) * 0.14 * shake.current;
      g.position.y = Math.sin(t * 0.9) * 0.08;
      const wantScale = status === 'success' ? 1.18 : 1;
      swell.current += (wantScale - swell.current) * Math.min(1, delta * 4);
      g.scale.setScalar(swell.current);
    }

    const speed = status === 'busy' ? 2.2 : 0.35;
    if (spin.current) spin.current.rotation.y += delta * speed;
    if (core.current) core.current.scale.setScalar(1 + Math.sin(t * 2) * 0.03);
    ringGroups.current.forEach((rg, i) => {
      if (rg) rg.rotation.z += delta * RINGS[i].speed * (status === 'busy' ? 4 : 1);
    });
  });

  return (
    <group ref={group}>
      <mesh ref={core}>
        <icosahedronGeometry args={[0.85, 3]} />
        <meshStandardMaterial ref={coreMat} color={STATUS_COLOR.idle} emissive={STATUS_COLOR.idle} emissiveIntensity={0.7} roughness={0.25} metalness={0.3} />
      </mesh>
      <mesh ref={spin}>
        <icosahedronGeometry args={[1.25, 1]} />
        <meshBasicMaterial ref={shellMat} color={STATUS_COLOR.idle} wireframe transparent opacity={0.55} />
      </mesh>
      {RINGS.map((ring, i) => (
        <group key={ring.radius} rotation={ring.tilt}>
          <group ref={(el) => { ringGroups.current[i] = el; }}>
            <mesh>
              <torusGeometry args={[ring.radius, 0.012, 8, 140]} />
              <meshBasicMaterial ref={(el) => { ringMats.current[i] = el; }} color={STATUS_COLOR.idle} transparent opacity={0.6} />
            </mesh>
            <mesh position={[ring.radius, 0, 0]}>
              <sphereGeometry args={[0.06, 12, 12]} />
              <meshBasicMaterial color="#e0f2fe" />
            </mesh>
          </group>
        </group>
      ))}
    </group>
  );
}

export default function LoginOrbScene({ status = 'idle', reduced = false }) {
  return (
    <SceneCanvas camera={{ position: [0, 0, 6.2], fov: 45 }} reduced={reduced} aria-hidden="true">
      <ambientLight intensity={0.7} />
      <directionalLight position={[3, 4, 5]} intensity={2} />
      <Orb status={status} reduced={reduced} />
    </SceneCanvas>
  );
}
