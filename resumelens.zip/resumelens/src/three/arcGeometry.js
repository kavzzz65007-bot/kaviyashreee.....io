/**
 * arcGeometry.js - turns the pure arc data from math.js into a three.js geometry.
 * Every caller gets its OWN geometry (setDrawRange is per geometry), and must
 * call geometry.dispose() when it unmounts.
 */
import { BufferAttribute, BufferGeometry } from 'three';

export function makeArcGeometry(data) {
  const geometry = new BufferGeometry();
  geometry.setAttribute('position', new BufferAttribute(data.positions, 3));
  geometry.setAttribute('normal', new BufferAttribute(data.normals, 3));
  geometry.setIndex(new BufferAttribute(data.indices, 1));
  return geometry;
}
