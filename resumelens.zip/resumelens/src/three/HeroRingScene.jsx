/**
 * HeroRingScene.jsx - the 3D score ring on the landing page.
 *
 * The coloured arc is ONE tube mesh whose triangles are ordered along the
 * path (see math.js buildArcTube). Filling the ring is just
 * geometry.setDrawRange(0, n) - no geometry is rebuilt while it animates.
 * A glowing ball rides the end of the arc.
 */

import { useEffect, useMemo, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import SceneCanvas from './SceneCanvas.jsx';
import { makeArcGeometry } from './arcGeometry.js';
import { arcPoint, buildArcTube, clamp, drawCountForProgress, easeOutCubic, ringColor } from './math.js';
import { usePointer } from './usePointer.js';

const RADIUS = 1.5;
const FILL_SECONDS = 1.6;

function Gauge({ score, reduced }) {
  const invalidate = useThree((s) => s.invalidate);
  const data = useMemo(() => buildArcTube({ radius: RADIUS, tube: 0.17, segments: 180, radialSegments: 16 }), []);
  const trackGeometry = useMemo(() => makeArcGeometry(data), [data]);
  const fillGeometry = useMemo(() => {
    const g = makeArcGeometry(data);
    g.setDrawRange(0, 0); // start empty so the first frame never flashes a full ring
    return g;
  }, [data]);

  useEffect(() => () => trackGeometry.dispose(), [trackGeometry]);
  useEffect(() => () => fillGeometry.dispose(), [fillGeometry]);

  const group = useRef(null);
  const cap = useRef(null);
  const halo = useRef(null);
  const anim = useRef({ from: 0, to: 0, start: null, value: 0 });
  const pointer = usePointer();

  const target = clamp(Number.isFinite(score) ? score : 0, 0, 100) / 100;
  const color = ringColor(score);

  const show = (progress) => {
    fillGeometry.setDrawRange(0, drawCountForProgress(progress, data));
    const dot = cap.current;
    if (dot) {
      const p = arcPoint(progress, RADIUS);
      dot.position.set(p.x, p.y, 0);
      dot.visible = progress > 0.004;
    }
  };

  // New score: restart the fill from wherever it currently is.
  useEffect(() => {
    const a = anim.current;
    a.from = a.value;
    a.to = target;
    a.start = null;
    if (reduced) {
      a.value = target;
      show(target);
      invalidate();
    }
    // `show` only touches stable refs/geometries, so it is safe to leave out.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [target, reduced]);

  useFrame((state, delta) => {
    if (reduced) return;
    const a = anim.current;
    const t = state.clock.elapsedTime;
    if (a.start === null) a.start = t;
    a.value = a.from + (a.to - a.from) * easeOutCubic((t - a.start) / FILL_SECONDS);
    show(a.value);

    const g = group.current;
    if (g) {
      const ease = Math.min(1, delta * 3);
      g.rotation.y += (pointer.current.x * 0.4 - g.rotation.y) * ease;
      g.rotation.x += (-pointer.current.y * 0.3 - g.rotation.x) * ease;
      g.position.y = Math.sin(t * 0.9) * 0.06;
    }
    if (halo.current) halo.current.rotation.z += delta * 0.15;
  });

  return (
    <group ref={group}>
      <mesh geometry={trackGeometry}>
        <meshStandardMaterial color="#1e293b" roughness={0.6} metalness={0.1} />
      </mesh>
      <mesh geometry={fillGeometry}>
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.5} roughness={0.3} metalness={0.25} />
      </mesh>
      <mesh ref={cap} visible={false}>
        <sphereGeometry args={[0.25, 24, 24]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={1.2} />
      </mesh>
      <mesh ref={halo} rotation={[0.45, 0, 0]}>
        <torusGeometry args={[2.1, 0.012, 8, 160]} />
        <meshBasicMaterial color="#38bdf8" transparent opacity={0.4} />
      </mesh>
    </group>
  );
}

export default function HeroRingScene({ score = 0, reduced = false }) {
  return (
    <SceneCanvas camera={{ position: [0, 0, 5.8], fov: 45 }} reduced={reduced} aria-hidden="true">
      <ambientLight intensity={0.9} />
      <directionalLight position={[3, 4, 5]} intensity={2.2} />
      <Gauge score={score} reduced={reduced} />
    </SceneCanvas>
  );
}
