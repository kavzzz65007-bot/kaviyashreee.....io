/**
 * App.jsx - the shell: backdrop, header, the current page, footer.
 *
 * Routing is a tiny hash router (#/, #/login, #/app) so it works on GitHub
 * Pages with no server settings. The tracker needs a profile (guest counts);
 * visiting it without one redirects to the 3D login.
 */

import { useEffect } from 'react';
import Backdrop from './components/Backdrop.jsx';
import ErrorBoundary from './components/ErrorBoundary.jsx';
import Footer from './components/Footer.jsx';
import Header from './components/Header.jsx';
import PageTransition from './components/PageTransition.jsx';
import { AuthProvider, useAuth } from './lib/AuthContext.jsx';
import { navigate, useRoute } from './lib/hooks.js';
import Home from './pages/Home.jsx';
import Login from './pages/Login.jsx';
import Tracker from './pages/Tracker.jsx';

const TITLES = {
  home: 'ResumeLens - see which edits moved your resume score',
  login: 'Sign in - ResumeLens',
  app: 'Edit Impact Tracker - ResumeLens',
};

function Shell() {
  const route = useRoute();
  const { session } = useAuth();
  const page = route === 'app' && !session ? 'login' : route;

  // Not signed in -> send the address bar to the login page too.
  useEffect(() => {
    if (route === 'app' && !session) navigate('login', { replace: true });
  }, [route, session]);

  useEffect(() => {
    document.title = TITLES[page] || TITLES.home;
    window.scrollTo(0, 0);
  }, [page]);

  // Key by profile so switching account always starts with that account's data.
  const profileKey = session ? session.profile : 'none';

  return (
    <div className="relative min-h-screen">
      <Backdrop />
      <Header route={page} />
      <main className="relative z-10">
        <ErrorBoundary resetKey={page}>
          <PageTransition routeKey={page}>
            {page === 'home' ? <Home /> : null}
            {page === 'login' ? <Login /> : null}
            {page === 'app' ? <Tracker key={profileKey} /> : null}
          </PageTransition>
        </ErrorBoundary>
      </main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <Shell />
      </AuthProvider>
    </ErrorBoundary>
  );
}
