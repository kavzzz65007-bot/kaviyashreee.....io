/**
 * Login.jsx - the 3D login screen.
 *
 * Left: a 3D orb that follows the mouse, spins while signing in, shakes on an
 * error and swells on success (flat CSS orb if WebGL is unavailable).
 * Right: a tilting glass card with Sign in / Create account / Guest.
 *
 * REMINDER: accounts are stored only in this browser (see lib/auth.js). This
 * keeps people's saved resumes apart on a shared computer; it is not real
 * security, and the page says so.
 */

import { useEffect, useRef, useState } from 'react';
import SafeScene from '../components/SafeScene.jsx';
import TiltCard from '../components/TiltCard.jsx';
import { Alert, Spinner } from '../components/ui.jsx';
import { PASSWORD_MIN, USERNAME_RULE } from '../lib/auth.js';
import { useAuth } from '../lib/AuthContext.jsx';
import { navigate, useReducedMotion } from '../lib/hooks.js';
import { LoginOrbScene } from '../three/lazy.js';

const STATUS_TEXT = {
  idle: 'Move your mouse - the orb follows.',
  busy: 'Checking…',
  error: 'That did not work.',
  success: 'Welcome!',
};

export default function Login() {
  const { session, login, register, guest, logout } = useAuth();
  const reduced = useReducedMotion();

  const [mode, setMode] = useState('signin'); // 'signin' | 'register'
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  const mounted = useRef(true);
  const timer = useRef(0);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      clearTimeout(timer.current);
    };
  }, []);

  const status = busy ? 'busy' : done ? 'success' : error ? 'error' : 'idle';

  const finish = () => {
    setDone(true);
    timer.current = setTimeout(() => navigate('app'), reduced ? 0 : 650);
  };

  const submit = async (e) => {
    e.preventDefault();
    if (busy || done) return;
    setError('');
    setBusy(true);
    let result;
    try {
      result = await (mode === 'signin' ? login : register)(username, password);
    } catch {
      result = { ok: false, error: 'Something went wrong. Please try again.' };
    }
    if (!mounted.current) return;
    setBusy(false);
    if (!result.ok) {
      setError(result.error || 'Something went wrong. Please try again.');
      return;
    }
    finish();
  };

  const continueAsGuest = () => {
    if (busy || done) return;
    guest();
    finish();
  };

  const switchMode = (next) => {
    setMode(next);
    setError('');
  };

  const signedInPanel = Boolean(session) && !done && !busy;

  return (
    <div className="mx-auto grid max-w-5xl items-center gap-6 px-4 py-8 sm:px-6 md:grid-cols-2 md:py-14">
      {/* ------------------------------ 3D orb ----------------------------- */}
      <div>
        <div className="relative mx-auto h-44 w-full max-w-md sm:h-60 md:h-[26rem]" role="img" aria-label="Decorative 3D orb">
          <SafeScene
            fallback={
              <div className="grid h-full place-items-center">
                <div className={`orb-2d ${status === 'error' ? 'orb-2d-error' : ''} ${status === 'success' ? 'orb-2d-ok' : ''}`} />
              </div>
            }
            loading={<div className="grid h-full place-items-center text-sm text-slate-500">Loading 3D…</div>}
          >
            <LoginOrbScene status={status} reduced={reduced} />
          </SafeScene>
        </div>
        <p className="mt-1 text-center text-xs text-slate-500" aria-hidden="true">
          {STATUS_TEXT[status]}
        </p>
      </div>

      {/* ------------------------------ form ------------------------------- */}
      <TiltCard max={3} className="p-5 sm:p-7">
        {signedInPanel ? (
          <div className="text-center">
            <h1 className="text-2xl font-extrabold text-white">You&apos;re signed in</h1>
            <p className="mt-2 text-sm text-slate-400">
              Signed in as <strong className="text-slate-100">{session.guest ? 'Guest' : session.username}</strong>.
            </p>
            <div className="mt-6 flex flex-col gap-2">
              <button type="button" className="btn btn-primary" onClick={() => navigate('app')}>
                Open the tracker
              </button>
              <button type="button" className="btn btn-secondary" onClick={logout}>
                Sign out / switch account
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={submit} noValidate aria-describedby="local-note">
            <h1 className="text-2xl font-extrabold tracking-tight text-white">{mode === 'signin' ? 'Welcome back' : 'Create your profile'}</h1>
            <p className="mt-1 text-sm text-slate-400">{mode === 'signin' ? 'Sign in to open your saved resume versions.' : 'Pick a username and password to keep your versions separate.'}</p>

            <div className="mt-4 grid grid-cols-2 gap-1 rounded-xl bg-black/30 p-1" role="group" aria-label="Sign in or create account">
              {[
                ['signin', 'Sign in'],
                ['register', 'Create account'],
              ].map(([key, text]) => (
                <button
                  key={key}
                  type="button"
                  aria-pressed={mode === key}
                  disabled={busy || done}
                  onClick={() => switchMode(key)}
                  className={`rounded-lg px-3 py-1.5 text-sm font-semibold transition-colors ${mode === key ? 'bg-white/12 text-white' : 'text-slate-400 hover:text-white'}`}
                >
                  {text}
                </button>
              ))}
            </div>

            <div className="mt-4 space-y-3">
              <div>
                <label htmlFor="login-username" className="mb-1 block text-sm font-semibold text-slate-200">
                  Username
                </label>
                <input
                  id="login-username"
                  className="field"
                  type="text"
                  autoComplete="username"
                  autoCapitalize="none"
                  spellCheck={false}
                  value={username}
                  disabled={busy || done}
                  aria-invalid={error ? 'true' : 'false'}
                  aria-describedby={mode === 'register' ? 'username-rule' : undefined}
                  onChange={(e) => {
                    setUsername(e.target.value);
                    setError('');
                  }}
                />
                {mode === 'register' ? (
                  <p id="username-rule" className="mt-1 text-xs text-slate-500">
                    {USERNAME_RULE}
                  </p>
                ) : null}
              </div>

              <div>
                <label htmlFor="login-password" className="mb-1 block text-sm font-semibold text-slate-200">
                  Password
                </label>
                <div className="relative">
                  <input
                    id="login-password"
                    className="field pr-16"
                    type={showPw ? 'text' : 'password'}
                    autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
                    value={password}
                    disabled={busy || done}
                    aria-invalid={error ? 'true' : 'false'}
                    aria-describedby={mode === 'register' ? 'password-rule' : undefined}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setError('');
                    }}
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-2 my-auto h-8 rounded-md px-2 text-xs font-semibold text-slate-400 hover:text-white"
                    aria-pressed={showPw}
                    onClick={() => setShowPw((v) => !v)}
                  >
                    {showPw ? 'Hide' : 'Show'}
                  </button>
                </div>
                {mode === 'register' ? (
                  <p id="password-rule" className="mt-1 text-xs text-slate-500">
                    At least {PASSWORD_MIN} characters. Do not reuse a real password.
                  </p>
                ) : null}
              </div>
            </div>

            <div className="mt-3 space-y-2" aria-live="polite">
              {error ? <Alert tone="error">{error}</Alert> : null}
              {done ? <Alert tone="success">Signed in. Opening the tracker…</Alert> : null}
            </div>

            <button type="submit" className="btn btn-primary mt-2 w-full !py-2.5" disabled={busy || done} aria-busy={busy}>
              {busy ? <Spinner /> : null}
              {busy ? 'Please wait…' : mode === 'signin' ? 'Sign in' : 'Create account'}
            </button>

            <div className="my-4 flex items-center gap-3 text-xs text-slate-500">
              <span className="h-px flex-1 bg-white/10" />
              or
              <span className="h-px flex-1 bg-white/10" />
            </div>

            <button type="button" className="btn btn-secondary w-full" disabled={busy || done} onClick={continueAsGuest}>
              Continue as guest
            </button>

            <p id="local-note" className="mt-4 text-xs leading-relaxed text-slate-500">
              Heads up: there is no server. Your profile lives only in this browser (the password is hashed, but anyone using this browser profile could still read or delete it). It exists to keep saved resumes apart on a shared computer, not to protect secrets.
            </p>
          </form>
        )}
      </TiltCard>
    </div>
  );
}
