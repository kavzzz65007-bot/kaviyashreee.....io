/**
 * Home.jsx - the landing page: hero with the animated 3D score ring, how it
 * works, features, and the scoring rubric.
 */

import { useMemo } from 'react';
import HeroScore from '../components/HeroScore.jsx';
import TiltCard from '../components/TiltCard.jsx';
import { SectionHeading } from '../components/ui.jsx';
import { WEIGHTS_NO_JD, WEIGHTS_WITH_JD, CATEGORY_META } from '../engine/constants.js';
import { DEMO_JD, DEMO_V2 } from '../engine/demoData.js';
import { scoreResume } from '../engine/scoring.js';
import { useAuth } from '../lib/AuthContext.jsx';
import { navigate } from '../lib/hooks.js';

const STEPS = [
  { n: '1', title: 'Add two versions', text: 'Paste or upload your old resume (v1) and your edited one (v2). Add a job description if you have one.' },
  { n: '2', title: 'We re-score every edit', text: 'The change is split into edits. Each one is applied alone to v1 and scored, so you see what it was really worth.' },
  { n: '3', title: 'Keep what works', text: 'Undo any edit that hurt, follow the next best edits, and watch your score climb across versions.' },
];

const FEATURES = [
  { icon: '🎯', title: 'Per-edit attribution', text: 'See "Added metric to bullet 3: +6" instead of one mystery number.' },
  { icon: '⚖️', title: 'Honest maths', text: 'An interaction row covers overlapping edits, so the numbers always add up exactly.' },
  { icon: '🚨', title: 'Regression alerts', text: 'Edits that lowered your score are flagged, with a one-click Undo for just that edit.' },
  { icon: '🧭', title: 'Next best edit', text: 'The three improvements with the biggest estimated gain, tested before they are suggested.' },
  { icon: '📈', title: 'Score timeline', text: 'Save v1, v2, v3 and see your progress as a line chart.' },
  { icon: '🖍️', title: 'Word-level colour', text: 'Green words raised the score, red words lowered it. Hover for the exact points.' },
];

export default function Home() {
  const { session, guest } = useAuth();
  const sampleScore = useMemo(() => scoreResume(DEMO_V2, DEMO_JD).total, []);

  const openTracker = () => navigate(session ? 'app' : 'login');
  const tryAsGuest = () => {
    if (!session) guest();
    navigate('app');
  };

  return (
    <div className="mx-auto max-w-6xl px-4 pt-8 sm:px-6 sm:pt-14">
      {/* ------------------------------ hero ------------------------------ */}
      <section className="grid items-center gap-8 lg:grid-cols-[1.1fr_0.9fr]">
        <div>
          <p className="chip chip-info mb-4">100% in your browser · nothing is uploaded</p>
          <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
            See exactly which edits <span className="bg-gradient-to-r from-sky-300 to-emerald-300 bg-clip-text text-transparent">moved your resume score</span>.
          </h1>
          <p className="mt-5 max-w-xl text-base leading-relaxed text-slate-300 sm:text-lg">
            Paste your old and new resume. ResumeLens tests every change on its own and tells you what helped, what hurt, and what to fix next. No account servers, no paid APIs, and the same input always gives the same score.
          </p>
          <div className="mt-7 flex flex-wrap gap-3">
            <button type="button" className="btn btn-primary !px-5 !py-3 !text-base" onClick={openTracker}>
              {session ? 'Open the tracker' : 'Sign in to start'}
            </button>
            <button type="button" className="btn btn-secondary !px-5 !py-3 !text-base" onClick={tryAsGuest}>
              Try it as a guest
            </button>
          </div>
          <p className="mt-3 text-xs text-slate-500">Inside the tracker, press &ldquo;Load demo data&rdquo; to see a full example in one click.</p>
        </div>

        <div className="mx-auto w-full max-w-sm">
          <HeroScore score={sampleScore} caption="Sample resume after 10 edits" />
        </div>
      </section>

      {/* --------------------------- how it works -------------------------- */}
      <section className="mt-20" aria-labelledby="how-title">
        <SectionHeading id="how-title" eyebrow="How it works" title="Three steps" />
        <ol className="grid gap-4 md:grid-cols-3">
          {STEPS.map((s) => (
            <TiltCard as="li" key={s.n} className="p-5">
              <span className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-sky-400 to-emerald-400 font-extrabold text-slate-900">{s.n}</span>
              <h3 className="mt-3 text-lg font-bold text-white">{s.title}</h3>
              <p className="mt-1 text-sm leading-relaxed text-slate-400">{s.text}</p>
            </TiltCard>
          ))}
        </ol>
      </section>

      {/* ----------------------------- features ---------------------------- */}
      <section className="mt-20" aria-labelledby="features-title">
        <SectionHeading id="features-title" eyebrow="What you get" title="Built around one idea: edits, measured" />
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <TiltCard as="li" key={f.title} className="p-5">
              <span className="text-2xl" aria-hidden="true">
                {f.icon}
              </span>
              <h3 className="mt-2 text-base font-bold text-white">{f.title}</h3>
              <p className="mt-1 text-sm leading-relaxed text-slate-400">{f.text}</p>
            </TiltCard>
          ))}
        </ul>
      </section>

      {/* ------------------------------ rubric ----------------------------- */}
      <section className="mt-20" aria-labelledby="rubric-title">
        <SectionHeading id="rubric-title" eyebrow="The rules" title="How the 0-100 score is made">
          Five fixed categories. With no job description, the 35 keyword points are shared among the other four.
        </SectionHeading>
        <div className="glass overflow-x-auto">
          <table className="w-full min-w-[22rem] text-left text-sm">
            <caption className="sr-only">Score weights by category</caption>
            <thead>
              <tr className="border-b border-white/10 text-xs text-slate-400 uppercase">
                <th scope="col" className="px-4 py-3 font-semibold">
                  Category
                </th>
                <th scope="col" className="px-4 py-3 text-right font-semibold">
                  With job description
                </th>
                <th scope="col" className="px-4 py-3 text-right font-semibold">
                  Without
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {CATEGORY_META.map((c) => (
                <tr key={c.key}>
                  <th scope="row" className="px-4 py-2.5 font-medium text-slate-200">
                    {c.label}
                  </th>
                  <td className="px-4 py-2.5 text-right tabular-nums text-slate-300">{WEIGHTS_WITH_JD[c.key]}</td>
                  <td className="px-4 py-2.5 text-right tabular-nums text-slate-300">{WEIGHTS_NO_JD[c.key] || '-'}</td>
                </tr>
              ))}
              <tr className="bg-white/[0.03]">
                <th scope="row" className="px-4 py-2.5 font-bold text-white">
                  Total
                </th>
                <td className="px-4 py-2.5 text-right font-bold tabular-nums text-white">100</td>
                <td className="px-4 py-2.5 text-right font-bold tabular-nums text-white">100</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
