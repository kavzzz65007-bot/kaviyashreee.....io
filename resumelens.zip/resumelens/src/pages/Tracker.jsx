/**
 * Tracker.jsx - the main screen: inputs, "Analyze edits", results, versions.
 *
 * All state lives here; the heavy lifting is in src/engine (pure functions).
 * Rules this page follows:
 *   - every button that could be double-clicked is disabled while working
 *   - nothing is ever thrown at the user: problems become inline messages
 *   - only the LATEST analysis may update the screen (runId), and nothing
 *     updates after the page is left (mounted ref)
 *   - text is drafted into localStorage (debounced) so a reload loses nothing
 */

import { useCallback, useDeferredValue, useEffect, useMemo, useRef, useState } from 'react';
import ResultsView from '../components/ResultsView.jsx';
import ResumeInput from '../components/ResumeInput.jsx';
import VersionsPanel from '../components/VersionsPanel.jsx';
import { Alert, ConfirmButton, Spinner } from '../components/ui.jsx';
import { analyzeEditImpact, validateInputs } from '../engine/analysis.js';
import { revertChunkText } from '../engine/attribution.js';
import { DEMO_JD, DEMO_V1, DEMO_V2 } from '../engine/demoData.js';
import { resolveJd, scoreResume } from '../engine/scoring.js';
import { normalizeText } from '../engine/text.js';
import { useAuth } from '../lib/AuthContext.jsx';
import { useReducedMotion } from '../lib/hooks.js';
import { addVersion, loadDraft, loadVersions, removeVersion, saveDraft, saveVersions } from '../lib/storage.js';

const IDLE_RUN = { status: 'idle', result: null, snapshot: null, key: 0, scroll: false };

export default function Tracker() {
  const { session } = useAuth();
  const profile = session ? session.profile : 'guest';
  const reduced = useReducedMotion();

  const [texts, setTexts] = useState(() => loadDraft(profile));
  const [versions, setVersions] = useState(() => loadVersions(profile));
  const [storageOk, setStorageOk] = useState(true);
  const [run, setRun] = useState(IDLE_RUN);
  const [attempted, setAttempted] = useState(false);
  const [formError, setFormError] = useState('');
  const [toast, setToast] = useState(null);

  const mounted = useRef(true);
  const runId = useRef(0);
  const resultsRef = useRef(null);
  const toastTimer = useRef(0);
  const latestTexts = useRef(texts);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      clearTimeout(toastTimer.current);
    };
  }, []);

  /* ------------------------------ draft saving ----------------------------- */
  useEffect(() => {
    latestTexts.current = texts;
    const id = setTimeout(() => saveDraft(profile, texts), 500);
    return () => clearTimeout(id);
  }, [profile, texts]);
  // Save immediately when leaving the page, so the last keystrokes are never lost.
  useEffect(() => () => saveDraft(profile, latestTexts.current), [profile]);

  /* ------------------------------ small helpers ---------------------------- */
  const showToast = useCallback((text, tone = 'success') => {
    setToast({ text, tone, id: Date.now() });
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => {
      if (mounted.current) setToast(null);
    }, 3800);
  }, []);

  const setField = useCallback((key) => (value) => setTexts((t) => ({ ...t, [key]: value })), []);
  const setV1 = useMemo(() => setField('v1'), [setField]);
  const setV2 = useMemo(() => setField('v2'), [setField]);
  const setJd = useMemo(() => setField('jd'), [setField]);

  const running = run.status === 'running';

  /* ------------------------------ live checks ------------------------------ */
  const deferred = useDeferredValue(texts);
  const live = useMemo(() => validateInputs({ v1Text: deferred.v1, v2Text: deferred.v2, jdText: deferred.jd }), [deferred]);
  const fieldError = (key) => (attempted || texts[key].trim() ? live.errors[key] || '' : '');

  const jdModel = useMemo(() => {
    try {
      return resolveJd(normalizeText(deferred.jd) || null);
    } catch {
      return null;
    }
  }, [deferred.jd]);

  const points = useMemo(
    () =>
      versions.items
        .map((v) => {
          try {
            const s = scoreResume(v.text, jdModel);
            return { id: v.id, label: v.label, score: s.total, tenths: s.totalTenths, words: s.stats.wordCount, savedAt: v.savedAt };
          } catch {
            return null;
          }
        })
        .filter(Boolean),
    [versions, jdModel],
  );

  const snapshot = run.snapshot;
  const stale = Boolean(snapshot) && (snapshot.v1Text !== texts.v1 || snapshot.v2Text !== texts.v2 || snapshot.jdText !== texts.jd);

  /* -------------------------------- analysis ------------------------------- */
  const runAnalysis = useCallback(async (input, { scroll = true } = {}) => {
    setAttempted(true);
    const validation = validateInputs(input);
    if (!validation.ok) {
      setFormError('Please fix the problems shown above, then try again.');
      const firstBad = ['v1', 'v2', 'jd'].find((k) => validation.errors[k]);
      const el = firstBad ? document.getElementById(`${firstBad}-text`) : null;
      if (el) el.focus();
      return;
    }

    const id = ++runId.current;
    setFormError('');
    setRun((r) => ({ ...r, status: 'running' }));
    await new Promise((resolve) => setTimeout(resolve, 30)); // let the "Analyzing…" state paint first

    try {
      const result = await analyzeEditImpact(input);
      if (!mounted.current || id !== runId.current) return;
      if (!result.ok) {
        setRun((r) => ({ ...r, status: r.result ? 'done' : 'idle' }));
        setFormError('Please fix the problems shown above, then try again.');
        return;
      }
      setRun({ status: 'done', result, snapshot: input, key: id, scroll });
    } catch {
      if (!mounted.current || id !== runId.current) return;
      setRun((r) => ({ ...r, status: r.result ? 'done' : 'idle' }));
      setFormError('Something unexpected happened while analysing. Your text has not been changed. Please try again, or try shorter text.');
    }
  }, []);

  const analyze = () => runAnalysis({ v1Text: texts.v1, v2Text: texts.v2, jdText: texts.jd });

  // After a fresh analysis, bring the results into view.
  useEffect(() => {
    if (run.status === 'done' && run.scroll && resultsRef.current) {
      resultsRef.current.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'start' });
    }
    // Only when a NEW result arrives.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [run.key]);

  /* --------------------------------- undo ---------------------------------- */
  const undo = useCallback(
    (chunkId) => {
      if (!run.result || running) return;
      const chunk = run.result.chunks.find((c) => c.id === chunkId);
      let newV2;
      try {
        newV2 = revertChunkText(run.result.attribution, chunkId);
      } catch {
        newV2 = null;
      }
      if (typeof newV2 !== 'string' || !newV2.trim()) {
        showToast('That edit could not be reverted automatically.', 'error');
        return;
      }
      setTexts((t) => ({ ...t, v2: newV2 }));
      runAnalysis({ ...run.snapshot, v2Text: newV2 }, { scroll: false });
      showToast(`Reverted: ${chunk ? chunk.label : 'edit'}`);
    },
    [run.result, run.snapshot, running, runAnalysis, showToast],
  );

  /* ------------------------------ demo and clear --------------------------- */
  const persistVersions = useCallback((data) => {
    setVersions(data);
    setStorageOk(saveVersions(profile, data));
  }, [profile]);

  const loadDemo = () => {
    setTexts({ v1: DEMO_V1.trim(), v2: DEMO_V2.trim(), jd: DEMO_JD.trim() });
    // Save both demo resumes as versions so the timeline has something to show.
    let data = versions;
    const a = addVersion(data, DEMO_V1);
    data = a.data;
    const b = addVersion(data, DEMO_V2);
    data = b.data;
    if (a.added || b.added) persistVersions(data);
    runAnalysis({ v1Text: DEMO_V1.trim(), v2Text: DEMO_V2.trim(), jdText: DEMO_JD.trim() });
    showToast('Demo data loaded.');
  };

  const clearAll = () => {
    runId.current += 1; // cancel any analysis in flight
    setTexts({ v1: '', v2: '', jd: '' });
    setRun(IDLE_RUN);
    setAttempted(false);
    setFormError('');
    showToast('Cleared. Your saved versions are still below.');
  };

  const hasText = Boolean(texts.v1.trim() || texts.v2.trim() || texts.jd.trim());

  /* -------------------------------- versions ------------------------------- */
  const saveAs = (key) => {
    const res = addVersion(versions, texts[key]);
    if (res.existing) {
      showToast(`Already saved as ${res.existing.label}.`, 'info');
      return;
    }
    if (!res.added) {
      showToast('Nothing to save: the text is empty or too long.', 'error');
      return;
    }
    persistVersions(res.data);
    showToast(`Saved as ${res.added.label}.`);
  };

  const useVersion = (key) => (id) => {
    const item = versions.items.find((v) => v.id === id);
    if (!item) return;
    setTexts((t) => ({ ...t, [key]: item.text }));
    showToast(`${item.label} loaded as ${key === 'v1' ? 'version 1' : 'version 2'}.`);
  };

  const deleteVersion = (id) => {
    persistVersions(removeVersion(versions, id));
    showToast('Version deleted.', 'info');
  };

  /* ---------------------------------- view --------------------------------- */
  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <header className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div className="max-w-2xl">
          <p className="text-xs font-semibold tracking-widest text-sky-300/80 uppercase">Edit Impact Tracker</p>
          <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">Which edit moved your score?</h1>
          <p className="mt-1.5 text-sm text-slate-400">Paste or upload your old resume (v1) and your edited one (v2), add a job description if you have one, then press Analyze.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <ConfirmButton className="btn btn-secondary" confirmLabel="Click again to replace my text" needsConfirm={hasText} onConfirm={loadDemo} disabled={running}>
            Load demo data
          </ConfirmButton>
          <ConfirmButton className="btn btn-ghost" confirmLabel="Click again to clear" needsConfirm={hasText} onConfirm={clearAll} disabled={running || !hasText}>
            Clear all
          </ConfirmButton>
        </div>
      </header>

      <div className="grid gap-5 lg:grid-cols-2">
        <ResumeInput
          id="v1-text"
          label="Resume v1 (before)"
          hint="Your older version."
          placeholder="Paste your older resume here…"
          value={texts.v1}
          onChange={setV1}
          error={fieldError('v1')}
          disabled={running}
          onSave={() => saveAs('v1')}
          saveLabel="Save v1 as version"
        />
        <ResumeInput
          id="v2-text"
          label="Resume v2 (after)"
          hint="Your edited version."
          placeholder="Paste your edited resume here…"
          value={texts.v2}
          onChange={setV2}
          error={fieldError('v2')}
          disabled={running}
          onSave={() => saveAs('v2')}
          saveLabel="Save v2 as version"
        />
      </div>

      <div className="mt-5">
        <ResumeInput
          id="jd-text"
          label="Job description (optional)"
          hint="Paste the job posting to score keyword match. Leave empty to skip."
          placeholder="Paste the job description here…"
          value={texts.jd}
          onChange={setJd}
          error={fieldError('jd')}
          disabled={running}
          maxChars={20000}
          rows={7}
        />
      </div>

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <button type="button" className="btn btn-primary !px-6 !py-3 !text-base" onClick={analyze} disabled={running} aria-busy={running}>
          {running ? <Spinner /> : null}
          {running ? 'Analyzing…' : 'Analyze edits'}
        </button>
        {running ? <span className="text-sm text-slate-400">Re-scoring every edit - this takes a moment for long resumes.</span> : null}
      </div>

      <div className="mt-3 space-y-2">
        {formError ? <Alert tone="error">{formError}</Alert> : null}
        {!run.result ? live.warnings.map((w) => <Alert key={w} tone="warn">{w}</Alert>) : null}
        {!run.result && texts.v1.trim() && texts.v2.trim() ? live.notes.map((n) => <Alert key={n} tone="info">{n}</Alert>) : null}
      </div>

      <div ref={resultsRef} className="mt-8 scroll-mt-20" aria-live="polite">
        {run.result ? (
          <ResultsView result={run.result} stale={stale} busy={running} onUndo={undo} />
        ) : (
          <div className="glass grid min-h-[10rem] place-items-center p-8 text-center">
            <div>
              <p className="text-lg font-bold text-slate-100">Your results will appear here</p>
              <p className="mt-1 text-sm text-slate-400">Add two versions of a resume and press &ldquo;Analyze edits&rdquo;, or press &ldquo;Load demo data&rdquo; to see a full example.</p>
            </div>
          </div>
        )}
      </div>

      <div className="mt-8">
        <VersionsPanel
          points={points}
          hasJD={Boolean(jdModel)}
          storageOk={storageOk}
          disabled={running}
          onUseV1={useVersion('v1')}
          onUseV2={useVersion('v2')}
          onDelete={deleteVersion}
        />
      </div>

      {/* Screen-reader + sighted confirmation messages */}
      <div className="pointer-events-none fixed inset-x-0 bottom-4 z-40 flex justify-center px-4" role="status" aria-live="polite">
        {toast ? (
          <div
            key={toast.id}
            className={`fade-in pointer-events-auto rounded-xl border px-4 py-2.5 text-sm font-medium shadow-xl backdrop-blur ${
              toast.tone === 'error' ? 'border-red-400/50 bg-red-950/90 text-red-100' : toast.tone === 'info' ? 'border-sky-400/40 bg-slate-900/95 text-sky-100' : 'border-emerald-400/40 bg-slate-900/95 text-emerald-100'
            }`}
          >
            {toast.text}
          </div>
        ) : null}
      </div>
    </div>
  );
}
