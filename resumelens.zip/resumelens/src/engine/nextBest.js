/**
 * nextBest.js
 * ---------------------------------------------------------------------------
 * "Next Best Edit": rank improvements that are NOT yet applied to a resume by
 * their estimated score gain.
 *
 * Every candidate is a concrete simulated edit (e.g. "add Docker to Skills",
 * "put a number on bullet 4"). We apply it to a copy of the resume, re-score,
 * and the difference is the estimated gain. Placeholders used for the
 * simulation (a "by 25%" suffix, a generic opening verb) are only an estimate:
 * the real gain depends on how you word the edit.
 */

import { MAX_JD_KEYWORDS, SECTION_LABELS } from './constants.js';
import {
  analyzeBullets,
  findWeakPhrases,
  hasMetric,
  resolveJd,
  scoreStructure,
  startsWithActionVerb,
} from './scoring.js';
import { countWords, makeUnit, structureFromUnits, withUnitText } from './text.js';

const TYPE_PRIORITY = { keyword: 0, metric: 1, weak: 2, verb: 3, tighten: 4, section: 5, contact: 6 };
const MAX_KEYWORD_CANDIDATES = 12;
const MAX_BULLET_CANDIDATES = 25;

const scoreUnitsTenths = (units, jdModel) => scoreStructure(structureFromUnits(units), jdModel).totalTenths;

const lowerFirst = (s) => (s ? s[0].toLowerCase() + s.slice(1) : s);
const stripEnd = (s) => s.replace(/[.;,\s]+$/, '');
const snippet = (s, n = 8) => {
  const w = s.split(' ');
  return w.length > n ? `${w.slice(0, n).join(' ')}…` : s;
};

/** Replace the unit at `index` with new body text. */
function replaceAt(units, index, newText) {
  const copy = units.slice();
  copy[index] = withUnitText(units[index], newText);
  return copy;
}

/** Candidate generation: returns [{ id, type, title, detail, units, order }]. */
function generateCandidates(units, structure, jdModel) {
  const out = [];
  const bullets = structure.bullets.slice(0, MAX_BULLET_CANDIDATES);
  const ordinalInSection = (b) => structure.bullets.filter((x) => x.section === b.section && x.index <= b.index).length;
  const where = (b) => `bullet ${ordinalInSection(b)} (${SECTION_LABELS[b.section] || 'Resume'})`;

  /* 1. Missing JD keywords -> add to Skills */
  if (jdModel) {
    const stemsPresent = new Set();
    const result = scoreStructure(structure, jdModel);
    result.missingKeywords.slice(0, MAX_KEYWORD_CANDIDATES).forEach((kw, i) => {
      const skillsHeadingIdx = structure.lines.findIndex((l) => l.kind === 'heading' && l.section === 'skills');
      let simulated;
      if (skillsHeadingIdx >= 0) {
        const bodyLines = structure.lines.filter((l) => l.section === 'skills' && l.kind !== 'heading');
        if (bodyLines.length) {
          const last = bodyLines[bodyLines.length - 1];
          simulated = replaceAt(units, last.index, `${stripEnd(last.unit.text)}, ${kw.display}`);
        } else {
          simulated = [...units.slice(0, skillsHeadingIdx + 1), makeUnit(kw.display), ...units.slice(skillsHeadingIdx + 1)];
        }
      } else {
        simulated = [...units, makeUnit('Skills'), makeUnit(kw.display)];
      }
      stemsPresent.add(kw.stem);
      out.push({
        id: `keyword:${kw.stem}`,
        type: 'keyword',
        title: `Add "${kw.display}" to your Skills section`,
        detail: `It appears ${kw.count}x in the job description but not in your resume. Only add it if you genuinely have the skill.`,
        units: simulated,
        order: i,
      });
    });
  }

  /* 2. Bullets without a number */
  bullets.forEach((b) => {
    if (hasMetric(b.text)) return;
    const simulated = replaceAt(units, b.index, `${stripEnd(b.text)} by 25%`);
    out.push({
      id: `metric:${b.index}`,
      type: 'metric',
      title: `Add a measurable result to ${where(b)}`,
      detail: `"${snippet(b.text)}" has no number. Say how much, how many or how fast (a %, $ amount, time saved, users reached).`,
      units: simulated,
      order: b.index,
    });
  });

  /* 3. Weak phrases that have a simple strong replacement */
  bullets.forEach((b) => {
    const weak = findWeakPhrases(b.text).find((w) => w.replaceWith);
    if (!weak) return;
    const re = new RegExp(`(?<![A-Za-z])${weak.phrase.replace(/ /g, '\\s+')}(?![A-Za-z])`, 'i');
    const atStart = re.exec(b.text)?.index === 0;
    const replaced = b.text.replace(re, atStart ? weak.replaceWith : lowerFirst(weak.replaceWith));
    out.push({
      id: `weak:${b.index}`,
      type: 'weak',
      title: `Replace "${weak.phrase}" in ${where(b)} with a strong verb`,
      detail: weak.fix,
      units: replaceAt(units, b.index, replaced),
      order: b.index,
    });
  });

  /* 4. Bullets that do not open with an action verb (and have no weak phrase to fix) */
  bullets.forEach((b) => {
    if (startsWithActionVerb(b.text) || findWeakPhrases(b.text).some((w) => w.replaceWith)) return;
    out.push({
      id: `verb:${b.index}`,
      type: 'verb',
      title: `Start ${where(b)} with a strong action verb`,
      detail: `"${snippet(b.text)}" - try Led, Built, Reduced, Launched or Automated.`,
      units: replaceAt(units, b.index, `Delivered ${lowerFirst(b.text)}`),
      order: b.index,
    });
  });

  /* 5. Over-long bullets */
  analyzeBullets(structure)
    .filter((f) => f.issues.includes('too-long'))
    .slice(0, 10)
    .forEach((f) => {
      const trimmed = f.text.split(' ').slice(0, 24).join(' ');
      out.push({
        id: `tighten:${f.index}`,
        type: 'tighten',
        title: `Tighten bullet ${f.number} (${countWords(f.text)} words)`,
        detail: 'Cut filler and keep the action plus the result; aim for under 30 words.',
        units: replaceAt(units, f.index, trimmed),
        order: f.index,
      });
    });

  /* 6. Missing standard sections */
  [
    ['summary', 'Summary', 'A 2-3 line summary tells recruiters and ATS parsers who you are at a glance.'],
    ['experience', 'Experience', 'Most ATS parsers look for an Experience section first.'],
    ['education', 'Education', 'Add your degree(s) under an Education heading.'],
    ['skills', 'Skills', 'A Skills section is the easiest place for ATS keyword matches.'],
  ].forEach(([key, label, detail], i) => {
    if (structure.present[key]) return;
    out.push({
      id: `section:${key}`,
      type: 'section',
      title: `Add a "${label}" section`,
      detail,
      units: [...units, makeUnit(label), makeUnit('Add details here')],
      order: i,
    });
  });

  /* 7. Contact info */
  if (!structure.hasContact) {
    out.push({
      id: 'contact',
      type: 'contact',
      title: 'Add an email address and phone number',
      detail: 'ATS and recruiters need a way to reach you; put contact details at the very top.',
      units: [makeUnit('name@example.com | +1 555 010 1234'), ...units],
      order: 0,
    });
  }

  return out;
}

/**
 * Rank the not-yet-applied improvements for `units`.
 *
 * @param {Array} units   the resume (usually v2)
 * @param {string|object|null} jd
 * @param {{limit?: number}} [options]
 * @returns {Array<{id,type,title,detail,gainTenths,gain}>} top N by estimated gain (gain > 0)
 */
export function computeNextBestEdits(units, jd, options = {}) {
  const limit = options.limit ?? 3;
  const jdModel = resolveJd(jd);
  const structure = structureFromUnits(units);
  const base = scoreStructure(structure, jdModel).totalTenths;

  const seen = new Set();
  const ranked = [];
  for (const cand of generateCandidates(units, structure, jdModel)) {
    if (seen.has(cand.id)) continue;
    seen.add(cand.id);
    const gainTenths = scoreUnitsTenths(cand.units, jdModel) - base;
    if (gainTenths <= 0) continue;
    ranked.push({
      id: cand.id,
      type: cand.type,
      title: cand.title,
      detail: cand.detail,
      gainTenths,
      gain: gainTenths / 10,
      order: cand.order,
    });
  }

  ranked.sort(
    (a, b) =>
      b.gainTenths - a.gainTenths ||
      TYPE_PRIORITY[a.type] - TYPE_PRIORITY[b.type] ||
      a.order - b.order ||
      (a.id < b.id ? -1 : 1),
  );
  return ranked.slice(0, limit).map(({ order, ...rest }) => rest);
}

export { MAX_JD_KEYWORDS };
