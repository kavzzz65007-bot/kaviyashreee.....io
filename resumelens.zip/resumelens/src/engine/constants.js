/**
 * constants.js
 * ---------------------------------------------------------------------------
 * All the fixed data the scoring / diff engines rely on: weights, limits,
 * word lists and section aliases. Keeping it in one place makes the scoring
 * rules easy to read and tweak. Nothing in here is random or time based, so
 * the same input always produces the same score.
 */

/* ----------------------------- limits -------------------------------- */

/** Anything above this is rejected with a friendly message (not a real resume). */
export const MAX_CHARS = 40000;
/** Job descriptions are shorter than resumes. */
export const MAX_JD_CHARS = 20000;
/** Hard cap on logical lines so the O(n*m) diff stays fast. */
export const MAX_LINES = 1500;
/** Below this many words we warn that scores will be unreliable. */
export const MIN_WORDS_WARN = 40;
/** Upload size limit in bytes (5 MB). */
export const MAX_FILE_BYTES = 5 * 1024 * 1024;
/** How many JD keywords we keep when a JD is supplied. */
export const MAX_JD_KEYWORDS = 30;
/** Word-level highlighting evaluates at most this many changed words. */
export const MAX_WORD_EVALS = 300;
/** Max saved resume versions per profile. */
export const MAX_VERSIONS = 20;

/* ----------------------------- weights ------------------------------- */

/** Category maxima when a job description is present. Sum = 100. */
export const WEIGHTS_WITH_JD = {
  keywords: 35,
  metrics: 20,
  verbs: 15,
  sections: 15,
  readability: 15,
};

/**
 * Category maxima with NO job description: the 35 keyword points are shared
 * out proportionally (20:15:15:15 of 65) and rounded so the total is still
 * exactly 100.  20/65*100 = 30.8 -> 31, 15/65*100 = 23.1 -> 23.  31+23*3 = 100.
 */
export const WEIGHTS_NO_JD = {
  keywords: 0,
  metrics: 31,
  verbs: 23,
  sections: 23,
  readability: 23,
};

/** Display order + labels for the breakdown. */
export const CATEGORY_META = [
  { key: 'keywords', label: 'Keyword match' },
  { key: 'metrics', label: 'Quantified metrics' },
  { key: 'verbs', label: 'Action verbs' },
  { key: 'sections', label: 'Standard sections' },
  { key: 'readability', label: 'Readability & weak phrases' },
];

/** Share of bullets that should contain a number for full metric marks. */
export const METRIC_TARGET_SHARE = 0.5;
/** Share of bullets that should open with a strong verb for full marks. */
export const VERB_TARGET_SHARE = 0.8;
/** Bullet length window (in words) that counts as readable. */
export const BULLET_MIN_WORDS = 6;
export const BULLET_MAX_WORDS = 30;

/**
 * Piece-wise linear "ideal length" curve: [wordCount, ratio].
 * 350-800 words is the sweet spot for a 1-2 page resume.
 */
export const LENGTH_CURVE = [
  [0, 0],
  [150, 0.3],
  [350, 1],
  [800, 1],
  [1200, 0.4],
  [2000, 0.1],
];

/* ----------------------------- sections ------------------------------ */

/** Heading text (normalised) -> canonical section key. */
const SECTION_ALIASES = {
  summary: [
    'summary', 'professional summary', 'profile', 'professional profile',
    'career summary', 'objective', 'career objective', 'about me', 'about',
    'executive summary', 'personal statement', 'summary of qualifications',
  ],
  experience: [
    'experience', 'work experience', 'professional experience', 'employment',
    'employment history', 'work history', 'relevant experience', 'internships',
    'internship experience', 'career history', 'industry experience',
  ],
  education: [
    'education', 'academic background', 'academics', 'education and training',
    'academic qualifications', 'educational qualifications',
  ],
  skills: [
    'skills', 'technical skills', 'core skills', 'key skills',
    'core competencies', 'competencies', 'skills and tools', 'technologies',
    'tech stack', 'technical proficiencies', 'areas of expertise', 'expertise',
    'skills and technologies', 'technical expertise',
  ],
  projects: [
    'projects', 'personal projects', 'academic projects', 'selected projects',
    'key projects', 'side projects', 'project experience',
  ],
  contact: ['contact', 'contact information', 'contact details'],
  other: [
    'certifications', 'certificates', 'awards', 'honors', 'honours',
    'achievements', 'publications', 'languages', 'interests', 'hobbies',
    'volunteer', 'volunteering', 'volunteer experience', 'leadership',
    'extracurricular', 'extracurricular activities', 'activities',
    'references', 'training', 'courses', 'patents', 'accomplishments',
  ],
};

export const SECTION_LOOKUP = (() => {
  const map = new Map();
  for (const [key, aliases] of Object.entries(SECTION_ALIASES)) {
    for (const a of aliases) map.set(a, key);
  }
  return map;
})();

/** Sections whose lines are treated as achievement bullets. */
export const BULLET_SECTIONS = new Set(['experience', 'projects']);

/** The sections the "standard sections" category checks for. */
export const CORE_SECTIONS = [
  { key: 'contact', label: 'Contact info' },
  { key: 'summary', label: 'Summary' },
  { key: 'experience', label: 'Experience' },
  { key: 'education', label: 'Education' },
  { key: 'skills', label: 'Skills' },
];

/** Pretty names for section keys (used in labels). */
export const SECTION_LABELS = {
  header: 'Header',
  contact: 'Contact',
  summary: 'Summary',
  experience: 'Experience',
  education: 'Education',
  skills: 'Skills',
  projects: 'Projects',
  other: 'Other',
};

/* ----------------------------- action verbs -------------------------- */

/**
 * Strong action verbs. Base forms are enough for regular verbs because the
 * engine compares stems ("developed", "develops", "developing" all match
 * "develop"). Irregular past tenses are listed explicitly.
 */
export const ACTION_VERBS = [
  'accelerate', 'achieve', 'administer', 'advise', 'analyze', 'analyse',
  'architect', 'assemble', 'audit', 'author', 'automate', 'boost', 'budget',
  'build', 'built', 'calculate', 'catalog', 'centralize', 'chair', 'champion',
  'coach', 'collaborate', 'compile', 'complete', 'conceive', 'conduct',
  'configure', 'consolidate', 'construct', 'consult', 'containerize',
  'coordinate', 'create', 'cut', 'debug', 'decrease', 'define', 'deliver',
  'deploy', 'design', 'detect', 'develop', 'devise', 'diagnose', 'direct',
  'discover', 'double', 'drive', 'drove', 'earn', 'eliminate', 'enable',
  'enforce', 'engineer', 'enhance', 'establish', 'evaluate', 'execute',
  'expand', 'expedite', 'facilitate', 'finalize', 'forecast', 'formulate',
  'found', 'generate', 'grew', 'grow', 'guide', 'identify', 'implement',
  'improve', 'increase', 'initiate', 'innovate', 'install', 'instruct',
  'integrate', 'introduce', 'investigate', 'launch', 'lead', 'led',
  'leverage', 'maintain', 'manage', 'mentor', 'migrate', 'minimize', 'model',
  'modernize', 'monitor', 'negotiate', 'optimize', 'orchestrate', 'organize',
  'outperform', 'oversaw', 'oversee', 'own', 'owned', 'partner', 'pioneer',
  'plan', 'present', 'prioritize', 'produce', 'program', 'promote',
  'prototype', 'provision', 'publish', 'rebuild', 'recruit', 'redesign',
  'reduce', 'refactor', 'refine', 'release', 'reorganize', 'replace',
  'research', 'resolve', 'restructure', 'revamp', 'review', 'revise', 'ran',
  'run', 'save', 'scale', 'schedule', 'secure', 'shape', 'ship', 'simplify',
  'slash', 'solve', 'spearhead', 'standardize', 'steer', 'streamline',
  'strengthen', 'supervise', 'surpass', 'synthesize', 'taught', 'teach',
  'test', 'train', 'transform', 'translate', 'triple', 'troubleshoot',
  'unify', 'upgrade', 'validate', 'visualize', 'won', 'win', 'wrote', 'write',
];

/* ----------------------------- weak phrases -------------------------- */

/**
 * Weak / vague phrases. `fix` is the short suggestion shown to the user.
 * `replaceWith` (optional) is a strong verb used when we SIMULATE a fix for
 * the "Next Best Edit" estimate. Longer phrases come first so that
 * "helped with" is matched before "helped".
 */
export const WEAK_PHRASES = [
  { phrase: 'responsible for', kind: 'weak', replaceWith: 'Led', fix: 'Open with a strong verb (e.g. "Led", "Managed") and state the result instead of "responsible for".' },
  { phrase: 'duties included', kind: 'weak', replaceWith: 'Delivered', fix: 'Replace "duties included" with what you actually delivered.' },
  { phrase: 'worked on', kind: 'weak', replaceWith: 'Built', fix: 'Say what you built or changed ("Built…", "Improved…") instead of "worked on".' },
  { phrase: 'worked with', kind: 'weak', replaceWith: 'Partnered with', fix: 'Say what the collaboration achieved ("Partnered with X to deliver Y").' },
  { phrase: 'helped with', kind: 'weak', replaceWith: 'Supported', fix: 'Describe your own contribution and outcome instead of "helped with".' },
  { phrase: 'helped to', kind: 'weak', replaceWith: 'Enabled', fix: 'Describe your own contribution and outcome instead of "helped to".' },
  { phrase: 'helped', kind: 'weak', replaceWith: 'Supported', fix: 'Describe your own contribution and outcome instead of "helped".' },
  { phrase: 'assisted with', kind: 'weak', replaceWith: 'Supported', fix: 'Describe what you owned instead of "assisted with".' },
  { phrase: 'assisted in', kind: 'weak', replaceWith: 'Supported', fix: 'Describe what you owned instead of "assisted in".' },
  { phrase: 'assisted', kind: 'weak', replaceWith: 'Supported', fix: 'Describe what you owned instead of "assisted".' },
  { phrase: 'tasked with', kind: 'weak', replaceWith: 'Executed', fix: 'Lead with the action and result, not the assignment ("tasked with").' },
  { phrase: 'in charge of', kind: 'weak', replaceWith: 'Directed', fix: 'Use a verb like "Directed" or "Managed" and add a result.' },
  { phrase: 'involved in', kind: 'weak', replaceWith: 'Drove', fix: 'Say what your role was ("Drove", "Delivered") instead of "involved in".' },
  { phrase: 'participated in', kind: 'weak', replaceWith: 'Drove', fix: 'Say what your role was instead of "participated in".' },
  { phrase: 'was part of', kind: 'weak', replaceWith: 'Contributed to', fix: 'Say what you contributed instead of "was part of".' },
  { phrase: 'exposure to', kind: 'weak', replaceWith: 'Applied', fix: 'Replace "exposure to" with what you actually did with it.' },
  { phrase: 'familiar with', kind: 'weak', replaceWith: 'Applied', fix: 'Replace "familiar with" with how you used it.' },
  { phrase: 'tried to', kind: 'weak', replaceWith: 'Drove', fix: 'Describe what you achieved, not what you tried.' },
  { phrase: 'attempted to', kind: 'weak', replaceWith: 'Drove', fix: 'Describe what you achieved, not what you attempted.' },
  { phrase: 'hard worker', kind: 'cliche', fix: 'Replace the buzzword "hard worker" with a concrete result.' },
  { phrase: 'hard-working', kind: 'cliche', fix: 'Replace the buzzword "hard-working" with a concrete result.' },
  { phrase: 'team player', kind: 'cliche', fix: 'Show teamwork with an example instead of saying "team player".' },
  { phrase: 'go-getter', kind: 'cliche', fix: 'Replace "go-getter" with a specific achievement.' },
  { phrase: 'self-starter', kind: 'cliche', fix: 'Replace "self-starter" with a project you started.' },
  { phrase: 'results-driven', kind: 'cliche', fix: 'Show the results instead of claiming to be "results-driven".' },
  { phrase: 'results-oriented', kind: 'cliche', fix: 'Show the results instead of claiming to be "results-oriented".' },
  { phrase: 'detail-oriented', kind: 'cliche', fix: 'Prove attention to detail with a number (e.g. error rate cut by 20%).' },
  { phrase: 'think outside the box', kind: 'cliche', fix: 'Describe the creative solution itself.' },
  { phrase: 'references available upon request', kind: 'cliche', fix: 'Remove this line; it is assumed and wastes space.' },
  { phrase: 'a lot of', kind: 'vague', fix: 'Replace "a lot of" with a real quantity.' },
  { phrase: 'various', kind: 'vague', fix: 'Name the specific items instead of "various".' },
  { phrase: 'several', kind: 'vague', fix: 'Replace "several" with an exact number.' },
  { phrase: 'numerous', kind: 'vague', fix: 'Replace "numerous" with an exact number.' },
  { phrase: 'miscellaneous', kind: 'vague', fix: 'Name the specific tasks instead of "miscellaneous".' },
  { phrase: 'stuff', kind: 'vague', fix: 'Replace "stuff" with the specific thing you worked on.' },
  { phrase: 'things', kind: 'vague', fix: 'Replace "things" with the specific items.' },
  { phrase: 'etc', kind: 'vague', fix: 'List the specifics instead of ending with "etc."' },
];

/* ----------------------------- stop words ---------------------------- */

const STOPWORDS_LIST = `a about above after again against all also am an and any are as at be because been before
being below between both but by can could did do does doing down during each few for from further had has have
having he her here hers him his how i if in into is it its itself just me more most my myself no nor not of off on
once only or other our ours out over own same she should so some such than that the their theirs them then there
these they this those through to too under until up very was we were what when where which while who whom why will
with would you your yours yourself within without per via etc eg ie vs among across along around within upon onto
whether either neither yet still ever even much many may might must shall lot lots well`;

/**
 * Words that are common in job descriptions but are not real keywords
 * (they would otherwise dominate the "missing keywords" list).
 */
const JD_FILLER_LIST = `experience experienced ability able strong strongly work working works worked team teams years year
required requirement requirements preferred prefer responsibilities responsibility qualifications qualification
knowledge understanding understand role roles position positions candidate candidates looking join company
including include includes included plus good great excellent proven demonstrated demonstrate seeking
skills skill job description opportunity opportunities benefits salary apply application applicants applicant
ideal successful success need needs needed make making help helping ensure ensuring across new using use used
related relevant various multiple environment environments fast paced day days time week weeks month months
based level levels senior junior mid entry full part etc will would should might love passion passionate
motivated driven eager willing highly hands commitment equal employer employment status regarding minimum
bachelor bachelors master masters degree equivalent similar field plus nice bonus own ownership others
cross functional collaborate collaboration collaborative communicate communication stakeholders stakeholder
perform performing performs provide providing provides support supporting supports develop developing
drive driving deliver delivering high quality best practices practice process processes solutions solution
products product services service customers customer clients client business businesses organization
organizations industry industries part parts responsible lead leading leads one two three four five
platform platforms power powers track record scale scaling build building engineer engineers improve improving
improvement improvements own owns grow growing role responsibilities familiarity familiar comfortable
comfort proficiency proficient`;

const toSet = (s) => new Set(s.split(/\s+/).filter(Boolean));
export const STOPWORDS = toSet(STOPWORDS_LIST);
export const JD_FILLER = toSet(JD_FILLER_LIST);

/** Two-letter tokens that are real tech keywords (everything else <3 chars is dropped). */
export const SHORT_TECH = new Set(['ai', 'ml', 'qa', 'ui', 'ux', 'ci', 'cd', 'bi', 'db', 'js', 'ts', 'vr', 'ar', 'c#', 'c+']);

/** Words that, directly before a number, mean the number is a version (not a metric). */
export const VERSION_WORDS = new Set([
  'version', 'v', 'java', 'python', 'php', 'ruby', 'node', 'ios', 'android',
  'windows', 'angular', 'html', 'css', 'http', 'es', 'iso', 'swift', 'kotlin',
  'php', 'perl', 'office', 'server', 'macos', 'linux', 'ubuntu', 'spark',
]);
