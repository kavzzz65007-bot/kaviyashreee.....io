/**
 * wordImpact.js
 * ---------------------------------------------------------------------------
 * Word-level highlighting for the v2 text.
 *
 *   green  = this edited word RAISED the score
 *   red    = this edited word LOWERED the score
 *   grey   = changed, but no effect on the score
 *
 * For every ADDED word we remove just that word from v2 and re-score:
 *      impact = score(v2) - score(v2 without the word)
 * For every REMOVED word (it exists in v1 only) we put it back into v2:
 *      impact = score(v2) - score(v2 with the word restored)
 * i.e. impact is always "what did this edit do to the score".
 *
 * Words that do the same job (two numbers in one bullet) cannot change the
 * score when removed one at a time. When the one-at-a-time effect is zero we
 * fall back to the effect the word has ON ITS OWN (the line with only that
 * edit applied), so both numbers still get credit.
 *
 * Whole removed lines are shown as ghost lines coloured by their chunk delta.
 * Only the first MAX_WORD_EVALS score evaluations are spent; remaining changed
 * words stay grey and `truncated` is set.
 */

import { MAX_WORD_EVALS } from './constants.js';
import { diffWords } from './diff.js';
import { scoreStructure } from './scoring.js';
import { structureFromUnits, withUnitText } from './text.js';

const sameTick = () => Promise.resolve();

/**
 * @param {object} args
 * @param {Array} args.unitsB          units of v2
 * @param {object} args.attribution    result of attributeChanges()
 * @param {object|null} args.jdModel
 * @param {() => Promise<void>} [args.yieldFn] called every few evaluations so the UI can repaint
 * @param {number} [args.maxEvals]
 */
export async function computeWordImpact({ unitsB, attribution, jdModel, yieldFn = sameTick, maxEvals = MAX_WORD_EVALS }) {
  const { script, rawChunks, chunks } = attribution;
  const baseTenths = scoreStructure(structureFromUnits(unitsB), jdModel).totalTenths;
  const chunkResult = new Map(chunks.map((c) => [c.id, c]));
  const rawById = new Map(rawChunks.map((c) => [c.id, c]));

  let evals = 0;
  let truncated = false;
  const working = unitsB.slice();

  /** Total score (tenths) of v2 with unit `index` temporarily replaced by `words`. */
  const scoreWith = async (index, words) => {
    const original = working[index];
    working[index] = withUnitText(original, words.join(' '));
    const t = scoreStructure(structureFromUnits(working), jdModel).totalTenths;
    working[index] = original;
    evals += 1;
    if (evals % 40 === 0) await yieldFn();
    return t;
  };

  /** Effect of ADDED word k of a line (newWords / statuses are in v2 order). */
  const addedImpact = async (index, newWords, statuses, k, cache) => {
    const marginal = baseTenths - (await scoreWith(index, newWords.filter((_, i) => i !== k)));
    if (marginal !== 0) return marginal;
    // Redundant word: judge it alone, on top of the unchanged words only.
    const kept = newWords.filter((_, i) => statuses[i] === 'same');
    if (cache.keptScore === undefined) cache.keptScore = await scoreWith(index, kept);
    const alone = await scoreWith(index, newWords.filter((_, i) => statuses[i] === 'same' || i === k));
    return alone - cache.keptScore;
  };

  /** Effect of REMOVING word `aPos` of the old line (v2 position `bPos`). */
  const removedImpact = async (index, newWords, bPos, oldWords, aPos, cache) => {
    const restored = [...newWords.slice(0, bPos), oldWords[aPos], ...newWords.slice(bPos)];
    const marginal = baseTenths - (await scoreWith(index, restored));
    if (marginal !== 0) return marginal;
    // Redundant word: judge removing it alone from the old line.
    if (cache.oldScore === undefined) cache.oldScore = await scoreWith(index, oldWords);
    const without = await scoreWith(index, oldWords.filter((_, i) => i !== aPos));
    return without - cache.oldScore;
  };

  const lines = [];

  for (const item of script) {
    if (item.type === 'eq') {
      lines.push({ key: `eq-${item.b}`, unitIndex: item.b, ghost: false, marker: item.unit.marker, segments: [{ text: item.unit.text, status: 'same', impact: null }] });
      continue;
    }

    const chunk = rawById.get(item.chunk);

    if (item.type === 'del') {
      // Edited lines show their old words inline on the v2 line; moved lines show at the new position.
      if (chunk.kind === 'changed' || chunk.kind === 'moved') continue;
      const res = chunkResult.get(item.chunk);
      const delta = res ? res.deltaTenths : 0;
      lines.push({
        key: `del-${item.a}`,
        unitIndex: null,
        ghost: true,
        chunkId: item.chunk,
        chunkDeltaTenths: delta,
        marker: item.unit.marker,
        segments: item.unit.text.split(' ').map((w) => ({ text: w, status: 'removed', impact: delta, lineLevel: true })),
      });
      continue;
    }

    // item.type === 'ins'
    const unitIndex = item.b;
    const newWords = item.unit.text.split(' ');

    if (chunk.kind === 'moved') {
      lines.push({ key: `mv-${item.b}`, unitIndex, ghost: false, chunkId: item.chunk, moved: true, marker: item.unit.marker, segments: [{ text: item.unit.text, status: 'same', impact: null }] });
      continue;
    }

    const cache = {};
    const segs = [];

    if (chunk.kind === 'added' || chunk.scope === 'document') {
      const statuses = newWords.map(() => 'added');
      for (let i = 0; i < newWords.length; i += 1) {
        if (evals >= maxEvals) {
          truncated = true;
          segs.push({ text: newWords[i], status: 'added', impact: null });
        } else {
          // eslint-disable-next-line no-await-in-loop
          segs.push({ text: newWords[i], status: 'added', impact: await addedImpact(unitIndex, newWords, statuses, i, cache) });
        }
      }
      lines.push({ key: `ins-${item.b}`, unitIndex, ghost: false, chunkId: item.chunk, marker: item.unit.marker, segments: segs });
      continue;
    }

    // changed line: word diff between the paired old unit and this new unit
    const oldWords = chunk.oldUnits[0].text.split(' ');
    const ops = diffWords(chunk.oldUnits[0].text, item.unit.text);
    const statuses = ops.filter((o) => o.op !== 'del').map((o) => (o.op === 'eq' ? 'same' : 'added'));
    let bPos = 0; // v2 words emitted so far
    let aPos = 0; // v1 words consumed so far
    for (const op of ops) {
      if (op.op === 'eq') {
        segs.push({ text: op.word, status: 'same', impact: null });
        bPos += 1;
        aPos += 1;
      } else if (op.op === 'ins') {
        if (evals >= maxEvals) {
          truncated = true;
          segs.push({ text: op.word, status: 'added', impact: null });
        } else {
          // eslint-disable-next-line no-await-in-loop
          segs.push({ text: op.word, status: 'added', impact: await addedImpact(unitIndex, newWords, statuses, bPos, cache) });
        }
        bPos += 1;
      } else {
        if (evals >= maxEvals) {
          truncated = true;
          segs.push({ text: op.word, status: 'removed', impact: null });
        } else {
          // eslint-disable-next-line no-await-in-loop
          segs.push({ text: op.word, status: 'removed', impact: await removedImpact(unitIndex, newWords, bPos, oldWords, aPos, cache) });
        }
        aPos += 1;
      }
    }
    lines.push({ key: `chg-${item.b}`, unitIndex, ghost: false, chunkId: item.chunk, marker: item.unit.marker, segments: segs });
  }

  return { lines, truncated, evaluated: evals };
}
