/**
 * analysis.js
 * ---------------------------------------------------------------------------
 * The orchestrator the UI talks to:
 *
 *   validateInputs()      friendly, specific problems with the inputs
 *   analyzeEditImpact()   diff -> counterfactual attribution -> next best edits
 *                         -> word-level impact, returned as ONE plain object
 *
 * It never throws for bad user input: invalid input returns { ok: false, validation }.
 */

import { MAX_CHARS, MAX_JD_CHARS, MAX_LINES, MIN_WORDS_WARN } from './constants.js';
import { attributeChanges } from './attribution.js';
import { computeNextBestEdits } from './nextBest.js';
import { buildJdModel, resolveJd } from './scoring.js';
import { countWords, normalizeText, parseUnits } from './text.js';
import { computeWordImpact } from './wordImpact.js';

const defaultYield = () => new Promise((resolve) => setTimeout(resolve, 0));
const fmt = (n) => Number(n).toLocaleString('en-US');

/** Check one resume text. Returns { error?, warning? }. */
function checkResume(label, text) {
  const clean = normalizeText(text);
  if (!clean) return { error: `Paste or upload ${label} to continue.` };
  if (!/[A-Za-z]/.test(clean)) return { error: `${label} does not contain readable text. Paste plain text or upload a text-based PDF/DOCX.` };
  if (clean.length > MAX_CHARS) {
    return {
      error: `${label} is too long (${fmt(clean.length)} characters). The limit is ${fmt(MAX_CHARS)}, which is far more than a normal resume. Did you paste more than one document?`,
    };
  }
  const lines = parseUnits(clean).length;
  if (lines > MAX_LINES) return { error: `${label} has too many lines (${fmt(lines)}). The limit is ${fmt(MAX_LINES)}.` };
  const words = countWords(clean);
  if (words < MIN_WORDS_WARN) {
    return { warning: `${label} is very short (${words} word${words === 1 ? '' : 's'}). Scores for very short text are low and not very meaningful.` };
  }
  return {};
}

/**
 * Validate the three inputs.
 * @returns {{ ok: boolean, errors: {v1?: string, v2?: string, jd?: string}, warnings: string[], notes: string[] }}
 */
export function validateInputs({ v1Text = '', v2Text = '', jdText = '' } = {}) {
  const errors = {};
  const warnings = [];
  const notes = [];

  const r1 = checkResume('Resume v1', v1Text);
  const r2 = checkResume('Resume v2', v2Text);
  if (r1.error) errors.v1 = r1.error;
  if (r1.warning) warnings.push(r1.warning);
  if (r2.error) errors.v2 = r2.error;
  if (r2.warning) warnings.push(r2.warning);

  const jd = normalizeText(jdText);
  if (jd.length > MAX_JD_CHARS) {
    errors.jd = `The job description is too long (${fmt(jd.length)} characters). The limit is ${fmt(MAX_JD_CHARS)}.`;
  } else if (!jd) {
    notes.push('No job description: keyword matching is skipped and its 35 points are shared across the other categories.');
  } else {
    const model = buildJdModel(jd);
    if (!model.hasJD) {
      warnings.push('No usable keywords were found in the job description, so it was ignored. Paste the full job posting for keyword matching.');
    } else if (model.keywords.length < 5) {
      warnings.push('The job description is very short, so keyword matching may be unreliable.');
    }
  }

  return { ok: Object.keys(errors).length === 0, errors, warnings, notes };
}

/**
 * Run the full Edit Impact analysis.
 *
 * @param {{v1Text: string, v2Text: string, jdText?: string}} input
 * @param {{yieldFn?: () => Promise<void>}} [options]  yieldFn lets the UI repaint between heavy steps
 * @returns {Promise<{ok: false, validation: object} | object>}
 */
export async function analyzeEditImpact(input, options = {}) {
  const yieldFn = options.yieldFn || defaultYield;
  const validation = validateInputs(input);
  if (!validation.ok) return { ok: false, validation };

  const unitsA = parseUnits(input.v1Text);
  const unitsB = parseUnits(input.v2Text);
  const jdModel = resolveJd(normalizeText(input.jdText || '') || null);

  await yieldFn();
  const attribution = attributeChanges(unitsA, unitsB, jdModel);

  await yieldFn();
  const nextBest = computeNextBestEdits(unitsB, jdModel, { limit: 3 });

  await yieldFn();
  const words = attribution.identical
    ? { lines: [], truncated: false, evaluated: 0 }
    : await computeWordImpact({ unitsB, attribution, jdModel, yieldFn, maxEvals: options.maxWordEvals });

  return {
    ok: true,
    validation,
    identical: attribution.identical,
    hasJD: attribution.after.hasJD,
    before: attribution.before,
    after: attribution.after,
    chunks: attribution.chunks,
    totalTenths: attribution.totalTenths,
    sumTenths: attribution.sumTenths,
    interactionTenths: attribution.interactionTenths,
    nextBest,
    wordLines: words.lines,
    wordTruncated: words.truncated,
    attribution, // kept for Undo (revertChunkText)
    unitsA,
    unitsB,
  };
}
