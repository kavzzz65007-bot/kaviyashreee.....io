/**
 * attribution.js
 * ---------------------------------------------------------------------------
 * COUNTERFACTUAL ATTRIBUTION for the Edit Impact Tracker.
 *
 * For every chunk of the v1 -> v2 diff we ask: "if I applied ONLY this chunk to
 * v1, how much would the score change?" That delta is the chunk's attributed
 * score. Edits can interact (e.g. the "50% of bullets need numbers" cap), so
 * the individual deltas rarely add up to the total change exactly. The gap is
 * reported as an explicit row:
 *
 *      interaction = (score(v2) - score(v1)) - sum(individual deltas)
 *
 * so   sum(deltas) + interaction === total change   ALWAYS.
 * All arithmetic is done on integer TENTHS of a point to avoid float drift.
 */

import { SECTION_LABELS } from './constants.js';
import {
  applyAll,
  applyAllExcept,
  applyOnly,
  computeEditScript,
  diffWords,
} from './diff.js';
import {
  findWeakPhrases,
  hasMetric,
  jdKeywordsIn,
  resolveJd,
  scoreStructure,
  startsWithActionVerb,
} from './scoring.js';
import { countWords, detectHeading, structureFromUnits, unitsToText } from './text.js';

/* ------------------------------------------------------------------ */
/* Labels                                                              */
/* ------------------------------------------------------------------ */

const sectionName = (key) => SECTION_LABELS[key] || 'Resume';
const plural = (n, one, many = `${one}s`) => `${n} ${n === 1 ? one : many}`;

/** Position of a bullet among the bullets of its own section (1-based). */
function bulletOrdinal(structure, unitIndex) {
  const b = structure.bullets.find((x) => x.index === unitIndex);
  if (!b) return null;
  return structure.bullets.filter((x) => x.section === b.section && x.index <= unitIndex).length;
}

/** Human description of where a unit lives: "bullet 3", "line 2". */
function whereIs(structure, unitIndex) {
  const line = structure.lines[unitIndex];
  if (!line) return 'line';
  const ord = bulletOrdinal(structure, unitIndex);
  if (ord) return `bullet ${ord}`;
  return `line ${line.sectionLine}`;
}

const splitList = (text) =>
  String(text)
    .split(/[,;|•·]+/)
    .map((s) => s.trim())
    .filter(Boolean);

function isListLike(text) {
  const items = splitList(text);
  if (items.length < 3) return false;
  const avgWords = items.reduce((s, i) => s + countWords(i), 0) / items.length;
  return avgWords <= 3.5;
}

const clip = (arr, n = 3) => (arr.length > n ? `${arr.slice(0, n).join(', ')}…` : arr.join(', '));

/** Compare two list lines ("Python, SQL" vs "Python, SQL, Docker"). */
function listDiff(oldText, newText) {
  const oldItems = splitList(oldText);
  const newItems = splitList(newText);
  const oldSet = new Set(oldItems.map((i) => i.toLowerCase()));
  const newSet = new Set(newItems.map((i) => i.toLowerCase()));
  return {
    added: newItems.filter((i) => !oldSet.has(i.toLowerCase())),
    removed: oldItems.filter((i) => !newSet.has(i.toLowerCase())),
  };
}

/** Build the human readable label for one chunk (no score info yet). */
export function describeChunk(chunk, ctx) {
  const { structA, structB, jdModel } = ctx;
  const oldU = chunk.oldUnits[0];
  const newU = chunk.newUnits[0];

  if (chunk.scope === 'document') {
    return { label: 'Rewrote the whole document', tag: 'Rewrite', type: 'rewrite' };
  }

  /* ---------------- edited line ---------------- */
  if (chunk.kind === 'changed') {
    const lineB = structB.lines[chunk.newIndex];
    const section = lineB ? lineB.section : 'header';

    if (lineB && lineB.kind === 'heading') {
      return {
        label: `Renamed heading "${oldU.text}" to "${newU.text}"`,
        tag: 'Heading',
        type: 'heading',
      };
    }
    if (oldU.text === newU.text) {
      return { label: `Changed bullet style in ${sectionName(section)}`, tag: 'Formatting', type: 'formatting' };
    }

    if (section === 'skills' || (isListLike(oldU.text) && isListLike(newU.text))) {
      const { added, removed } = listDiff(oldU.text, newU.text);
      if (added.length || removed.length) {
        const parts = [];
        if (added.length) parts.push(`+${clip(added)}`);
        if (removed.length) parts.push(`−${clip(removed)}`);
        const tag = `${sectionName(section)} ${added.length ? `+${added.length}` : ''}${removed.length ? ` −${removed.length}` : ''}`.trim();
        return { label: `${sectionName(section)} updated: ${parts.join('  ')}`, tag, type: 'keywords' };
      }
      return { label: `Reordered items in ${sectionName(section)}`, tag: 'Reorder', type: 'reword' };
    }

    // Bullets get metric / verb / weak-phrase labels; other lines (summary,
    // education ...) are only described by keywords and wording.
    const isBullet = Boolean(lineB && lineB.kind === 'bullet');
    const where = isBullet
      ? whereIs(structB, chunk.newIndex)
      : `${sectionName(section)} line ${lineB ? lineB.sectionLine : 1}`;
    const kOld = jdKeywordsIn(oldU.text, jdModel);
    const kNew = jdKeywordsIn(newU.text, jdModel);
    const oldStems = new Set(kOld.map((k) => k.stem));
    const newStems = new Set(kNew.map((k) => k.stem));
    const gained = kNew.filter((k) => !oldStems.has(k.stem));
    const lost = kOld.filter((k) => !newStems.has(k.stem));

    // Every effect we can detect, most important first. The first one becomes
    // the label, the rest are listed as "also ...".
    const effects = [];
    if (isBullet) {
      const mOld = hasMetric(oldU.text);
      const mNew = hasMetric(newU.text);
      const vOld = startsWithActionVerb(oldU.text);
      const vNew = startsWithActionVerb(newU.text);
      const wOld = findWeakPhrases(oldU.text).length;
      const wNew = findWeakPhrases(newU.text).length;
      if (!mOld && mNew) effects.push({ label: `Added metric to ${where}`, tag: `Metric · ${where}`, type: 'metric', short: 'added a metric' });
      if (mOld && !mNew) effects.push({ label: `Removed metric from ${where}`, tag: `−Metric · ${where}`, type: 'metric', short: 'removed a metric' });
      if (wOld > 0 && wNew === 0) effects.push({ label: `Replaced weak phrase in ${where}`, tag: `Weak fixed · ${where}`, type: 'weak', short: 'removed a weak phrase' });
      if (wOld === 0 && wNew > 0) effects.push({ label: `Introduced a weak phrase in ${where}`, tag: `Weak · ${where}`, type: 'weak', short: 'introduced a weak phrase' });
      if (!vOld && vNew) effects.push({ label: `Strengthened opening verb in ${where}`, tag: `Verb · ${where}`, type: 'verb', short: 'strengthened the opening verb' });
      if (vOld && !vNew) effects.push({ label: `Weakened opening verb in ${where}`, tag: `−Verb · ${where}`, type: 'verb', short: 'weakened the opening verb' });
    }
    if (gained.length) {
      const names = clip(gained.map((k) => k.display));
      effects.push({ label: `Added keywords to ${where}: ${names}`, tag: `Keywords · ${where}`, type: 'keywords', short: `added keywords (${names})` });
    }
    if (lost.length) {
      const names = clip(lost.map((k) => k.display));
      effects.push({ label: `Dropped keywords from ${where}: ${names}`, tag: `−Keywords · ${where}`, type: 'keywords', short: `dropped keywords (${names})` });
    }
    if (effects.length) {
      const [first, ...rest] = effects;
      return {
        label: first.label,
        tag: first.tag,
        type: first.type,
        detail: rest.length ? `Also: ${rest.map((e) => e.short).join(', ')}.` : null,
      };
    }
    const diffWc = countWords(newU.text) - countWords(oldU.text);
    if (diffWc >= 5) return { label: `Expanded ${where}`, tag: `Expand · ${where}`, type: 'reword' };
    if (diffWc <= -5) return { label: `Shortened ${where}`, tag: `Shorten · ${where}`, type: 'reword' };
    return { label: `Reworded ${where}`, tag: `Reword · ${where}`, type: 'reword' };
  }

  /* ---------------- added ---------------- */
  if (chunk.kind === 'added') {
    const lineB = structB.lines[chunk.newIndex];
    const section = lineB ? lineB.section : 'header';
    if (chunk.scope === 'section') {
      const heading = chunk.newUnits[0].text;
      const body = chunk.newUnits.length - 1;
      return {
        label: `Added section: ${heading}${body ? ` (${plural(body, 'line')})` : ''}`,
        tag: `+ ${heading}`,
        type: 'add',
      };
    }
    const where = whereIs(structB, chunk.newIndex);
    const extra = lineB && lineB.kind === 'bullet' && hasMetric(newU.text) ? ' with a metric' : '';
    return {
      label: `Added ${where} to ${sectionName(section)}${extra}`,
      tag: `+ ${where}`,
      type: 'add',
    };
  }

  /* ---------------- removed ---------------- */
  if (chunk.kind === 'removed') {
    const lineA = structA.lines[chunk.oldIndex];
    const section = lineA ? lineA.section : 'header';
    if (chunk.scope === 'section') {
      const heading = chunk.oldUnits[0].text;
      const body = chunk.oldUnits.length - 1;
      return {
        label: `Removed section: ${heading}${body ? ` (${plural(body, 'line')})` : ''}`,
        tag: `− ${heading}`,
        type: 'remove',
      };
    }
    const where = whereIs(structA, chunk.oldIndex);
    return {
      label: `Removed ${where} from ${sectionName(section)}`,
      tag: `− ${where}`,
      type: 'remove',
    };
  }

  /* ---------------- moved ---------------- */
  if (chunk.scope === 'section') {
    const heading = chunk.oldUnits[0].text;
    const key = detectHeading(heading);
    const from = structA.headingOrder.indexOf(key) + 1;
    const to = structB.headingOrder.indexOf(key) + 1;
    return {
      label: `Moved section: ${heading}${from && to ? ` (position ${from} → ${to})` : ''}`,
      tag: `Move · ${heading}`,
      type: 'move',
    };
  }
  const secOld = structA.lines[chunk.oldIndex]?.section;
  const secNew = structB.lines[chunk.newIndex]?.section;
  const n = chunk.newUnits.length;
  return {
    label:
      secOld === secNew
        ? `Reordered ${plural(n, 'line')} in ${sectionName(secNew)}`
        : `Moved ${plural(n, 'line')} from ${sectionName(secOld)} to ${sectionName(secNew)}`,
    tag: `Move · ${plural(n, 'line')}`,
    type: 'move',
  };
}

/* ------------------------------------------------------------------ */
/* Attribution                                                         */
/* ------------------------------------------------------------------ */

/**
 * Attribute the v1 -> v2 score change to individual chunks.
 *
 * @param {Array} unitsA  units of v1
 * @param {Array} unitsB  units of v2
 * @param {string|object|null} jd  job description text or model
 */
export function attributeChanges(unitsA, unitsB, jd) {
  const jdModel = resolveJd(jd);
  const { script, chunks } = computeEditScript(unitsA, unitsB);

  const structA = structureFromUnits(unitsA);
  const structB = structureFromUnits(unitsB);
  const before = scoreStructure(structA, jdModel);
  const after = scoreStructure(structB, jdModel);
  const ctx = { structA, structB, jdModel };

  const results = chunks.map((chunk) => {
    // Counterfactual: v1 with ONLY this chunk applied.
    const only = scoreStructure(structureFromUnits(applyOnly(script, chunk.id)), jdModel);
    const deltaTenths = only.totalTenths - before.totalTenths;
    const meta = describeChunk(chunk, ctx);
    return {
      id: chunk.id,
      kind: chunk.kind,
      scope: chunk.scope,
      ...meta,
      deltaTenths,
      delta: deltaTenths / 10,
      regression: deltaTenths < 0,
      oldText: chunk.oldUnits.map((u) => u.raw).join('\n'),
      newText: chunk.newUnits.map((u) => u.raw).join('\n'),
      oldIndex: chunk.oldIndex,
      newIndex: chunk.newIndex,
      note:
        chunk.kind === 'moved' && deltaTenths === 0 && chunk.scope === 'section'
          ? 'Layout only: section order is not scored.'
          : null,
    };
  });

  const totalTenths = after.totalTenths - before.totalTenths;
  const sumTenths = results.reduce((s, r) => s + r.deltaTenths, 0);
  const interactionTenths = totalTenths - sumTenths; // exact, integer arithmetic

  return {
    before,
    after,
    jdModel,
    structA,
    structB,
    script,
    rawChunks: chunks,
    chunks: results,
    totalTenths,
    sumTenths,
    interactionTenths,
    identical: chunks.length === 0,
  };
}

/** Units of v2 with ONE chunk reverted (everything else stays as in v2). */
export function revertChunkUnits(attribution, chunkId) {
  return applyAllExcept(attribution.script, attribution.rawChunks, chunkId);
}

/** Text of v2 with ONE chunk reverted - what the "Undo" button puts back in the editor. */
export function revertChunkText(attribution, chunkId) {
  return unitsToText(revertChunkUnits(attribution, chunkId));
}

/** Units with every chunk applied (equals v2). Exposed for tests. */
export const allChunksUnits = (attribution) => applyAll(attribution.script, attribution.rawChunks);

/** Exposed for the word-level view. */
export { diffWords };
