/**
 * demoData.js
 * ---------------------------------------------------------------------------
 * Sample v1, v2 and job description used by the "Load Demo Data" button.
 * The two resumes are fictional. v2 deliberately contains:
 *   - edits that raise the score (metrics, strong verbs, keywords),
 *   - edits that LOWER it (a removed achievement, a new vague bullet),
 *   - a section move (Skills moved above Experience),
 * so every part of the Edit Impact Tracker has something to show.
 */

export const DEMO_V1 = `ALEX MORGAN
alex.morgan@example.com | +1 415 555 0198 | San Francisco, CA | github.com/alexmorgan

SUMMARY
Hard worker and team player with experience in software development. Looking for a new opportunity to grow my career.

EXPERIENCE
Software Engineer | BrightPath Software | Jan 2022 - Present
- Responsible for building web application features for the customer portal
- Worked on the API and fixed various bugs and other stuff
- Helped with deployments and testing of releases
- Mentored three junior developers and ran weekly code reviews for the whole team
- Wrote unit tests for backend services using Python and pytest

Junior Developer | Northwind Labs | Jun 2020 - Dec 2021
- Assisted with maintaining internal tools for the operations team
- Built a reporting script in Python that saved the finance team 5 hours every week
- Participated in daily standups and sprint planning

EDUCATION
B.S. in Computer Science | University of California, Davis | 2020

SKILLS
Python, JavaScript, SQL, Git, HTML, CSS`;

export const DEMO_V2 = `ALEX MORGAN
alex.morgan@example.com | +1 415 555 0198 | San Francisco, CA | github.com/alexmorgan

SUMMARY
Backend-leaning software engineer with 4 years of experience building cloud services in Python and TypeScript.

SKILLS
Python, JavaScript, TypeScript, SQL, Git, React, Node.js, Kubernetes, Terraform, HTML, CSS

EXPERIENCE
Software Engineer | BrightPath Software | Jan 2022 - Present
- Built dashboards for the customer portal used by 1,200 customers, cutting support tickets by 35%
- Reduced API response time from 800ms to 250ms by adding Redis caching and tuning PostgreSQL queries
- Containerized services with Docker and automated CI/CD pipelines on AWS, shipping releases 3x faster
- Wrote unit tests for backend services using Python and pytest

Junior Developer | Northwind Labs | Jun 2020 - Dec 2021
- Assisted with maintaining internal tools for the operations team
- Assisted with various tasks and other things as needed
- Built a reporting script in Python that saved the finance team 5 hours every week

EDUCATION
B.S. in Computer Science | University of California, Davis | 2020

PROJECTS
- Launched an open-source CLI tool that reached 400+ GitHub stars
- Built a Node.js microservice handling 2M requests per day`;

export const DEMO_JD = `Senior Backend Engineer - Cloud Platform

About the role
We are looking for a backend engineer to design, build and scale microservices that power our cloud platform. You will work with Python, TypeScript and Node.js, deploy on AWS with Docker and Kubernetes, and own CI/CD pipelines.

Requirements
- 3+ years of experience building REST APIs and microservices in Python or Node.js
- Strong knowledge of PostgreSQL, Redis and SQL performance tuning
- Hands-on experience with Docker, Kubernetes and AWS
- Experience with CI/CD, automated testing and monitoring
- Track record of mentoring engineers and improving system performance
- Familiarity with React is a plus

Nice to have: GraphQL, Terraform, Agile practices.`;
