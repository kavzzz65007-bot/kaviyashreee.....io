/**
 * diff.js
 * ---------------------------------------------------------------------------
 * Splits the difference between two resumes (arrays of "units", see text.js)
 * into independent CHUNKS that can each be applied (or reverted) on their own.
 *
 * How it stays consistent
 * -----------------------
 * 1. We compute one global line-level edit script (LCS) between v1 and v2.
 *    The script is an ordered list of items:
 *        eq  - a unit that is identical in both versions
 *        del - a unit that only exists in v1
 *        ins - a unit that only exists in v2
 * 2. Every del / ins item belongs to exactly ONE chunk (chunk.id).
 * 3. Building a document = walk the script and
 *        eq  -> always keep
 *        del -> keep unless its chunk is applied
 *        ins -> keep only if its chunk is applied
 *    so   applying NO chunks  gives v1 exactly,
 *         applying ALL chunks gives v2 exactly,
 *         applying any subset gives a well-formed in-between document.
 *
 * Chunk kinds: changed (a bullet rewritten), added, removed, moved
 * (identical lines that changed position - e.g. a whole section moved).
 */

import { detectHeading } from './text.js';

const SIM_THRESHOLD = 0.35; // min word overlap to call two lines "the same line, edited"
const MAX_LCS_CELLS = 6_000_000;
const MAX_PAIR_CELLS = 1_000_000;

/* ------------------------------------------------------------------ */
/* LCS over arbitrary string arrays                                     */
/* ------------------------------------------------------------------ */

/**
 * Longest-common-subsequence edit ops between two key arrays.
 * Returns [{ op: 'eq'|'del'|'ins', a, b }] in document order
 * (a = index in A for eq/del, b = index in B for eq/ins).
 */
export function lcsOps(keysA, keysB) {
  const n = keysA.length;
  const m = keysB.length;
  let start = 0;
  while (start < n && start < m && keysA[start] === keysB[start]) start += 1;
  let endA = n;
  let endB = m;
  while (endA > start && endB > start && keysA[endA - 1] === keysB[endB - 1]) {
    endA -= 1;
    endB -= 1;
  }

  const ops = [];
  for (let i = 0; i < start; i += 1) ops.push({ op: 'eq', a: i, b: i });

  const N = endA - start;
  const M = endB - start;
  if ((N + 1) * (M + 1) > MAX_LCS_CELLS) {
    // Too big for the quadratic table: treat the middle as fully replaced.
    for (let i = start; i < endA; i += 1) ops.push({ op: 'del', a: i, b: null });
    for (let j = start; j < endB; j += 1) ops.push({ op: 'ins', a: null, b: j });
  } else if (N === 0 || M === 0) {
    for (let i = start; i < endA; i += 1) ops.push({ op: 'del', a: i, b: null });
    for (let j = start; j < endB; j += 1) ops.push({ op: 'ins', a: null, b: j });
  } else {
    const W = M + 1;
    const dp = new Uint32Array((N + 1) * (M + 1));
    for (let i = N - 1; i >= 0; i -= 1) {
      for (let j = M - 1; j >= 0; j -= 1) {
        dp[i * W + j] =
          keysA[start + i] === keysB[start + j]
            ? dp[(i + 1) * W + j + 1] + 1
            : Math.max(dp[(i + 1) * W + j], dp[i * W + j + 1]);
      }
    }
    let i = 0;
    let j = 0;
    while (i < N && j < M) {
      if (keysA[start + i] === keysB[start + j]) {
        ops.push({ op: 'eq', a: start + i, b: start + j });
        i += 1;
        j += 1;
      } else if (dp[(i + 1) * W + j] >= dp[i * W + j + 1]) {
        ops.push({ op: 'del', a: start + i, b: null });
        i += 1;
      } else {
        ops.push({ op: 'ins', a: null, b: start + j });
        j += 1;
      }
    }
    while (i < N) {
      ops.push({ op: 'del', a: start + i, b: null });
      i += 1;
    }
    while (j < M) {
      ops.push({ op: 'ins', a: null, b: start + j });
      j += 1;
    }
  }

  for (let k = 0; k < n - endA; k += 1) ops.push({ op: 'eq', a: endA + k, b: endB + k });
  return ops;
}

/** Word-level diff of two strings -> [{ op, word }]. Used for labels + highlighting. */
export function diffWords(oldText, newText) {
  const A = String(oldText || '').split(' ').filter(Boolean);
  const B = String(newText || '').split(' ').filter(Boolean);
  return lcsOps(A, B).map((o) => ({
    op: o.op,
    word: o.op === 'ins' ? B[o.b] : A[o.a],
  }));
}

/* ------------------------------------------------------------------ */
/* Pairing deleted + inserted lines into "changed" lines                */
/* ------------------------------------------------------------------ */

const wordSet = (s) => new Set(String(s).toLowerCase().split(/[^a-z0-9+#]+/).filter(Boolean));

function similarity(a, b) {
  const A = wordSet(a);
  const B = wordSet(b);
  if (A.size === 0 || B.size === 0) return 0;
  let inter = 0;
  for (const w of A) if (B.has(w)) inter += 1;
  return inter / (A.size + B.size - inter);
}

/** Section key of every unit (scanning headings top to bottom). */
function sectionsOf(units) {
  let current = 'header';
  return units.map((u) => {
    const key = u.marker ? null : detectHeading(u.text);
    if (key) current = key;
    return current;
  });
}

/**
 * Pair deleted and inserted units of one run.
 *  1. best monotone matching by word overlap (clear edits of the same line),
 *  2. leftovers between those anchors are paired by POSITION when they sit in
 *     the same section ("bullet 2 was rewritten in place").
 * Identical lines are never paired here (they become "moved" chunks instead).
 * Headings only ever pair through step 1.
 * Returns [[delIndex, insIndex], ...] with both indexes strictly increasing.
 */
function pairRun(dels, inses, delSecs, insSecs) {
  const anchors = similarityPairs(dels, inses);
  const D = dels.length;
  const I = inses.length;
  const out = [];
  const all = [[-1, -1], ...anchors, [D, I]];
  for (let k = 0; k < all.length - 1; k += 1) {
    if (k > 0) out.push(all[k]);
    const [d0, i0] = all[k];
    const [d1, i1] = all[k + 1];
    let di = d0 + 1;
    let ii = i0 + 1;
    while (di < d1 && ii < i1) {
      const dh = isHeadingUnit(dels[di]);
      const ih = isHeadingUnit(inses[ii]);
      if (dh) di += 1;
      else if (ih) ii += 1;
      else {
        if (delSecs[di] === insSecs[ii] && dels[di].raw !== inses[ii].raw) out.push([di, ii]);
        di += 1;
        ii += 1;
      }
    }
  }
  return out;
}

/** Monotone best matching by word overlap (step 1 of pairRun). */
function similarityPairs(dels, inses) {
  const D = dels.length;
  const I = inses.length;
  if (D === 0 || I === 0 || D * I > MAX_PAIR_CELLS) return [];

  const w = new Float64Array(D * I).fill(-1);
  for (let i = 0; i < D; i += 1) {
    for (let j = 0; j < I; j += 1) {
      if (dels[i].raw === inses[j].raw) continue;
      const s = similarity(dels[i].text, inses[j].text);
      if (s >= SIM_THRESHOLD) w[i * I + j] = s;
    }
  }

  const W = I + 1;
  const dp = new Float64Array((D + 1) * (I + 1));
  for (let i = D - 1; i >= 0; i -= 1) {
    for (let j = I - 1; j >= 0; j -= 1) {
      let best = Math.max(dp[(i + 1) * W + j], dp[i * W + j + 1]);
      const s = w[i * I + j];
      if (s > 0) best = Math.max(best, s + dp[(i + 1) * W + j + 1]);
      dp[i * W + j] = best;
    }
  }

  const pairs = [];
  let i = 0;
  let j = 0;
  while (i < D && j < I) {
    const s = w[i * I + j];
    if (s > 0 && Math.abs(dp[i * W + j] - (s + dp[(i + 1) * W + j + 1])) < 1e-9) {
      pairs.push([i, j]);
      i += 1;
      j += 1;
    } else if (Math.abs(dp[i * W + j] - dp[(i + 1) * W + j]) < 1e-9) {
      i += 1;
    } else {
      j += 1;
    }
  }
  return pairs;
}

/* ------------------------------------------------------------------ */
/* Edit script + chunks                                                 */
/* ------------------------------------------------------------------ */

function isHeadingUnit(u) {
  return !u.marker && Boolean(detectHeading(u.text));
}

/** Group free (unpaired) items: a heading starts a section group, bullets stand alone. */
function groupFree(items, key) {
  const sorted = items.slice().sort((x, y) => x[key] - y[key]);
  const groups = [];
  let cur = null;
  for (const it of sorted) {
    const heading = isHeadingUnit(it.unit);
    if (cur && cur.startsWithHeading && !heading && it[key] === cur.last + 1) {
      cur.items.push(it);
      cur.last = it[key];
    } else {
      cur = { items: [it], startsWithHeading: heading, last: it[key] };
      groups.push(cur);
    }
  }
  return groups;
}

const KIND_ORDER = { removed: 0, changed: 1, moved: 2, added: 3 };

/**
 * Build the edit script and the chunk list.
 * @returns {{ script: Array, chunks: Array }}
 */
export function computeEditScript(unitsA, unitsB) {
  const built = buildScript(unitsA, unitsB);
  // Safety net: if (through some unforeseen edge case) the invariants do not
  // hold, fall back to ONE chunk that replaces the whole document. The numbers
  // still add up, just with coarser granularity.
  if (!invariantsHold(built, unitsA, unitsB)) return wholeDocumentFallback(unitsA, unitsB);
  return built;
}

function buildScript(unitsA, unitsB) {
  const ops = lcsOps(
    unitsA.map((u) => u.raw),
    unitsB.map((u) => u.raw),
  );

  const secA = sectionsOf(unitsA);
  const secB = sectionsOf(unitsB);
  const script = [];
  const pairs = [];
  let run = [];

  const flushRun = () => {
    if (run.length === 0) return;
    const dels = run.filter((o) => o.op === 'del').map((o) => ({ type: 'del', unit: unitsA[o.a], a: o.a, b: null, chunk: null, paired: false }));
    const inses = run.filter((o) => o.op === 'ins').map((o) => ({ type: 'ins', unit: unitsB[o.b], a: null, b: o.b, chunk: null, paired: false }));
    const matched = pairRun(
      dels.map((d) => d.unit),
      inses.map((x) => x.unit),
      dels.map((d) => secA[d.a]),
      inses.map((x) => secB[x.b]),
    );
    let di = 0;
    let ii = 0;
    for (const [pd, pi] of matched) {
      while (di < pd) script.push(dels[di++]);
      while (ii < pi) script.push(inses[ii++]);
      dels[pd].paired = true;
      inses[pi].paired = true;
      script.push(dels[pd], inses[pi]);
      pairs.push({ del: dels[pd], ins: inses[pi] });
      di = pd + 1;
      ii = pi + 1;
    }
    while (di < dels.length) script.push(dels[di++]);
    while (ii < inses.length) script.push(inses[ii++]);
    run = [];
  };

  for (const op of ops) {
    if (op.op === 'eq') {
      flushRun();
      script.push({ type: 'eq', unit: unitsB[op.b], a: op.a, b: op.b, chunk: null });
    } else run.push(op);
  }
  flushRun();
  script.forEach((it, pos) => {
    it.pos = pos;
  });

  const rawChunks = [];

  // 1) Edited lines.
  for (const p of pairs) rawChunks.push({ kind: 'changed', scope: 'line', items: [p.del, p.ins] });

  // 2) Moves: an unpaired deleted line with an identical unpaired inserted line.
  const freeDel = script.filter((it) => it.type === 'del' && !it.paired).sort((x, y) => x.a - y.a);
  const freeIns = script.filter((it) => it.type === 'ins' && !it.paired);
  const queues = new Map();
  for (const it of freeIns.slice().sort((x, y) => x.b - y.b)) {
    if (!queues.has(it.unit.raw)) queues.set(it.unit.raw, []);
    queues.get(it.unit.raw).push(it);
  }
  const movePairs = [];
  for (const d of freeDel) {
    const q = queues.get(d.unit.raw);
    if (q && q.length) movePairs.push({ del: d, ins: q.shift() });
  }
  const moveGroups = [];
  for (const mp of movePairs) {
    const last = moveGroups[moveGroups.length - 1];
    const prev = last && last[last.length - 1];
    if (prev && mp.del.a === prev.del.a + 1 && mp.ins.b === prev.ins.b + 1) last.push(mp);
    else moveGroups.push([mp]);
  }
  const movedItems = new Set();
  for (const g of moveGroups) {
    const items = [...g.map((x) => x.del), ...g.map((x) => x.ins)];
    items.forEach((it) => movedItems.add(it));
    rawChunks.push({ kind: 'moved', scope: isHeadingUnit(g[0].del.unit) ? 'section' : 'lines', items });
  }

  // 3) Cross-run edits: a line that was both moved AND edited (e.g. the body of a
  //    section that was moved up). Same section + high word overlap.
  const restDel = freeDel.filter((it) => !movedItems.has(it));
  const restIns = freeIns.filter((it) => !movedItems.has(it));
  const crossPaired = new Set();
  if (restDel.length * restIns.length <= 250000) {
    const candidates = [];
    const setsDel = restDel.map((d) => wordSet(d.unit.text));
    const setsIns = restIns.map((x) => wordSet(x.unit.text));
    restDel.forEach((d, i) => {
      if (isHeadingUnit(d.unit) || setsDel[i].size < 3) return;
      restIns.forEach((x, j) => {
        if (isHeadingUnit(x.unit) || setsIns[j].size < 3 || secA[d.a] !== secB[x.b]) return;
        let inter = 0;
        for (const w of setsDel[i]) if (setsIns[j].has(w)) inter += 1;
        const overlap = inter / Math.min(setsDel[i].size, setsIns[j].size);
        if (overlap >= 0.6) candidates.push({ d, x, overlap, key: d.a * 100000 + x.b });
      });
    });
    candidates.sort((p, q) => q.overlap - p.overlap || p.key - q.key);
    for (const c of candidates) {
      if (crossPaired.has(c.d) || crossPaired.has(c.x)) continue;
      crossPaired.add(c.d);
      crossPaired.add(c.x);
      rawChunks.push({ kind: 'changed', scope: 'line', items: [c.d, c.x] });
    }
  }

  // 4) Remaining inserted lines -> added chunks; remaining deleted -> removed chunks.
  for (const g of groupFree(restIns.filter((it) => !crossPaired.has(it)), 'b')) {
    rawChunks.push({ kind: 'added', scope: g.startsWithHeading ? 'section' : 'line', items: g.items });
  }
  for (const g of groupFree(restDel.filter((it) => !crossPaired.has(it)), 'a')) {
    rawChunks.push({ kind: 'removed', scope: g.startsWithHeading ? 'section' : 'line', items: g.items });
  }

  // Order by first appearance in the script, then assign ids.
  const chunks = rawChunks
    .map((c) => ({ ...c, firstPos: Math.min(...c.items.map((it) => it.pos)) }))
    .sort((x, y) => x.firstPos - y.firstPos || KIND_ORDER[x.kind] - KIND_ORDER[y.kind])
    .map((c, i) => {
      const id = `c${i + 1}`;
      c.items.forEach((it) => {
        it.chunk = id;
      });
      const oldItems = c.items.filter((it) => it.type === 'del');
      const newItems = c.items.filter((it) => it.type === 'ins');
      return {
        id,
        kind: c.kind,
        scope: c.scope,
        items: c.items,
        oldUnits: oldItems.map((it) => it.unit),
        newUnits: newItems.map((it) => it.unit),
        oldIndex: oldItems.length ? Math.min(...oldItems.map((it) => it.a)) : null,
        newIndex: newItems.length ? Math.min(...newItems.map((it) => it.b)) : null,
        firstPos: c.firstPos,
      };
    });

  return { script, chunks };
}

function invariantsHold({ script, chunks }, unitsA, unitsB) {
  if (script.some((it) => it.type !== 'eq' && !it.chunk)) return false;
  const none = applyChunks(script, new Set());
  const all = applyChunks(script, new Set(chunks.map((c) => c.id)));
  const same = (x, y) => x.length === y.length && x.every((u, i) => u.raw === y[i].raw);
  return same(none, unitsA) && same(all, unitsB);
}

function wholeDocumentFallback(unitsA, unitsB) {
  const script = [];
  const items = [];
  unitsA.forEach((unit, a) => {
    const it = { type: 'del', unit, a, b: null, chunk: 'c1', paired: false, pos: script.length };
    script.push(it);
    items.push(it);
  });
  unitsB.forEach((unit, b) => {
    const it = { type: 'ins', unit, a: null, b, chunk: 'c1', paired: false, pos: script.length };
    script.push(it);
    items.push(it);
  });
  if (items.length === 0) return { script, chunks: [] };
  return {
    script,
    chunks: [
      {
        id: 'c1',
        kind: 'changed',
        scope: 'document',
        items,
        oldUnits: unitsA.slice(),
        newUnits: unitsB.slice(),
        oldIndex: unitsA.length ? 0 : null,
        newIndex: unitsB.length ? 0 : null,
        firstPos: 0,
      },
    ],
  };
}

/* ------------------------------------------------------------------ */
/* Applying chunks                                                      */
/* ------------------------------------------------------------------ */

/**
 * Build a unit array from the script with the given chunk ids applied.
 * @param {Array} script
 * @param {Set<string>} applied
 */
export function applyChunks(script, applied) {
  const out = [];
  for (const it of script) {
    if (it.type === 'eq') out.push(it.unit);
    else if (it.type === 'del') {
      if (!applied.has(it.chunk)) out.push(it.unit);
    } else if (applied.has(it.chunk)) out.push(it.unit);
  }
  return out;
}

export const applyAll = (script, chunks) => applyChunks(script, new Set(chunks.map((c) => c.id)));
export const applyNone = (script) => applyChunks(script, new Set());
export const applyOnly = (script, id) => applyChunks(script, new Set([id]));
export const applyAllExcept = (script, chunks, id) =>
  applyChunks(script, new Set(chunks.filter((c) => c.id !== id).map((c) => c.id)));
