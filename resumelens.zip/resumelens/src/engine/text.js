/**
 * text.js
 * ---------------------------------------------------------------------------
 * Text utilities and the resume "structure" parser.
 *
 * Pipeline:   raw text --parseUnits--> units --structureFromUnits--> structure
 *
 * A **unit** is one logical line of the resume (wrapped PDF lines are joined).
 * Units are the currency of the diff + attribution engines: chunks are applied
 * to arrays of units, and the scorer works on the structure built from them.
 * That way "apply chunk -> re-score" never has to re-parse (and re-wrap) text.
 */

import {
  BULLET_SECTIONS,
  SECTION_LOOKUP,
} from './constants.js';

/* ------------------------------------------------------------------ */
/* Normalisation + tokenising                                          */
/* ------------------------------------------------------------------ */

/**
 * Normalise raw text: unify newlines, strip control / zero-width chars,
 * expand ligatures (NFKC), convert tabs, trim trailing spaces.
 */
export function normalizeText(input) {
  let text = typeof input === 'string' ? input : '';
  try {
    text = text.normalize('NFKC');
  } catch {
    /* very old engines - ignore */
  }
  return text
    .replace(/\r\n?/g, '\n')
    .replace(/[​-‍﻿­]/g, '')
    .replace(/ /g, ' ')
    .replace(/\t/g, ' ')
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '')
    .replace(/[ ]+\n/g, '\n')
    .trim();
}

/** Count whitespace separated words. */
export function countWords(text) {
  if (!text) return 0;
  const m = String(text).trim().match(/\S+/g);
  return m ? m.length : 0;
}

/**
 * Tokens: letters/digits, optional inner dots (node.js, asp.net) and a
 * trailing +/# (c++, c#). Hyphens split words ("full-stack" -> full, stack).
 */
const TOKEN_RE = /[A-Za-z0-9]+(?:\.[A-Za-z0-9]+)*(?:\+\+|#|\+)?/g;

/** Tokenise returning both the raw and lower-case form of every token. */
export function tokenizeRaw(text) {
  const out = [];
  if (!text) return out;
  const matches = String(text).match(TOKEN_RE);
  if (!matches) return out;
  for (const raw of matches) out.push({ raw, lower: raw.toLowerCase() });
  return out;
}

/** Lower-case tokens only. */
export function tokenize(text) {
  return tokenizeRaw(text).map((t) => t.lower);
}

/** Collapse "node.js"/"nodejs"/"react.js" style variants onto one form. */
export function canonicalToken(token) {
  let t = token;
  if (t.length > 3 && t.endsWith('.js')) t = t.slice(0, -3);
  if (t === 'nodejs') return 'node';
  if (t === 'reactjs') return 'react';
  if (t === 'vuejs') return 'vue';
  return t;
}

/**
 * A tiny, deterministic stemmer. It does not need to be linguistically
 * correct - it only has to map "managed / manages / managing / manage" to the
 * same string, and to do so identically for the resume and the JD.
 */
export function stem(word) {
  let w = canonicalToken(word);
  if (w.length <= 3) return w;
  if (/[+#.]/.test(w)) return w; // tech tokens stay untouched
  if (w.endsWith('ies') && w.length > 4) return `${w.slice(0, -3)}y`;
  for (const suf of ['ing', 'ed', 'es', 's']) {
    if (w.endsWith(suf) && w.length - suf.length >= 3) {
      if (suf === 's' && w.endsWith('ss')) break;
      w = w.slice(0, -suf.length);
      break;
    }
  }
  if (w.endsWith('e') && w.length > 3) w = w.slice(0, -1);
  return w;
}

/* ------------------------------------------------------------------ */
/* Units                                                               */
/* ------------------------------------------------------------------ */

/** A bullet glyph (no space needed after it) or a dash / star / "1." (space needed). */
const GLYPH_MARKER_RE = /^[•●▪■◦○◆◇▶►‣⁃∙·-]\s*/;
const SPACED_MARKER_RE = /^(?:[*\-–—]|\d{1,2}[.)])\s+/;

/**
 * Build a unit from one already-trimmed line.
 *   raw    - the line with single spaces (the diff compares this)
 *   marker - the bullet prefix ("• ", "- ", "") exactly as written
 *   text   - the line without the marker
 */
export function makeUnit(line) {
  const raw = String(line).replace(/\s+/g, ' ').trim();
  let marker = '';
  const g = raw.match(GLYPH_MARKER_RE);
  if (g) marker = g[0];
  else {
    const s = raw.match(SPACED_MARKER_RE);
    if (s) marker = s[0];
  }
  return { raw, marker, text: raw.slice(marker.length).trim() };
}

/** Return a copy of `unit` with new body text but the same marker. */
export function withUnitText(unit, newText) {
  const body = String(newText).replace(/\s+/g, ' ').trim();
  const marker = unit.marker || '';
  return { raw: marker + body, marker, text: body };
}

/** Turn units back into text (one per line). */
export function unitsToText(units) {
  return units.map((u) => u.raw).join('\n');
}

/**
 * Detect a section heading. Returns the section key or null.
 * Headings are short lines whose letters match a known alias
 * ("WORK EXPERIENCE:", "Skills", "Education & Training" ...).
 */
export function detectHeading(text) {
  if (!text) return null;
  const cleaned = String(text)
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!cleaned) return null;
  if (cleaned.split(' ').length > 5) return null;
  return SECTION_LOOKUP.get(cleaned) ?? null;
}

/** True when `cur` looks like the wrapped continuation of bullet `prev`. */
function isContinuation(prev, cur) {
  if (!prev.marker || cur.marker) return false;
  if (detectHeading(cur.text)) return false;
  if (/^[a-z(]/.test(cur.text)) return true;
  return /(,|\b(and|or|of|to|with|for|in|by|on|the|a|an))$/i.test(prev.text);
}

/**
 * Split text into units. Handles: blank lines, a lone bullet glyph on its own
 * line (PDF exports), and wrapped bullet lines.
 */
export function parseUnits(text) {
  const lines = normalizeText(text).split('\n');
  const units = [];
  let pendingMarker = '';
  for (const rawLine of lines) {
    const line = rawLine.replace(/\s+/g, ' ').trim();
    if (!line) continue;
    let unit = makeUnit(line);
    if (!unit.text) {
      // A bullet glyph on its own line: remember it for the next line.
      pendingMarker = unit.marker ? unit.marker.trim() + ' ' : '';
      continue;
    }
    if (pendingMarker && !unit.marker) {
      unit = makeUnit(pendingMarker + line);
    }
    pendingMarker = '';
    const prev = units[units.length - 1];
    if (prev && isContinuation(prev, unit)) {
      units[units.length - 1] = makeUnit(`${prev.raw} ${unit.raw}`);
      continue;
    }
    units.push(unit);
  }
  return units;
}

/* ------------------------------------------------------------------ */
/* Structure                                                           */
/* ------------------------------------------------------------------ */

const EMAIL_RE = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/;
const PHONE_CANDIDATE_RE = /\+?\d[\d\s().-]{8,}\d/g;
const DATE_RE =
  /\b(?:19|20)\d{2}\b|\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s+\d{2,4}\b|\bpresent\b|\bcurrent\b/i;

/** True when the text contains an email address or a plausible phone number. */
export function hasContactInfo(text) {
  if (!text) return false;
  if (EMAIL_RE.test(text)) return true;
  const candidates = String(text).match(PHONE_CANDIDATE_RE) || [];
  return candidates.some((c) => {
    const digits = c.replace(/\D/g, '').length;
    return digits >= 10 && digits <= 15 && !c.includes(',');
  });
}

/** "Software Engineer | Acme Corp | Jan 2021 - Present" style lines. */
export function isMetaLine(text) {
  const w = countWords(text);
  if (w <= 14 && DATE_RE.test(text)) return true;
  if (w <= 12 && text.includes('|')) return true;
  return false;
}

/**
 * Build the structure the scorer works on.
 *
 * lines[i]   = { unit, index, kind: 'heading'|'bullet'|'text', section, sectionLine }
 * bullets[]  = achievement bullets (what metrics / verbs / weak phrases check)
 */
export function structureFromUnits(units) {
  const lines = [];
  const present = {};
  const headingOrder = [];
  let current = 'header';
  const perSectionCount = {};

  units.forEach((unit, index) => {
    const headingKey = unit.marker ? null : detectHeading(unit.text);
    if (headingKey) {
      current = headingKey;
      present[headingKey] = true;
      headingOrder.push(headingKey);
      perSectionCount[current] = 0;
      lines.push({ unit, index, kind: 'heading', section: headingKey, sectionLine: 0 });
      return;
    }
    perSectionCount[current] = (perSectionCount[current] || 0) + 1;
    lines.push({
      unit,
      index,
      kind: 'text',
      section: current,
      sectionLine: perSectionCount[current],
    });
  });

  // Primary rule: marker lines or long non-meta lines in experience/projects.
  let bulletLines = lines.filter((l) => {
    if (l.kind === 'heading' || !BULLET_SECTIONS.has(l.section)) return false;
    return Boolean(l.unit.marker) || (countWords(l.unit.text) >= 7 && !isMetaLine(l.unit.text));
  });

  // Fallback 1: any marker lines outside skills / education.
  if (bulletLines.length === 0) {
    bulletLines = lines.filter(
      (l) => l.kind !== 'heading' && l.unit.marker && l.section !== 'skills' && l.section !== 'education',
    );
  }
  // Fallback 2: long prose lines outside skills / education / summary.
  if (bulletLines.length === 0) {
    bulletLines = lines.filter(
      (l) =>
        l.kind !== 'heading' &&
        !['skills', 'education', 'summary'].includes(l.section) &&
        countWords(l.unit.text) >= 7 &&
        !isMetaLine(l.unit.text),
    );
  }

  const bullets = bulletLines.map((l, i) => {
    l.kind = 'bullet';
    return {
      index: l.index,
      text: l.unit.text,
      section: l.section,
      sectionLine: l.sectionLine,
      number: i + 1,
    };
  });

  const text = unitsToText(units);
  return {
    units,
    lines,
    bullets,
    present,
    headingOrder,
    wordCount: countWords(text),
    hasContact: hasContactInfo(text),
    text,
  };
}

/** Parse raw text all the way to a structure. */
export function parseResume(text) {
  return structureFromUnits(parseUnits(text));
}
