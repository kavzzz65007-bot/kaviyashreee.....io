/**
 * scoring.js
 * ---------------------------------------------------------------------------
 * Deterministic, rule-based ATS-style scoring (0-100) with a visible breakdown.
 *
 *   Keyword match vs JD ........ 35   (0 when no JD - weight is redistributed)
 *   Quantified metrics ......... 20
 *   Action verbs ............... 15
 *   Standard sections .......... 15
 *   Readability + weak phrases . 15
 *
 * No randomness, no clocks, no network: the same input always gives the same
 * score. Category scores are rounded to ONE decimal and the total is the sum
 * of those rounded values, so the breakdown always adds up to the total.
 */

import {
  ACTION_VERBS,
  BULLET_MAX_WORDS,
  BULLET_MIN_WORDS,
  CATEGORY_META,
  CORE_SECTIONS,
  JD_FILLER,
  LENGTH_CURVE,
  MAX_JD_KEYWORDS,
  METRIC_TARGET_SHARE,
  SHORT_TECH,
  STOPWORDS,
  VERB_TARGET_SHARE,
  VERSION_WORDS,
  WEAK_PHRASES,
  WEIGHTS_NO_JD,
  WEIGHTS_WITH_JD,
} from './constants.js';
import {
  countWords,
  parseResume,
  stem,
  tokenize,
  tokenizeRaw,
} from './text.js';

/* ------------------------------------------------------------------ */
/* Job description model                                               */
/* ------------------------------------------------------------------ */

const FILLER_STEMS = new Set([...JD_FILLER].map((w) => stem(w)));

/** Is this JD token worth treating as a keyword? */
function isKeywordCandidate(lower) {
  if (/^\d+(\.\d+)*$/.test(lower)) return false; // pure numbers
  if (lower.length < 3 && !SHORT_TECH.has(lower)) return false;
  if (STOPWORDS.has(lower) || JD_FILLER.has(lower)) return false;
  if (FILLER_STEMS.has(stem(lower))) return false;
  return true;
}

/**
 * Extract the keywords of a job description.
 * Ranking: how often the (stemmed) word appears, then where it first appears.
 * Weight of a keyword = min(count, 3) so repeated words matter more, but a
 * word repeated 20 times cannot dominate.
 */
export function buildJdModel(jdText) {
  const map = new Map();
  tokenizeRaw(jdText).forEach((t, order) => {
    if (!isKeywordCandidate(t.lower)) return;
    const key = stem(t.lower);
    let entry = map.get(key);
    if (!entry) {
      entry = { stem: key, count: 0, first: order, forms: new Map() };
      map.set(key, entry);
    }
    entry.count += 1;
    entry.forms.set(t.raw, (entry.forms.get(t.raw) || 0) + 1);
  });

  const keywords = [...map.values()]
    .sort((a, b) => b.count - a.count || a.first - b.first)
    .slice(0, MAX_JD_KEYWORDS)
    .map((e) => {
      let display = '';
      let best = 0;
      for (const [form, n] of e.forms) {
        if (n > best) {
          best = n;
          display = form;
        }
      }
      return { stem: e.stem, display, count: e.count, weight: Math.min(e.count, 3), order: e.first };
    });

  return {
    keywords,
    totalWeight: keywords.reduce((s, k) => s + k.weight, 0),
    hasJD: keywords.length > 0,
  };
}

/** Accept a JD as text, a prebuilt model, or nothing. */
export function resolveJd(jd) {
  if (!jd) return null;
  if (typeof jd === 'string') {
    const model = buildJdModel(jd);
    return model.hasJD ? model : null;
  }
  if (Array.isArray(jd.keywords) && jd.keywords.length > 0) return jd;
  return null;
}

/* ------------------------------------------------------------------ */
/* Feature detectors (used by scoring, labels and suggestions)         */
/* ------------------------------------------------------------------ */

const ACTION_STEMS = new Set(ACTION_VERBS.map((v) => stem(v)));

/**
 * A number that quantifies impact: %, $, 3x, 2k, 1,200, "5 engineers" ...
 * Years ("2023"), versions ("Java 8") and letter-attached numbers ("S3",
 * "HTML5", "3D") do not count.
 */
const NUMBER_RE =
  /(?<![A-Za-z0-9.])(?:[$€£₹]\s?)?\d[\d,]*(?:\.\d+)?(?:\s?%|\+|(?:ms|secs?|mins?|hrs?|gb|mb|kb|tb|qps|rps|fps|[kKmMbBhH]|[xX×])(?![A-Za-z0-9]))?(?![A-Za-z0-9])/g;

export function hasMetric(text) {
  const t = String(text || '').replace(/\b(?:19|20)\d{2}\b/g, ' ');
  for (const m of t.matchAll(NUMBER_RE)) {
    const words = t.slice(0, m.index).trimEnd().split(/\s+/);
    const before = (words[words.length - 1] || '').toLowerCase().replace(/[^a-z]/g, '');
    if (VERSION_WORDS.has(before)) continue;
    return true;
  }
  return false;
}

/** Does the bullet open with a strong action verb? */
export function startsWithActionVerb(text) {
  const first = tokenize(String(text || '').replace(/^[^A-Za-z]+/, ''))[0];
  return Boolean(first) && ACTION_STEMS.has(stem(first));
}

const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const WEAK_MATCHERS = WEAK_PHRASES.map((p) => ({
  ...p,
  re: new RegExp(`(?<![A-Za-z])${escapeRe(p.phrase).replace(/ /g, '\\s+')}(?![A-Za-z])`, 'i'),
}));

/** All weak / vague / cliché phrases found in a piece of text (longest-first order). */
export function findWeakPhrases(text) {
  const found = [];
  const t = String(text || '');
  for (const m of WEAK_MATCHERS) {
    if (m.re.test(t)) found.push(m);
  }
  // "helped with" also matches "helped": drop entries fully contained in a longer match.
  return found.filter(
    (f) => !found.some((g) => g !== f && g.phrase.length > f.phrase.length && g.phrase.includes(f.phrase)),
  );
}

/** How many JD keywords does this text contain? Returns the matched keyword objects. */
export function jdKeywordsIn(text, jdModel) {
  if (!jdModel) return [];
  const stems = new Set(tokenize(text).map((t) => stem(t)));
  return jdModel.keywords.filter((k) => stems.has(k.stem));
}

/** Piece-wise linear "ideal resume length" ratio for a word count. */
export function lengthRatio(wordCount) {
  const c = LENGTH_CURVE;
  if (wordCount <= c[0][0]) return c[0][1];
  for (let i = 1; i < c.length; i += 1) {
    if (wordCount <= c[i][0]) {
      const [x0, y0] = c[i - 1];
      const [x1, y1] = c[i];
      return y0 + ((y1 - y0) * (wordCount - x0)) / (x1 - x0);
    }
  }
  return c[c.length - 1][1];
}

/* ------------------------------------------------------------------ */
/* Per-bullet analysis (weak bullet detection)                         */
/* ------------------------------------------------------------------ */

/** Inspect every bullet and return the ones worth improving, each with ONE short suggestion. */
export function analyzeBullets(structure) {
  const flagged = [];
  for (const b of structure.bullets) {
    const words = countWords(b.text);
    const weak = findWeakPhrases(b.text);
    const issues = [];
    const weakKinds = weak.filter((w) => w.kind === 'weak' || w.kind === 'cliche');
    const vague = weak.filter((w) => w.kind === 'vague');
    if (weakKinds.length) issues.push('weak-phrase');
    if (vague.length) issues.push('vague');
    const verb = startsWithActionVerb(b.text);
    if (!verb && !weakKinds.length) issues.push('no-verb');
    const metric = hasMetric(b.text);
    if (words < BULLET_MIN_WORDS) issues.push('too-short');
    if (words > BULLET_MAX_WORDS) issues.push('too-long');

    const isWeak =
      issues.includes('weak-phrase') ||
      issues.includes('vague') ||
      issues.includes('no-verb') ||
      issues.includes('too-short') ||
      issues.includes('too-long');
    if (!isWeak) continue;

    let suggestion;
    if (weakKinds.length) suggestion = weakKinds[0].fix;
    else if (vague.length) suggestion = vague[0].fix;
    else if (issues.includes('no-verb')) {
      suggestion = 'Open with a strong action verb (e.g. "Led", "Built", "Reduced").';
      if (!metric) suggestion += ' Then add a number that shows the impact.';
    } else if (issues.includes('too-long')) suggestion = `Tighten to under ${BULLET_MAX_WORDS} words: cut filler and keep the result.`;
    else suggestion = 'Add what you did and the result (aim for 8-25 words).';

    flagged.push({
      index: b.index,
      number: b.number,
      section: b.section,
      text: b.text,
      issues,
      hasMetric: metric,
      suggestion,
    });
  }
  return flagged;
}

/* ------------------------------------------------------------------ */
/* Category scorers - each returns { ratio, summary, subs }            */
/* ------------------------------------------------------------------ */

function scoreKeywords(structure, jdModel) {
  const resumeStems = new Set(tokenize(structure.text).map((t) => stem(t)));
  const matched = [];
  const missing = [];
  let matchedWeight = 0;
  for (const k of jdModel.keywords) {
    if (resumeStems.has(k.stem)) {
      matched.push(k);
      matchedWeight += k.weight;
    } else missing.push(k);
  }
  missing.sort((a, b) => b.weight - a.weight || a.order - b.order);
  const ratio = jdModel.totalWeight > 0 ? matchedWeight / jdModel.totalWeight : 0;
  return {
    ratio,
    matched,
    missing,
    summary: `${matched.length} of ${jdModel.keywords.length} job-description keywords found`,
    subs: [{ label: 'Keywords matched', value: `${matched.length}/${jdModel.keywords.length}` }],
  };
}

function scoreMetrics(structure) {
  const total = structure.bullets.length;
  const withMetric = structure.bullets.filter((b) => hasMetric(b.text)).length;
  const share = total ? withMetric / total : 0;
  const ratio = Math.min(1, share / METRIC_TARGET_SHARE);
  return {
    ratio,
    withMetric,
    total,
    summary: total
      ? `${withMetric} of ${total} bullets contain a number (target: ${Math.round(METRIC_TARGET_SHARE * 100)}%+)`
      : 'No achievement bullets found to check',
    subs: [{ label: 'Bullets with numbers', value: `${withMetric}/${total}` }],
  };
}

function scoreVerbs(structure) {
  const total = structure.bullets.length;
  const withVerb = structure.bullets.filter((b) => startsWithActionVerb(b.text)).length;
  const share = total ? withVerb / total : 0;
  const ratio = Math.min(1, share / VERB_TARGET_SHARE);
  return {
    ratio,
    withVerb,
    total,
    summary: total
      ? `${withVerb} of ${total} bullets open with a strong action verb (target: ${Math.round(VERB_TARGET_SHARE * 100)}%+)`
      : 'No achievement bullets found to check',
    subs: [{ label: 'Bullets with strong verbs', value: `${withVerb}/${total}` }],
  };
}

function scoreSections(structure) {
  const checks = CORE_SECTIONS.map((s) => ({
    key: s.key,
    label: s.label,
    present: s.key === 'contact' ? structure.hasContact : Boolean(structure.present[s.key]),
  }));
  const presentCount = checks.filter((c) => c.present).length;
  return {
    ratio: presentCount / CORE_SECTIONS.length,
    checks,
    summary: `${presentCount} of ${CORE_SECTIONS.length} standard sections present`,
    subs: checks.map((c) => ({ label: c.label, value: c.present ? 'Yes' : 'Missing' })),
  };
}

function scoreReadability(structure) {
  const total = structure.bullets.length;
  const L = lengthRatio(structure.wordCount);
  let B = 0;
  let W = 0;
  let weakBullets = 0;
  if (total > 0) {
    const inRange = structure.bullets.filter((b) => {
      const w = countWords(b.text);
      return w >= BULLET_MIN_WORDS && w <= BULLET_MAX_WORDS;
    }).length;
    B = inRange / total;
    weakBullets = structure.bullets.filter((b) => findWeakPhrases(b.text).length > 0).length;
    W = 1 - Math.min(1, (2 * weakBullets) / total);
  }
  // Length counts 6 of 15, bullet length 4 of 15, weak phrases 5 of 15.
  const ratio = (6 * L + 4 * B + 5 * W) / 15;
  return {
    ratio,
    weakBullets,
    summary: `${structure.wordCount} words, ${weakBullets} bullet${weakBullets === 1 ? '' : 's'} with weak or vague phrases`,
    subs: [
      { label: 'Length', value: `${structure.wordCount} words (ideal 350-800)` },
      { label: 'Bullets of 6-30 words', value: total ? `${Math.round(B * total)}/${total}` : 'n/a' },
      { label: 'Bullets with weak phrases', value: `${weakBullets}` },
    ],
  };
}

/* ------------------------------------------------------------------ */
/* Public API                                                          */
/* ------------------------------------------------------------------ */

const toTenths = (ratio, max) =>
  Math.round(Math.max(0, Math.min(1, Number.isFinite(ratio) ? ratio : 0)) * max * 10);

/**
 * Score an already-parsed structure.
 * `jd` may be JD text, a model from buildJdModel(), or null/undefined.
 */
export function scoreStructure(structure, jd) {
  const jdModel = resolveJd(jd);
  const hasJD = Boolean(jdModel);
  const W = hasJD ? WEIGHTS_WITH_JD : WEIGHTS_NO_JD;

  const parts = {
    keywords: hasJD
      ? scoreKeywords(structure, jdModel)
      : { ratio: 0, matched: [], missing: [], summary: 'Add a job description to unlock keyword matching', subs: [] },
    metrics: scoreMetrics(structure),
    verbs: scoreVerbs(structure),
    sections: scoreSections(structure),
    readability: scoreReadability(structure),
  };

  const categories = {};
  let totalTenths = 0;
  const breakdown = CATEGORY_META.map(({ key, label }) => {
    const max = W[key];
    const tenths = max === 0 ? 0 : toTenths(parts[key].ratio, max);
    totalTenths += tenths;
    const cat = {
      key,
      label,
      max,
      score: tenths / 10,
      tenths,
      ratio: parts[key].ratio,
      skipped: max === 0,
      summary: parts[key].summary,
      subs: parts[key].subs,
    };
    categories[key] = cat;
    return cat;
  });

  return {
    total: totalTenths / 10,
    totalTenths,
    hasJD,
    breakdown,
    categories,
    matchedKeywords: parts.keywords.matched,
    missingKeywords: parts.keywords.missing,
    weakBullets: analyzeBullets(structure),
    stats: {
      wordCount: structure.wordCount,
      bullets: structure.bullets.length,
      bulletsWithMetric: parts.metrics.withMetric ?? 0,
      bulletsWithVerb: parts.verbs.withVerb ?? 0,
    },
  };
}

/** Score raw text (the main entry point for simple use + the tests). */
export function scoreResume(text, jd) {
  return scoreStructure(parseResume(text), jd);
}

/** Convenience: format points like 6, 6.5, -3.2 without trailing zeros. */
export function formatPoints(n) {
  if (!Number.isFinite(n)) return '0';
  const r = Math.round(n * 10) / 10;
  return Number.isInteger(r) ? String(r) : r.toFixed(1);
}

/** Signed delta label: "+6", "+6.5", "−3.2", "±0". Input in tenths (integer). */
export function formatDeltaTenths(tenths) {
  if (!Number.isFinite(tenths) || tenths === 0) return '±0';
  const abs = Math.abs(tenths) / 10;
  const body = Number.isInteger(abs) ? String(abs) : abs.toFixed(1);
  return `${tenths > 0 ? '+' : '−'}${body}`;
}
