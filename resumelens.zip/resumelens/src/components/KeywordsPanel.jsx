/**
 * KeywordsPanel.jsx - job-description keywords found / missing in version 2.
 */

import { Alert, SectionHeading } from './ui.jsx';

function KeywordChip({ kw, tone }) {
  const cls = tone === 'found' ? 'chip-up' : 'chip-down';
  return (
    <li className={`chip ${cls}`} title={kw.count > 1 ? `Appears ${kw.count} times in the job description` : 'Appears once in the job description'}>
      {kw.display}
      {kw.count > 1 ? <span className="opacity-70">×{kw.count}</span> : null}
    </li>
  );
}

export default function KeywordsPanel({ score }) {
  const { hasJD, matchedKeywords, missingKeywords } = score;
  return (
    <section className="glass p-4 sm:p-6" aria-labelledby="keywords-title">
      <SectionHeading id="keywords-title" eyebrow="Keywords" title="Job description keywords">
        The most important words in the job description, checked against version 2.
      </SectionHeading>

      {!hasJD ? (
        <Alert tone="info">Add a job description above to see which keywords your resume is missing.</Alert>
      ) : (
        <div className="space-y-4">
          <div>
            <h3 className="mb-2 text-sm font-semibold text-red-200">Missing ({missingKeywords.length})</h3>
            {missingKeywords.length ? (
              <ul className="flex flex-wrap gap-2">
                {missingKeywords.map((kw) => (
                  <KeywordChip key={kw.stem} kw={kw} tone="missing" />
                ))}
              </ul>
            ) : (
              <p className="text-sm text-emerald-300">Nothing missing - every keyword is covered.</p>
            )}
            {missingKeywords.length ? <p className="mt-2 text-xs text-slate-500">Only add a keyword if you genuinely have that skill or experience.</p> : null}
          </div>
          <div>
            <h3 className="mb-2 text-sm font-semibold text-emerald-200">Found ({matchedKeywords.length})</h3>
            {matchedKeywords.length ? (
              <ul className="flex flex-wrap gap-2">
                {matchedKeywords.map((kw) => (
                  <KeywordChip key={kw.stem} kw={kw} tone="found" />
                ))}
              </ul>
            ) : (
              <p className="text-sm text-slate-400">None of the keywords were found yet.</p>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
