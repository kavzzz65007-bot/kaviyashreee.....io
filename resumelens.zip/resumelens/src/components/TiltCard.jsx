/**
 * TiltCard.jsx - a glass card that tilts toward the pointer (CSS 3D).
 *
 * The pointer position is written straight to CSS variables on the element
 * (--rx, --ry, --mx, --my), so React does not re-render while the mouse moves.
 * Touch input and "prefers-reduced-motion" skip the tilt entirely.
 */

import { useEffect, useRef } from 'react';
import { useReducedMotion } from '../lib/hooks.js';

export default function TiltCard({ as: Tag = 'div', max = 7, className = '', children, ...rest }) {
  const ref = useRef(null);
  const frame = useRef(0);
  const reduced = useReducedMotion();

  useEffect(() => () => cancelAnimationFrame(frame.current), []);

  const setVars = (rx, ry, mx, my) => {
    const el = ref.current;
    if (!el) return;
    el.style.setProperty('--rx', `${rx}deg`);
    el.style.setProperty('--ry', `${ry}deg`);
    el.style.setProperty('--mx', `${mx}%`);
    el.style.setProperty('--my', `${my}%`);
  };

  const onMove = (e) => {
    if (reduced || e.pointerType === 'touch') return;
    const { clientX, clientY } = e;
    cancelAnimationFrame(frame.current);
    frame.current = requestAnimationFrame(() => {
      const el = ref.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      if (!r.width || !r.height) return;
      const px = Math.min(1, Math.max(0, (clientX - r.left) / r.width));
      const py = Math.min(1, Math.max(0, (clientY - r.top) / r.height));
      setVars(((0.5 - py) * 2 * max).toFixed(2), ((px - 0.5) * 2 * max).toFixed(2), (px * 100).toFixed(1), (py * 100).toFixed(1));
    });
  };

  const onLeave = () => {
    cancelAnimationFrame(frame.current);
    setVars(0, 0, 50, 50);
  };

  return (
    <Tag ref={ref} className={`glass tilt ${className}`} onPointerMove={onMove} onPointerLeave={onLeave} {...rest}>
      {children}
    </Tag>
  );
}
