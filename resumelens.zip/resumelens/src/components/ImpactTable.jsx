/**
 * ImpactTable.jsx - every edit with its score change, the regression alerts
 * (with Undo), and the "Interaction effect" row that makes the numbers add up.
 */

import { formatDeltaTenths, formatPoints } from '../engine/scoring.js';
import { DeltaChip } from './ui.jsx';

const KIND_LABEL = { changed: 'Changed', added: 'Added', removed: 'Removed', moved: 'Moved' };

function EditRow({ chunk, canUndo, undoHint, busy, onUndo }) {
  const regression = chunk.regression;
  return (
    <li className={`rounded-xl border p-3 ${regression ? 'border-red-400/45 bg-red-500/[0.07]' : 'border-white/10 bg-white/[0.03]'}`}>
      <div className="flex flex-wrap items-start gap-x-3 gap-y-2">
        <span className="chip chip-flat shrink-0">{KIND_LABEL[chunk.kind] || chunk.kind}</span>
        <p className="min-w-0 flex-1 basis-56 text-sm font-medium text-slate-100">{chunk.label}</p>
        <DeltaChip tenths={chunk.deltaTenths} className="shrink-0" />
      </div>

      {chunk.detail ? <p className="mt-1.5 text-xs text-slate-400">{chunk.detail}</p> : null}
      {chunk.note ? <p className="mt-1.5 text-xs text-slate-400">{chunk.note}</p> : null}

      {regression ? (
        <div className="mt-2.5 flex flex-wrap items-center gap-2 rounded-lg bg-red-500/10 px-3 py-2">
          <p className="min-w-0 flex-1 basis-48 text-xs font-semibold text-red-200">
            <span aria-hidden="true">⚠ </span>Regression: this edit lowered your score by {formatPoints(Math.abs(chunk.deltaTenths) / 10)}.
          </p>
          <button type="button" className="btn btn-danger btn-sm" disabled={!canUndo || busy} onClick={() => onUndo(chunk.id)} title={canUndo ? 'Revert only this edit in v2' : undoHint}>
            Undo this edit
          </button>
        </div>
      ) : null}

      {chunk.oldText || chunk.newText ? (
        <details className="mt-2 text-xs">
          <summary className="cursor-pointer text-slate-400 hover:text-slate-200">Show before / after text</summary>
          <div className="mt-2 grid gap-2 sm:grid-cols-2">
            <div className="rounded-lg bg-black/30 p-2">
              <p className="mb-1 font-semibold text-slate-400">v1 (before)</p>
              <p className="font-mono break-words whitespace-pre-wrap text-slate-300">{chunk.oldText || '—'}</p>
            </div>
            <div className="rounded-lg bg-black/30 p-2">
              <p className="mb-1 font-semibold text-slate-400">v2 (after)</p>
              <p className="font-mono break-words whitespace-pre-wrap text-slate-300">{chunk.newText || '—'}</p>
            </div>
          </div>
        </details>
      ) : null}
    </li>
  );
}

export default function ImpactTable({ result, stale, busy, onUndo }) {
  const { chunks, sumTenths, interactionTenths, totalTenths, before, after } = result;
  const canUndo = !stale;
  const undoHint = 'Run the analysis again first - your text changed after this result.';

  return (
    <div>
      <ul className="space-y-2">
        {chunks.map((chunk) => (
          <EditRow key={chunk.id} chunk={chunk} canUndo={canUndo} undoHint={undoHint} busy={busy} onUndo={onUndo} />
        ))}

        <li className="rounded-xl border border-violet-400/30 bg-violet-500/[0.06] p-3">
          <div className="flex flex-wrap items-start gap-x-3 gap-y-2">
            <span className="chip chip-info shrink-0">Interaction</span>
            <p className="min-w-0 flex-1 basis-56 text-sm font-medium text-slate-100">Interaction effect (approximate attribution)</p>
            <DeltaChip tenths={interactionTenths} neutral className="shrink-0" />
          </div>
          <p className="mt-1.5 text-xs leading-relaxed text-slate-400">
            Each edit above is scored on its own, as if it were the only change. Edits that overlap (two edits that both add the same keyword, say) each get full credit alone but count only once together. This row is the difference, so the rows always add up exactly.
          </p>
        </li>
      </ul>

      <p className="mt-3 rounded-xl bg-black/25 px-3 py-2.5 text-sm text-slate-300" aria-label="How the numbers add up">
        <span className="tabular-nums">
          Edits {formatDeltaTenths(sumTenths)} + interaction {formatDeltaTenths(interactionTenths)} = <strong className="text-white">{formatDeltaTenths(totalTenths)}</strong>
        </span>
        <span className="text-slate-500">
          {' '}
          (v1 {formatPoints(before.total)} → v2 {formatPoints(after.total)})
        </span>
      </p>
    </div>
  );
}
