/**
 * VersionsPanel.jsx - saved resume versions + the score timeline.
 * Every version is re-scored against the CURRENT job description, so the line
 * always compares like with like.
 */

import { Alert, ConfirmButton, DeltaChip, SectionHeading } from './ui.jsx';
import TimelineChart from './TimelineChart.jsx';

const dateFmt = (ms) => {
  try {
    return new Date(ms).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  } catch {
    return '';
  }
};

export default function VersionsPanel({ points, hasJD, storageOk, disabled, onUseV1, onUseV2, onDelete }) {
  return (
    <section className="glass p-4 sm:p-6" aria-labelledby="timeline-title">
      <SectionHeading id="timeline-title" eyebrow="Score timeline" title="Your versions over time">
        {hasJD ? 'Every saved version is scored against the job description above.' : 'No job description yet, so the keyword points are shared across the other categories.'}
      </SectionHeading>

      {!storageOk ? (
        <Alert tone="warn" className="mb-3">
          Your browser blocked local storage, so versions are kept only until you close or reload this tab.
        </Alert>
      ) : null}

      <TimelineChart points={points} />

      {points.length > 0 ? (
        <ul className="mt-4 divide-y divide-white/5 rounded-xl border border-white/10">
          {points.map((p, i) => {
            const prev = i > 0 ? points[i - 1] : null;
            return (
              <li key={p.id} className="flex flex-wrap items-center gap-x-3 gap-y-1.5 px-3 py-2.5 text-sm">
                <span className="w-9 font-bold text-slate-100">{p.label}</span>
                <span className="tabular-nums text-slate-300">{p.score.toFixed(1)} / 100</span>
                {prev ? <DeltaChip tenths={p.tenths - prev.tenths} /> : null}
                <span className="text-xs text-slate-500">
                  {p.words} words · {dateFmt(p.savedAt)}
                </span>
                <span className="ml-auto flex flex-wrap gap-1.5">
                  <button type="button" className="btn btn-secondary btn-sm" disabled={disabled} onClick={() => onUseV1(p.id)}>
                    Use as v1
                  </button>
                  <button type="button" className="btn btn-secondary btn-sm" disabled={disabled} onClick={() => onUseV2(p.id)}>
                    Use as v2
                  </button>
                  <ConfirmButton className="btn btn-ghost btn-sm" confirmLabel="Click to delete" onConfirm={() => onDelete(p.id)} disabled={disabled}>
                    Delete
                  </ConfirmButton>
                </span>
              </li>
            );
          })}
        </ul>
      ) : null}
    </section>
  );
}
