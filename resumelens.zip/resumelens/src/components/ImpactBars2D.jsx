/**
 * ImpactBars2D.jsx - flat version of the impact bars (the fallback when WebGL
 * is unavailable). Bars grow right (green, raised the score) or left (red,
 * lowered it) from a centre line.
 */

import { formatDeltaTenths } from '../engine/scoring.js';

const TONE = {
  up: 'bg-emerald-400',
  down: 'bg-red-400',
  neutral: 'bg-violet-400',
  flat: 'bg-slate-400',
};
const TEXT = { up: 'text-emerald-300', down: 'text-red-300', neutral: 'text-violet-300', flat: 'text-slate-300' };

export default function ImpactBars2D({ items }) {
  const maxAbs = items.reduce((m, it) => Math.max(m, Math.abs(it.deltaTenths)), 0);

  return (
    <ul className="space-y-2" aria-label="Score change per edit">
      {items.map((it) => {
        const tone = it.kind === 'interaction' ? 'neutral' : it.deltaTenths > 0 ? 'up' : it.deltaTenths < 0 ? 'down' : 'flat';
        const pct = maxAbs > 0 ? (Math.abs(it.deltaTenths) / maxAbs) * 50 : 0;
        return (
          <li key={it.id} className="grid grid-cols-[minmax(0,9rem)_1fr_3.5rem] items-center gap-2 text-xs sm:grid-cols-[minmax(0,13rem)_1fr_3.5rem]">
            <span className="truncate text-slate-300" title={it.tag}>
              {it.tag}
            </span>
            <span className="relative h-4 rounded bg-white/5">
              <span className="absolute inset-y-0 left-1/2 w-px bg-white/25" />
              <span
                className={`bar-fill absolute inset-y-0 rounded ${TONE[tone]}`}
                style={{ width: `${Math.max(pct, it.deltaTenths === 0 ? 0.8 : 1.5)}%`, [it.deltaTenths < 0 ? 'right' : 'left']: '50%' }}
              />
            </span>
            <span className={`text-right font-bold tabular-nums ${TEXT[tone]}`}>{formatDeltaTenths(it.deltaTenths)}</span>
          </li>
        );
      })}
    </ul>
  );
}
