/**
 * ImpactChart.jsx - the Edit Impact bar chart: 3D columns when WebGL works,
 * flat bars otherwise. `items` is the list of edits (+ the interaction row).
 */

import { layoutBars } from '../three/math.js';
import { detectWebGL, useReducedMotion } from '../lib/hooks.js';
import { ImpactBarsScene } from '../three/lazy.js';
import SafeScene from './SafeScene.jsx';
import ImpactBars2D from './ImpactBars2D.jsx';

function Legend() {
  return (
    <ul className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-400" aria-label="Legend">
      <li className="flex items-center gap-1.5">
        <span className="h-2.5 w-2.5 rounded-sm bg-emerald-400" /> raised the score
      </li>
      <li className="flex items-center gap-1.5">
        <span className="h-2.5 w-2.5 rounded-sm bg-red-400" /> lowered it
      </li>
      <li className="flex items-center gap-1.5">
        <span className="h-2.5 w-2.5 rounded-sm bg-violet-400" /> interaction effect
      </li>
    </ul>
  );
}

export default function ImpactChart({ items }) {
  const reduced = useReducedMotion();
  const hasGl = detectWebGL();
  const hidden = layoutBars(items).hidden;
  const summary = items.map((it) => `${it.tag}: ${it.deltaTenths / 10}`).join('; ');

  return (
    <div>
      <div role="img" aria-label={`Bar chart of the score change caused by each edit. ${summary}`} className={`w-full overflow-hidden rounded-xl border border-white/10 bg-black/20 ${hasGl ? 'h-[19rem] sm:h-[22rem]' : ''}`}>
        <SafeScene
          fallback={
            <div className="max-h-[22rem] overflow-y-auto p-3 sm:p-4">
              <ImpactBars2D items={items} />
            </div>
          }
          loading={<div className="grid h-full place-items-center text-sm text-slate-500">Loading 3D chart…</div>}
        >
          <ImpactBarsScene items={items} reduced={reduced} />
        </SafeScene>
      </div>
      <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
        <Legend />
        {hidden > 0 ? <p className="text-xs text-slate-500">Showing the biggest movers; the full list of {items.length} is below.</p> : null}
      </div>
    </div>
  );
}
