/**
 * HeroScore.jsx - the landing-page score ring.
 * 3D animated ring (fills up to the score) when WebGL works, SVG ring otherwise.
 */

import SafeScene from './SafeScene.jsx';
import ScoreMeter2D from './ScoreMeter2D.jsx';
import { HeroRingScene } from '../three/lazy.js';
import { useCountUp, useReducedMotion } from '../lib/hooks.js';
import { ringColor } from '../three/math.js';

function Overlay({ score, reduced, caption }) {
  const shown = useCountUp(score, { reduced });
  return (
    <div className="pointer-events-none absolute inset-0 grid place-content-center text-center">
      <div className="text-5xl font-extrabold tracking-tight tabular-nums sm:text-6xl" style={{ color: ringColor(score) }}>
        {shown.toFixed(1)}
      </div>
      <div className="mt-1 text-xs text-slate-400">out of 100</div>
      {caption ? <div className="mt-1 max-w-[9rem] text-[0.7rem] leading-tight text-slate-500">{caption}</div> : null}
    </div>
  );
}

export default function HeroScore({ score, caption }) {
  const reduced = useReducedMotion();
  const flat = (
    <div className="grid h-full place-items-center">
      <ScoreMeter2D score={score} size={260} stroke={18} label="Sample ATS score" sublabel={caption || 'out of 100'} />
    </div>
  );

  return (
    <div className="glass relative aspect-square w-full" role="img" aria-label={`Sample ATS score ${score.toFixed(1)} out of 100`}>
      <SafeScene fallback={flat} loading={<div className="grid h-full place-items-center text-sm text-slate-500">Loading…</div>}>
        <div className="relative h-full w-full">
          <HeroRingScene score={score} reduced={reduced} />
          <Overlay score={score} reduced={reduced} caption={caption} />
        </div>
      </SafeScene>
    </div>
  );
}
