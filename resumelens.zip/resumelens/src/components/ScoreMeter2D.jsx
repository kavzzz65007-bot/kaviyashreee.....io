/**
 * ScoreMeter2D.jsx - the flat SVG score ring.
 *
 * Used (a) next to before/after results and (b) as the fallback when WebGL is
 * unavailable or the 3D ring fails to load.
 */

import { useEffect, useState } from 'react';
import { useCountUp, useReducedMotion } from '../lib/hooks.js';
import { clamp, ringColor } from '../three/math.js';

export default function ScoreMeter2D({ score, size = 180, stroke = 12, label = 'Score', sublabel = 'out of 100', showNumber = true, className = '' }) {
  const reduced = useReducedMotion();
  const safe = clamp(Number.isFinite(score) ? score : 0, 0, 100);
  const [shown, setShown] = useState(reduced ? safe : 0);
  const counted = useCountUp(safe, { reduced });

  useEffect(() => {
    if (reduced) {
      setShown(safe);
      return undefined;
    }
    const id = requestAnimationFrame(() => setShown(safe));
    return () => cancelAnimationFrame(id);
  }, [safe, reduced]);

  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const color = ringColor(safe);
  const half = size / 2;

  return (
    <div
      role="img"
      aria-label={`${label}: ${safe.toFixed(1)} out of 100`}
      className={`relative inline-grid place-items-center ${className}`}
      style={{ width: size, height: size }}
    >
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90" aria-hidden="true">
        <circle cx={half} cy={half} r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={stroke} />
        <circle
          className="score-ring-stroke"
          cx={half}
          cy={half}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - shown / 100)}
        />
      </svg>
      {showNumber ? (
        <div className="absolute inset-0 grid place-content-center text-center">
          <div className="font-extrabold tracking-tight tabular-nums" style={{ color, fontSize: size * 0.24 }}>
            {counted.toFixed(1)}
          </div>
          <div className="text-xs text-slate-400">{sublabel}</div>
        </div>
      ) : null}
    </div>
  );
}
