/**
 * Backdrop.jsx - the floating-particles layer behind every page.
 * 3D when WebGL works; a few static CSS dots otherwise. Never takes clicks.
 */

import SafeScene from './SafeScene.jsx';
import { BackdropScene } from '../three/lazy.js';
import { useIsNarrow, useReducedMotion } from '../lib/hooks.js';

export default function Backdrop() {
  const reduced = useReducedMotion();
  const narrow = useIsNarrow();
  return (
    <div className="backdrop fixed inset-0 z-0" aria-hidden="true">
      <SafeScene fallback={<div className="backdrop-fallback absolute inset-0 opacity-70" />} loading={null}>
        <BackdropScene count={narrow ? 70 : 150} reduced={reduced} />
      </SafeScene>
    </div>
  );
}
