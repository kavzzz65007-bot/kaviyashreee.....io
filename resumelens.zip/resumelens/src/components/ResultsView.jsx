/**
 * ResultsView.jsx - everything shown after "Analyze edits".
 * Pure display: it receives the result object from analyzeEditImpact().
 */

import { useMemo } from 'react';
import { formatDeltaTenths, formatPoints } from '../engine/scoring.js';
import BreakdownPanel from './BreakdownPanel.jsx';
import ImpactChart from './ImpactChart.jsx';
import ImpactTable from './ImpactTable.jsx';
import KeywordsPanel from './KeywordsPanel.jsx';
import NextBestEdits from './NextBestEdits.jsx';
import ScoreMeter2D from './ScoreMeter2D.jsx';
import WeakBullets from './WeakBullets.jsx';
import WordHighlight from './WordHighlight.jsx';
import { Alert, DeltaChip, SectionHeading } from './ui.jsx';

export default function ResultsView({ result, stale, busy, onUndo }) {
  const { before, after, chunks, identical, totalTenths, interactionTenths } = result;

  const barItems = useMemo(() => {
    const items = chunks.map((c) => ({ id: c.id, tag: c.tag, deltaTenths: c.deltaTenths, kind: 'chunk' }));
    if (items.length > 0) items.push({ id: 'interaction', tag: 'Interaction', deltaTenths: interactionTenths, kind: 'interaction' });
    return items;
  }, [chunks, interactionTenths]);

  const regressions = chunks.filter((c) => c.regression).length;

  return (
    <div className="space-y-6">
      {stale ? (
        <Alert tone="warn">You changed the text after this analysis, so these results are out of date. Press &ldquo;Analyze edits&rdquo; to refresh them.</Alert>
      ) : null}
      {result.validation.warnings.map((w) => (
        <Alert key={w} tone="warn">
          {w}
        </Alert>
      ))}
      {result.validation.notes.map((n) => (
        <Alert key={n} tone="info">
          {n}
        </Alert>
      ))}

      {/* ------------------------------ summary ------------------------------ */}
      <section className="glass p-4 sm:p-6" aria-labelledby="summary-title">
        <SectionHeading id="summary-title" eyebrow="Result" title="Overall ATS score">
          {after.hasJD ? 'Scored against your job description.' : 'Scored without a job description.'}
        </SectionHeading>

        <div className="grid items-center justify-items-center gap-4 sm:grid-cols-[1fr_auto_1fr]">
          <div className="text-center">
            <ScoreMeter2D score={before.total} size={150} stroke={11} label="Version 1 score" sublabel="v1" />
          </div>
          <div className="flex flex-col items-center gap-1 text-center">
            <DeltaChip tenths={totalTenths} className="!px-3 !py-1 !text-base" />
            <p className="text-xs text-slate-400">{identical ? 'no change' : 'points'}</p>
          </div>
          <div className="text-center">
            <ScoreMeter2D score={after.total} size={170} stroke={12} label="Version 2 score" sublabel="v2" />
          </div>
        </div>

        {identical ? (
          <Alert tone="info" className="mt-4">
            Version 1 and version 2 are identical, so there are no edits to measure. Change something in version 2 and analyze again. The suggestions below still apply.
          </Alert>
        ) : (
          <p className="mt-4 text-center text-sm text-slate-300">
            Your edits moved the score from <strong className="text-white tabular-nums">{formatPoints(before.total)}</strong> to <strong className="text-white tabular-nums">{formatPoints(after.total)}</strong> ({formatDeltaTenths(totalTenths)}).
          </p>
        )}

        {regressions > 0 ? (
          <Alert tone="error" className="mt-4">
            <strong>
              {regressions} edit{regressions === 1 ? '' : 's'} lowered your score.
            </strong>{' '}
            Look for the red &ldquo;Regression&rdquo; rows below. Each has an Undo button that reverts only that edit.
          </Alert>
        ) : null}
      </section>

      {/* ------------------------------ impact ------------------------------- */}
      {!identical && chunks.length > 0 ? (
        <section className="glass p-4 sm:p-6" aria-labelledby="impact-title">
          <SectionHeading id="impact-title" eyebrow="Edit Impact Tracker" title="What each edit was worth">
            Every edit was applied on its own to version 1 and re-scored. This is an approximate attribution: edits that overlap share credit, shown as the interaction effect.
          </SectionHeading>
          <ImpactChart items={barItems} />
          <div className="mt-5">
            <ImpactTable result={result} stale={stale} busy={busy} onUndo={onUndo} />
          </div>
        </section>
      ) : null}

      <NextBestEdits edits={result.nextBest} />

      {!identical && result.wordLines.length > 0 ? <WordHighlight lines={result.wordLines} truncated={result.wordTruncated} /> : null}

      <BreakdownPanel before={before} after={after} />

      <div className="grid gap-6 lg:grid-cols-2">
        <KeywordsPanel score={after} />
        <WeakBullets score={after} />
      </div>
    </div>
  );
}
