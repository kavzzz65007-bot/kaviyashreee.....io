/**
 * SafeScene.jsx - the safety net around every 3D scene.
 *
 *   - no WebGL in this browser          -> shows `fallback` (a 2D version)
 *   - the 3D code is still downloading  -> shows `loading` (defaults to `fallback`)
 *   - the 3D code throws / chunk fails  -> ErrorBoundary shows `fallback`
 *
 * So a 3D problem can never break the page: the user always gets the 2D view.
 */

import { Suspense, useState } from 'react';
import ErrorBoundary from './ErrorBoundary.jsx';
import { detectWebGL } from '../lib/hooks.js';

export default function SafeScene({ children, fallback = null, loading, resetKey }) {
  const [webgl] = useState(detectWebGL);
  if (!webgl) return fallback;
  return (
    <ErrorBoundary fallback={fallback} resetKey={resetKey}>
      <Suspense fallback={loading === undefined ? fallback : loading}>{children}</Suspense>
    </ErrorBoundary>
  );
}
