/**
 * Header.jsx - brand, navigation and the signed-in profile chip.
 */

import { useAuth } from '../lib/AuthContext.jsx';
import { navigate } from '../lib/hooks.js';

function Logo() {
  return (
    <svg width="28" height="28" viewBox="0 0 64 64" aria-hidden="true">
      <defs>
        <linearGradient id="logo-g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#38bdf8" />
          <stop offset="1" stopColor="#34d399" />
        </linearGradient>
      </defs>
      <circle cx="30" cy="30" r="15" fill="none" stroke="url(#logo-g)" strokeWidth="7" />
      <path d="M42 42 L55 55" stroke="url(#logo-g)" strokeWidth="7" strokeLinecap="round" />
    </svg>
  );
}

const linkClass = (active) =>
  `rounded-lg px-2 py-1.5 text-sm font-semibold whitespace-nowrap sm:px-3 transition-colors ${active ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'}`;

export default function Header({ route }) {
  const { session, logout } = useAuth();

  return (
    <header className="sticky top-0 z-30 border-b border-white/5 bg-ink-950/70 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-2 px-3 py-2.5 sm:gap-3 sm:px-6">
        <a href="#/" className="flex items-center gap-1.5 text-base font-extrabold tracking-tight text-white sm:gap-2 sm:text-lg">
          <Logo />
          <span>
            Resume<span className="text-sky-300">Lens</span>
          </span>
        </a>

        <nav className="flex items-center gap-1 sm:gap-2" aria-label="Main">
          <a href="#/" className={`hidden sm:inline-block ${linkClass(route === 'home')}`} aria-current={route === 'home' ? 'page' : undefined}>
            Home
          </a>
          <a href="#/app" className={linkClass(route === 'app')} aria-current={route === 'app' ? 'page' : undefined}>
            Tracker
          </a>
          {session ? (
            <>
              <span className="chip chip-info ml-1 hidden max-w-[10rem] truncate sm:inline-flex" title={session.guest ? 'Guest profile (saved on this device)' : `Signed in as ${session.username}`}>
                {session.guest ? 'Guest' : session.username}
              </span>
              <button
                type="button"
                className="btn btn-ghost btn-sm whitespace-nowrap"
                onClick={() => {
                  logout();
                  navigate('home');
                }}
              >
                Sign out
              </button>
            </>
          ) : (
            <a href="#/login" className={`btn btn-primary btn-sm whitespace-nowrap ${route === 'login' ? 'pointer-events-none opacity-60' : ''}`} aria-current={route === 'login' ? 'page' : undefined}>
              Sign in
            </a>
          )}
        </nav>
      </div>
    </header>
  );
}
