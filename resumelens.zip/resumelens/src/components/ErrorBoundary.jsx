/**
 * ErrorBoundary.jsx
 * ---------------------------------------------------------------------------
 * Catches any error thrown while rendering its children so one broken part of
 * the page can never blank the whole app.
 *
 *   <ErrorBoundary>                       -> friendly "Something went wrong" card
 *   <ErrorBoundary fallback={<Simple />}> -> your own fallback (null is allowed)
 *   <ErrorBoundary fallback={(error, reset) => ...}>
 *
 * `resetKey`: when this value changes (for example the current page) the
 * boundary clears its error and tries to render the children again.
 */

import { Component } from 'react';

function DefaultFallback({ error, reset }) {
  return (
    <div className="glass mx-auto my-10 max-w-lg p-6 text-center" role="alert">
      <h2 className="text-xl font-bold text-slate-100">Something went wrong</h2>
      <p className="mt-2 text-sm text-slate-400">
        This part of ResumeLens hit an unexpected problem. Your saved resumes are safe in your browser.
      </p>
      {error && error.message ? (
        <p className="mt-3 rounded-lg bg-black/30 p-2 font-mono text-xs text-slate-500 break-words">{String(error.message).slice(0, 200)}</p>
      ) : null}
      <div className="mt-5 flex flex-wrap justify-center gap-2">
        <button type="button" className="btn btn-primary" onClick={reset}>
          Try again
        </button>
        <a className="btn btn-secondary" href="#/">
          Back to home
        </a>
        <button type="button" className="btn btn-ghost" onClick={() => window.location.reload()}>
          Reload page
        </button>
      </div>
    </div>
  );
}

export default class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
    this.reset = () => this.setState({ error: null });
  }

  static getDerivedStateFromError(error) {
    return { error: error || new Error('Unknown error') };
  }

  componentDidUpdate(prevProps) {
    if (this.state.error && prevProps.resetKey !== this.props.resetKey) this.reset();
  }

  render() {
    const { error } = this.state;
    if (!error) return this.props.children;
    const { fallback } = this.props;
    if (typeof fallback === 'function') return fallback(error, this.reset);
    if (fallback !== undefined) return fallback;
    return <DefaultFallback error={error} reset={this.reset} />;
  }
}
