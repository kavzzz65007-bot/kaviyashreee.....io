/**
 * BreakdownPanel.jsx - the five scoring categories, before vs after.
 */

import { formatDeltaTenths, formatPoints } from '../engine/scoring.js';
import { DeltaChip, SectionHeading } from './ui.jsx';

export default function BreakdownPanel({ before, after }) {
  return (
    <section className="glass p-4 sm:p-6" aria-labelledby="breakdown-title">
      <SectionHeading id="breakdown-title" eyebrow="Score breakdown" title="Where your points come from">
        Version 2, compared with version 1. {after.hasJD ? 'Keyword matching uses your job description (35 points).' : 'With no job description the 35 keyword points are shared among the other four categories.'}
      </SectionHeading>

      <ul className="space-y-4">
        {after.breakdown.map((cat, i) => {
          const prev = before.breakdown[i];
          if (cat.skipped) {
            return (
              <li key={cat.key} className="rounded-xl border border-dashed border-white/15 p-3">
                <p className="text-sm font-semibold text-slate-300">{cat.label}</p>
                <p className="text-xs text-slate-500">{cat.summary}</p>
              </li>
            );
          }
          const pct = cat.max ? (cat.score / cat.max) * 100 : 0;
          const prevPct = cat.max ? (prev.score / cat.max) * 100 : 0;
          return (
            <li key={cat.key}>
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <p className="text-sm font-semibold text-slate-100">{cat.label}</p>
                <p className="flex items-center gap-2 text-sm tabular-nums text-slate-300">
                  <span className="text-slate-500">{formatPoints(prev.score)} →</span>
                  <strong className="text-white">{formatPoints(cat.score)}</strong>
                  <span className="text-slate-500">/ {cat.max}</span>
                  <DeltaChip tenths={cat.tenths - prev.tenths} />
                </p>
              </div>
              <div
                className="relative mt-1.5 h-2.5 overflow-hidden rounded-full bg-white/10"
                role="progressbar"
                aria-valuemin={0}
                aria-valuemax={cat.max}
                aria-valuenow={cat.score}
                aria-label={`${cat.label}: ${formatPoints(cat.score)} of ${cat.max}`}
              >
                <div className="bar-fill absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-sky-400 to-emerald-400" style={{ width: `${pct}%` }} />
                <div className="absolute inset-y-0 w-0.5 bg-white/70" style={{ left: `calc(${prevPct}% - 1px)` }} title={`v1: ${formatPoints(prev.score)}`} />
              </div>
              <p className="mt-1 text-xs text-slate-400">{cat.summary}</p>
              {cat.subs && cat.subs.length ? (
                <p className="text-xs text-slate-500">
                  {cat.subs.map((s) => `${s.label}: ${s.value}`).join(' · ')}
                </p>
              ) : null}
            </li>
          );
        })}
      </ul>

      <p className="mt-4 flex flex-wrap items-center gap-2 border-t border-white/10 pt-3 text-sm text-slate-300">
        <span>Total</span>
        <strong className="text-white tabular-nums">
          {formatPoints(before.total)} → {formatPoints(after.total)}
        </strong>
        <DeltaChip tenths={after.totalTenths - before.totalTenths} />
        <span className="text-xs text-slate-500">{formatDeltaTenths(after.totalTenths - before.totalTenths)} points</span>
      </p>
      <p className="mt-1 text-xs text-slate-500">The white tick on each bar marks where version 1 was.</p>
    </section>
  );
}
