/**
 * ui.jsx - tiny shared building blocks (spinner, chips, alerts, confirm button).
 */

import { useEffect, useRef, useState } from 'react';
import { formatDeltaTenths } from '../engine/scoring.js';

export function Spinner({ className = '' }) {
  return <span className={`spinner ${className}`} aria-hidden="true" />;
}

/** A coloured "+6" / "−3.2" / "±0" pill. `tenths` is an integer number of tenths of a point. */
export function DeltaChip({ tenths, className = '', neutral = false }) {
  let tone = 'chip-flat';
  if (neutral) tone = 'chip-info';
  else if (tenths > 0) tone = 'chip-up';
  else if (tenths < 0) tone = 'chip-down';
  return (
    <span className={`chip ${tone} ${className}`}>
      {!neutral && tenths > 0 ? <span aria-hidden="true">▲</span> : null}
      {!neutral && tenths < 0 ? <span aria-hidden="true">▼</span> : null}
      {formatDeltaTenths(tenths)}
    </span>
  );
}

const ALERT_TONES = {
  error: 'border-red-400/40 bg-red-500/10 text-red-200',
  warn: 'border-amber-400/40 bg-amber-500/10 text-amber-200',
  info: 'border-sky-400/35 bg-sky-500/10 text-sky-200',
  success: 'border-emerald-400/40 bg-emerald-500/10 text-emerald-200',
};

/** Inline message box. errors use role="alert", everything else role="status". */
export function Alert({ tone = 'info', children, id, className = '' }) {
  return (
    <div
      id={id}
      role={tone === 'error' ? 'alert' : 'status'}
      className={`rounded-xl border px-3.5 py-2.5 text-sm leading-relaxed ${ALERT_TONES[tone] || ALERT_TONES.info} ${className}`}
    >
      {children}
    </div>
  );
}

export function SectionHeading({ eyebrow, title, children, id, as: Tag = 'h2' }) {
  return (
    <div className="mb-4">
      {eyebrow ? <p className="text-xs font-semibold tracking-widest text-sky-300/80 uppercase">{eyebrow}</p> : null}
      <Tag id={id} className="text-xl font-bold tracking-tight text-slate-50 sm:text-2xl">{title}</Tag>
      {children ? <p className="mt-1 text-sm text-slate-400">{children}</p> : null}
    </div>
  );
}

/**
 * A button that asks for a second click before doing something destructive
 * (replacing the user's text). No browser pop-up dialogs are used.
 */
export function ConfirmButton({ onConfirm, children, confirmLabel = 'Click again to confirm', needsConfirm = true, className = '', disabled = false }) {
  const [armed, setArmed] = useState(false);
  const timer = useRef(0);

  useEffect(() => () => clearTimeout(timer.current), []);

  const click = () => {
    if (!needsConfirm || armed) {
      clearTimeout(timer.current);
      setArmed(false);
      onConfirm();
      return;
    }
    setArmed(true);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setArmed(false), 4000);
  };

  return (
    <button
      type="button"
      className={`${className} ${armed ? 'ring-2 ring-amber-300/70' : ''}`}
      onClick={click}
      onBlur={() => setArmed(false)}
      disabled={disabled}
    >
      {armed ? confirmLabel : children}
    </button>
  );
}
