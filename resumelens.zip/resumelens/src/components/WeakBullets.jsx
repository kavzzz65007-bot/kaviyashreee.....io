/**
 * WeakBullets.jsx - weak / vague bullets in version 2, each with a short fix.
 */

import { useState } from 'react';
import { SectionHeading } from './ui.jsx';

const ISSUE_LABEL = {
  'weak-phrase': 'Weak phrase',
  vague: 'Vague',
  'no-metric': 'No numbers',
  'no-verb': 'No strong verb',
  'too-short': 'Too short',
  'too-long': 'Too long',
};
const SHOW_FIRST = 6;

export default function WeakBullets({ score }) {
  const [all, setAll] = useState(false);
  const list = score.weakBullets || [];
  const shown = all ? list : list.slice(0, SHOW_FIRST);

  return (
    <section className="glass p-4 sm:p-6" aria-labelledby="weak-title">
      <SectionHeading id="weak-title" eyebrow="Bullet check" title="Weak or vague bullets">
        Bullets in version 2 that could be stronger, with a quick suggestion for each.
      </SectionHeading>

      {list.length === 0 ? (
        <p className="text-sm text-emerald-300">No weak or vague bullets found. Nice work.</p>
      ) : (
        <>
          <ul className="space-y-3">
            {shown.map((b) => (
              <li key={`${b.index}-${b.number}`} className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-xs font-semibold text-slate-400">Bullet {b.number}</span>
                  {(b.issues || []).map((issue) => (
                    <span key={issue} className="chip chip-down">
                      {ISSUE_LABEL[issue] || issue}
                    </span>
                  ))}
                </div>
                <p className="mt-1.5 text-sm text-slate-200">{b.text}</p>
                <p className="mt-1.5 text-xs text-sky-200/90">
                  <span aria-hidden="true">💡 </span>
                  {b.suggestion}
                </p>
              </li>
            ))}
          </ul>
          {list.length > SHOW_FIRST ? (
            <button type="button" className="btn btn-ghost btn-sm mt-3" onClick={() => setAll((v) => !v)}>
              {all ? 'Show fewer' : `Show all ${list.length}`}
            </button>
          ) : null}
        </>
      )}
    </section>
  );
}
