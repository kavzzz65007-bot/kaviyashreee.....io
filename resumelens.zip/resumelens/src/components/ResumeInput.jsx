/**
 * ResumeInput.jsx - a labelled text area with word/character counters,
 * "Upload file" (PDF / DOCX / TXT, drag-and-drop too), Clear, and an optional
 * "Save as version" button.
 *
 * File problems (wrong type, > 5 MB, scanned PDF ...) appear as friendly
 * inline messages under the box; nothing ever throws into the page.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { MAX_CHARS, MAX_FILE_BYTES } from '../engine/constants.js';
import { countWords } from '../engine/text.js';
import { FileError, readResumeFile } from '../lib/fileParsing.js';
import { Alert, Spinner } from './ui.jsx';

const fmt = (n) => Number(n).toLocaleString('en-US');

export default function ResumeInput({
  id,
  label,
  hint,
  value,
  onChange,
  placeholder,
  error = '',
  disabled = false,
  maxChars = MAX_CHARS,
  rows = 12,
  onSave,
  saveLabel = 'Save as version',
}) {
  const [fileBusy, setFileBusy] = useState(false);
  const [fileError, setFileError] = useState('');
  const [fileNote, setFileNote] = useState('');
  const [dragging, setDragging] = useState(false);
  const fileInput = useRef(null);
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  const words = useMemo(() => countWords(value), [value]);
  const tooLong = value.length > maxChars;

  const handleFile = useCallback(
    async (file) => {
      if (!file) return;
      setFileError('');
      setFileNote('');
      setFileBusy(true);
      try {
        const { text, note } = await readResumeFile(file);
        if (!mounted.current) return;
        onChange(text);
        setFileNote(note || `Loaded "${file.name}".`);
      } catch (err) {
        if (!mounted.current) return;
        setFileError(err instanceof FileError ? err.message : 'That file could not be read. Try pasting the text instead.');
      } finally {
        if (mounted.current) setFileBusy(false);
      }
    },
    [onChange],
  );

  const onPick = (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = ''; // lets the same file be chosen again later
    handleFile(file);
  };

  const onDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    if (disabled || fileBusy) return;
    const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    handleFile(file);
  };

  const errorId = `${id}-error`;
  const locked = disabled || fileBusy;

  return (
    <div
      className={`glass p-4 sm:p-5 ${dragging ? 'ring-2 ring-sky-400/70' : ''}`}
      onDragOver={(e) => {
        e.preventDefault();
        if (!locked) setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={onDrop}
    >
      <div className="mb-2 flex flex-wrap items-end justify-between gap-2">
        <div>
          <label htmlFor={id} className="text-base font-bold text-slate-100">
            {label}
          </label>
          {hint ? <p className="text-xs text-slate-400">{hint}</p> : null}
        </div>
        <p className={`text-xs tabular-nums ${tooLong ? 'font-semibold text-red-300' : 'text-slate-500'}`} aria-live="polite">
          {fmt(words)} word{words === 1 ? '' : 's'} · {fmt(value.length)} / {fmt(maxChars)} characters
        </p>
      </div>

      <textarea
        id={id}
        className="field"
        rows={rows}
        value={value}
        placeholder={placeholder}
        spellCheck={false}
        disabled={disabled}
        aria-invalid={error ? 'true' : 'false'}
        aria-describedby={error ? errorId : undefined}
        onChange={(e) => onChange(e.target.value)}
      />

      <div className="mt-2.5 flex flex-wrap items-center gap-2">
        <input ref={fileInput} type="file" accept=".pdf,.docx,.txt" className="sr-only" tabIndex={-1} aria-label={`Upload a file for ${label}`} onChange={onPick} />
        <button type="button" className="btn btn-secondary btn-sm" disabled={locked} onClick={() => fileInput.current && fileInput.current.click()} title={`PDF, DOCX or TXT, up to ${MAX_FILE_BYTES / (1024 * 1024)} MB. Replaces the text above.`}>
          {fileBusy ? <Spinner /> : null}
          {fileBusy ? 'Reading file…' : 'Upload PDF / DOCX / TXT'}
        </button>
        <button
          type="button"
          className="btn btn-ghost btn-sm"
          disabled={locked || value.length === 0}
          onClick={() => {
            onChange('');
            setFileError('');
            setFileNote('');
          }}
        >
          Clear
        </button>
        {onSave ? (
          <button type="button" className="btn btn-ghost btn-sm ml-auto" disabled={locked || !value.trim()} onClick={onSave}>
            {saveLabel}
          </button>
        ) : null}
      </div>

      <div className="mt-2 space-y-2">
        {error ? (
          <Alert tone="error" id={errorId}>
            {error}
          </Alert>
        ) : null}
        {fileError ? <Alert tone="error">{fileError}</Alert> : null}
        {fileNote && !fileError ? <Alert tone="success">{fileNote}</Alert> : null}
      </div>
    </div>
  );
}
