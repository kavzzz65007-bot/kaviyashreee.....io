/**
 * PageTransition.jsx - plays a short fade/slide-in whenever `routeKey` changes.
 * Changing the React `key` remounts the wrapper, which restarts the CSS animation.
 * (With "reduce motion" on, index.css shortens the animation to nothing.)
 */
export default function PageTransition({ routeKey, children }) {
  return (
    <div key={routeKey} className="page-enter">
      {children}
    </div>
  );
}
