/**
 * NextBestEdits.jsx - the top 3 improvements not yet applied, ranked by the
 * estimated score gain (each one was simulated and re-scored by the engine).
 */

import { DeltaChip, SectionHeading } from './ui.jsx';

export default function NextBestEdits({ edits }) {
  return (
    <section className="glass p-4 sm:p-6" aria-labelledby="next-title">
      <SectionHeading id="next-title" eyebrow="Next best edit" title="What to improve next">
        Each suggestion was tried on your version 2 and re-scored. Gains are estimates and may not add up when combined.
      </SectionHeading>

      {edits.length === 0 ? (
        <p className="text-sm text-emerald-300">No further automatic improvements found. Nice work.</p>
      ) : (
        <ol className="space-y-3">
          {edits.map((edit, i) => (
            <li key={edit.id} className="flex gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-3">
              <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-sky-400/15 text-sm font-bold text-sky-200" aria-hidden="true">
                {i + 1}
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold text-slate-100">{edit.title}</p>
                <p className="mt-0.5 text-xs text-slate-400">{edit.detail}</p>
              </div>
              <DeltaChip tenths={edit.gainTenths} className="h-fit shrink-0" />
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}
