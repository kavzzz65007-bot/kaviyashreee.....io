/**
 * WordHighlight.jsx - version 2 with word-level colour.
 *
 *   green  an edited word that RAISED the score
 *   red    an edited word that LOWERED it
 *   dotted a changed word with no effect on the score
 *   struck-through words were deleted from v1 (shown so you can see what went)
 *
 * For a deleted word, green means "removing it helped", red "removing it hurt".
 */

import { useMemo, useState } from 'react';
import { formatDeltaTenths } from '../engine/scoring.js';
import { SectionHeading } from './ui.jsx';

function Segment({ seg }) {
  if (seg.status === 'same') return <span>{seg.text} </span>;

  let tone = 'w-flat';
  if (seg.impact > 0) tone = 'w-up';
  else if (seg.impact < 0) tone = 'w-down';
  const removed = seg.status === 'removed';
  const verb = removed ? 'Removing this word' : 'This word';
  const title =
    seg.impact === 0 || seg.impact == null
      ? `${verb}: no effect on the score`
      : `${verb}: ${formatDeltaTenths(seg.impact)} points${seg.lineLevel ? ' (whole line)' : ''}`;

  return (
    <>
      <span className={`w ${tone} ${removed ? 'w-gone' : ''}`} title={title}>
        {seg.text}
      </span>{' '}
    </>
  );
}

const isChanged = (line) => line.segments.some((s) => s.status !== 'same');

export default function WordHighlight({ lines, truncated }) {
  const [onlyChanged, setOnlyChanged] = useState(true);
  const changedCount = useMemo(() => lines.filter(isChanged).length, [lines]);

  const visible = useMemo(() => {
    if (!onlyChanged) return lines;
    return lines.filter(isChanged);
  }, [lines, onlyChanged]);

  return (
    <section className="glass p-4 sm:p-6" aria-labelledby="words-title">
      <SectionHeading id="words-title" eyebrow="Word-level impact" title="Which words moved the score">
        Hover or tap a highlighted word to see its effect.
      </SectionHeading>

      <ul className="mb-3 flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-slate-300" aria-label="Legend">
        <li>
          <span className="w w-up">word</span> raised the score
        </li>
        <li>
          <span className="w w-down">word</span> lowered it
        </li>
        <li>
          <span className="w w-flat">word</span> changed, no effect
        </li>
        <li>
          <span className="w w-gone w-flat">word</span> deleted from v1
        </li>
      </ul>

      <label className="mb-3 inline-flex cursor-pointer items-center gap-2 text-xs text-slate-400">
        <input type="checkbox" className="accent-sky-400" checked={onlyChanged} onChange={(e) => setOnlyChanged(e.target.checked)} />
        Show only changed lines ({changedCount} of {lines.length})
      </label>

      <div className="words max-h-[28rem] space-y-1 overflow-y-auto rounded-xl border border-white/10 bg-black/25 p-3 sm:p-4">
        {visible.length === 0 ? (
          <p className="text-slate-400">No changed lines to show.</p>
        ) : (
          visible.map((line) => (
            <p key={line.key} className={`break-words ${line.ghost ? 'ghost-line' : ''}`}>
              {line.marker ? <span className="text-slate-500">{line.marker}</span> : null}
              {line.segments.map((seg, i) => (
                <Segment key={`${line.key}-${i}`} seg={seg} />
              ))}
            </p>
          ))
        )}
      </div>

      {truncated ? <p className="mt-2 text-xs text-slate-500">This is a long edit, so only the first changed words were scored individually; the rest are shown in grey.</p> : null}
    </section>
  );
}
