/**
 * TimelineChart.jsx - hand-written SVG line chart of the score of every saved
 * version (v1, v2, v3 ...). No chart library, so it can never fail to load.
 */

import { ringColor } from '../three/math.js';

const W = 640;
const H = 250;
const PAD = { l: 38, r: 18, t: 22, b: 36 };

export default function TimelineChart({ points }) {
  const n = points.length;

  if (n === 0) {
    return (
      <div className="grid min-h-[9rem] place-items-center rounded-xl border border-dashed border-white/15 p-6 text-center text-sm text-slate-400">
        Save at least one version (use &ldquo;Save as version&rdquo; on a resume) to see your score timeline here.
      </div>
    );
  }

  const innerW = W - PAD.l - PAD.r;
  const innerH = H - PAD.t - PAD.b;
  const x = (i) => (n === 1 ? PAD.l + innerW / 2 : PAD.l + (i / (n - 1)) * innerW);
  const y = (score) => PAD.t + (1 - score / 100) * innerH;

  const line = points.map((p, i) => `${i === 0 ? 'M' : 'L'}${x(i).toFixed(1)} ${y(p.score).toFixed(1)}`).join(' ');
  const area = n > 1 ? `${line} L${x(n - 1).toFixed(1)} ${y(0)} L${x(0).toFixed(1)} ${y(0)} Z` : '';
  const showValues = n <= 10;
  const summary = points.map((p) => `${p.label}: ${p.score.toFixed(1)}`).join(', ');

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full" role="img" aria-label={`Score timeline. ${summary}`}>
      <defs>
        <linearGradient id="timeline-fill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#38bdf8" stopOpacity="0.35" />
          <stop offset="1" stopColor="#38bdf8" stopOpacity="0" />
        </linearGradient>
      </defs>

      {[0, 25, 50, 75, 100].map((tick) => (
        <g key={tick}>
          <line x1={PAD.l} x2={W - PAD.r} y1={y(tick)} y2={y(tick)} stroke="rgba(255,255,255,0.08)" strokeDasharray={tick === 0 ? undefined : '4 5'} />
          <text x={PAD.l - 8} y={y(tick) + 4} textAnchor="end" fontSize="11" fill="#64748b">
            {tick}
          </text>
        </g>
      ))}

      {area ? <path d={area} fill="url(#timeline-fill)" /> : null}
      {n > 1 ? <path d={line} fill="none" stroke="#38bdf8" strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round" /> : null}

      {points.map((p, i) => (
        <g key={p.id}>
          <circle cx={x(i)} cy={y(p.score)} r="5.5" fill="#0b1220" stroke={ringColor(p.score)} strokeWidth="3">
            <title>{`${p.label}: ${p.score.toFixed(1)} / 100`}</title>
          </circle>
          {showValues || i === n - 1 ? (
            <text x={x(i)} y={y(p.score) - 11} textAnchor="middle" fontSize="11.5" fontWeight="700" fill="#e2e8f0">
              {p.score.toFixed(1)}
            </text>
          ) : null}
          <text x={x(i)} y={H - 12} textAnchor="middle" fontSize="11.5" fill="#94a3b8">
            {p.label}
          </text>
        </g>
      ))}
    </svg>
  );
}
