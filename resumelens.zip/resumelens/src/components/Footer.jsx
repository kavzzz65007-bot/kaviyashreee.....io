/** Footer.jsx - privacy + honesty note shown on every page. */
export default function Footer() {
  return (
    <footer className="relative z-10 mt-16 border-t border-white/5 px-4 py-8 text-center text-xs leading-relaxed text-slate-500 sm:px-6">
      <p>
        ResumeLens runs entirely in your browser. Your resumes are never uploaded; they are only saved in this browser&apos;s local storage.
      </p>
      <p className="mt-1">
        Scores come from fixed, transparent rules - they estimate ATS-friendliness and are not a guarantee of how any real employer system will rank you.
      </p>
    </footer>
  );
}
